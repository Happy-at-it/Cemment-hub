# CEM Marketplace — Backend (Phase: Database + Domain Models)

## What's in this drop
Every domain app's **models, service-layer business logic, and Django
admin registrations** for the full v1 scope: users/auth foundation,
retailers, catalog, inventory, cart, orders, payments, delivery,
commission/settlements, reviews, disputes, notifications, promotions,
platform config, and audit logging.

This is real, structured Django code — not a mockup. It has been
**syntax-checked** (`python -m py_compile` on every file) but **not yet
executed against a live Django + MS SQL Server instance**, because this
authoring environment has no internet access to install Django. Do this
first when you pick it up:

```bash
python -m venv venv && source venv/bin/activate
pip install -r requirements/dev.txt
cp .env.example .env   # fill in a real SECRET_KEY and your MSSQL connection details
python manage.py makemigrations
python manage.py migrate
python manage.py createsuperuser
python manage.py runserver
```

You'll need the Microsoft ODBC Driver 18 for SQL Server installed on your
machine for `mssql-django`/`pyodbc` to connect. If you'd rather prove the
models out on SQLite first, temporarily swap the `DATABASES` block in
`config/settings/base.py` — MSSQL-specific SQL (in `docs/04-database-schema.sql`)
is the source of truth for the production schema either way.

## What's NOT in this drop yet (next phases)
- Authentication endpoints (register/login/JWT) — `apps/users/urls_auth.py`
  referenced in `config/urls.py` doesn't exist yet
- DRF serializers, viewsets, and `urls.py` for every other app
- Frontend templates/JS
- Seed data script
- Automated tests

These are exactly "Authentication" onward in the phase list — next up.

## Key design points to know before extending this
- **Service layer, not fat views**: business logic lives in each app's
  `services.py`. Views/serializers (added next phase) should stay thin —
  they validate input, call a service function, and serialize the result.
- **Stock changes always go through `apps/inventory/services.py:adjust_stock()`**,
  which row-locks the Inventory row and enforces the oversell guard.
  Never mutate `Inventory.quantity_available` directly.
- **Order status changes always go through `apps/orders/state_machine.py:transition()`**,
  same reasoning — illegal jumps are rejected there, not reconstructed per-caller.
- **Payments talk only to `apps/payments/gateways/factory.py:get_gateway()`**,
  never to a provider SDK directly, so swapping providers touches one file.
- **Business rules (commission %, cancellation window, fees) come from
  `apps/config/services.py:get_config()`**, not from Python constants.

See `../docs/` (from the prior architecture drop) for the full system
architecture, ER diagram, API spec, and phase-by-phase roadmap this code
follows.
