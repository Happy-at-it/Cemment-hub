"""Phase: Products & Catalog tests — product CRUD, inventory adjustment,
out-of-stock handling, and search/filter/compare."""
import pytest
from rest_framework.test import APIClient

from apps.users.models import User, Role
from apps.retailers.models import RetailerProfile
from apps.users.models import Address
from apps.catalog.models import Category, Brand, Product
from apps.inventory.models import Inventory

pytestmark = pytest.mark.django_db


@pytest.fixture
def api():
    return APIClient()


@pytest.fixture
def approved_retailer(db):
    role, _ = Role.objects.get_or_create(role_name=Role.RETAILER)
    user = User.objects.create_user(email="r1@example.com", phone="+233400000001", password="x", role=role)
    address = Address.objects.create(user=user, line1="1 Main St", city="Kumasi", region="Ashanti")
    return RetailerProfile.objects.create(
        user=user, business_name="Test Retailer", owner_name="Owner",
        business_address=address, status=RetailerProfile.APPROVED,
    )


@pytest.fixture
def category():
    return Category.objects.create(name="Cement", slug="cement")


@pytest.fixture
def brand():
    return Brand.objects.create(name="Ghacem")


@pytest.fixture
def product(approved_retailer, category, brand):
    p = Product.objects.create(
        retailer_profile=approved_retailer, category=category, brand=brand,
        product_name="Super Strong 42.5R", price_per_unit=78, min_order_quantity=5, max_order_quantity=500,
    )
    Inventory.objects.create(product=p, quantity_available=100)
    return p


class TestProductCreation:
    def test_retailer_can_create_product_with_initial_stock(self, api, approved_retailer, category, brand):
        api.force_authenticate(user=approved_retailer.user)
        resp = api.post("/api/v1/retailers/me/products/", {
            "category": category.id, "brand": brand.id, "product_name": "Diamond OPC 32.5R",
            "price_per_unit": "74.00", "min_order_quantity": 10, "initial_stock": 200,
        }, format="json")
        assert resp.status_code == 201
        assert resp.data["quantity_available"] == 200

    def test_max_qty_must_be_gte_min_qty(self, api, approved_retailer, category, brand):
        api.force_authenticate(user=approved_retailer.user)
        resp = api.post("/api/v1/retailers/me/products/", {
            "category": category.id, "brand": brand.id, "product_name": "Bad Product",
            "price_per_unit": "50.00", "min_order_quantity": 50, "max_order_quantity": 10,
        }, format="json")
        assert resp.status_code == 400

    def test_product_update_does_not_change_stock(self, api, approved_retailer, product):
        api.force_authenticate(user=approved_retailer.user)
        resp = api.patch(f"/api/v1/retailers/me/products/{product.id}/",
                          {"price_per_unit": "80.00", "initial_stock": 9999}, format="json")
        assert resp.status_code == 200
        product.inventory.refresh_from_db()
        assert product.inventory.quantity_available == 100  # unchanged despite initial_stock in payload


class TestInventoryAdjustment:
    def test_restock_increases_quantity_and_logs_history(self, api, approved_retailer, product):
        api.force_authenticate(user=approved_retailer.user)
        resp = api.post(f"/api/v1/retailers/me/products/{product.id}/inventory/adjust/",
                         {"delta": 50, "reason": "Restock"}, format="json")
        assert resp.status_code == 200
        assert resp.data["quantity_available"] == 150

        history = api.get(f"/api/v1/retailers/me/products/{product.id}/inventory/history/")
        assert history.status_code == 200
        assert history.data["count"] == 1
        assert history.data["results"][0]["change_quantity"] == 50

    def test_cannot_reduce_below_zero(self, api, approved_retailer, product):
        api.force_authenticate(user=approved_retailer.user)
        resp = api.post(f"/api/v1/retailers/me/products/{product.id}/inventory/adjust/",
                         {"delta": -500, "reason": "ManualAdjustment"}, format="json")
        assert resp.status_code == 400
        assert resp.data["error"]["code"] == "INSUFFICIENT_STOCK"

    def test_stock_hitting_zero_marks_out_of_stock(self, api, approved_retailer, product):
        api.force_authenticate(user=approved_retailer.user)
        api.post(f"/api/v1/retailers/me/products/{product.id}/inventory/adjust/",
                  {"delta": -100, "reason": "ManualAdjustment"}, format="json")
        product.refresh_from_db()
        assert product.availability_status == Product.OUT_OF_STOCK

    def test_out_of_stock_product_excluded_from_public_search(self, api, approved_retailer, product):
        api.force_authenticate(user=approved_retailer.user)
        api.post(f"/api/v1/retailers/me/products/{product.id}/inventory/adjust/",
                  {"delta": -100, "reason": "ManualAdjustment"}, format="json")

        api.force_authenticate(user=None)
        resp = api.get("/api/v1/products/")
        ids = [r["id"] for r in resp.data["results"]]
        assert product.id not in ids

    def test_other_retailer_cannot_adjust_stock(self, api, approved_retailer, product):
        role, _ = Role.objects.get_or_create(role_name=Role.RETAILER)
        other = User.objects.create_user(email="r2@example.com", phone="+233400000002", password="x", role=role)
        api.force_authenticate(user=other)
        resp = api.post(f"/api/v1/retailers/me/products/{product.id}/inventory/adjust/",
                         {"delta": 10, "reason": "Restock"}, format="json")
        assert resp.status_code == 404  # scoped queryset — no leak confirming the product exists


class TestSearchAndCompare:
    def test_search_filters_by_brand(self, api, product):
        resp = api.get("/api/v1/products/?brand=Ghacem")
        assert resp.status_code == 200
        assert resp.data["count"] == 1

    def test_search_filters_by_price_range(self, api, product):
        resp = api.get("/api/v1/products/?min_price=100")
        assert resp.data["count"] == 0

    def test_compare_requires_brand_or_category(self, api):
        resp = api.get("/api/v1/products/compare/")
        assert resp.status_code == 400

    def test_compare_returns_results_across_retailers(self, api, product):
        resp = api.get("/api/v1/products/compare/?brand=Ghacem")
        assert resp.status_code == 200
        assert resp.data["count"] == 1
        assert resp.data["results"][0]["is_sponsored"] is False
