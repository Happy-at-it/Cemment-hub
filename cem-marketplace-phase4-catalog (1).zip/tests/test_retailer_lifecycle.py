"""Phase: Retailers tests — registration, admin approve/reject/suspend,
directory visibility, and ownership checks."""
import pytest
from rest_framework.test import APIClient

from apps.users.models import User, Role
from apps.retailers.models import RetailerProfile

pytestmark = pytest.mark.django_db


@pytest.fixture
def api():
    return APIClient()


@pytest.fixture
def retailer_role():
    role, _ = Role.objects.get_or_create(role_name=Role.RETAILER)
    return role


@pytest.fixture
def admin_role():
    role, _ = Role.objects.get_or_create(role_name=Role.ADMIN)
    return role


@pytest.fixture
def retailer_user(retailer_role):
    return User.objects.create_user(
        email="retailer@example.com", phone="+233300000001", password="StrongPass123!", role=retailer_role
    )


@pytest.fixture
def admin_user(admin_role):
    return User.objects.create_user(
        email="admin@example.com", phone="+233300000002", password="StrongPass123!",
        role=admin_role, is_staff=True,
    )


REGISTRATION_PAYLOAD = {
    "business_name": "Kumasi Building Supplies", "owner_name": "Kwabena Asante",
    "address_line1": "12 Harper Road", "address_city": "Kumasi", "address_region": "Ashanti",
    "opening_hours": "7am - 6pm", "delivery_available": True, "pickup_available": True,
}


class TestRetailerRegistration:
    def test_retailer_can_register(self, api, retailer_user):
        api.force_authenticate(user=retailer_user)
        resp = api.post("/api/v1/retailers/register/", REGISTRATION_PAYLOAD, format="json")
        assert resp.status_code == 201
        assert resp.data["status"] == "Pending"
        assert RetailerProfile.objects.filter(user=retailer_user).exists()

    def test_customer_cannot_register_as_retailer(self, api, retailer_role):
        customer_role, _ = Role.objects.get_or_create(role_name=Role.CUSTOMER)
        customer = User.objects.create_user(
            email="cust@example.com", phone="+233300000003", password="x", role=customer_role
        )
        api.force_authenticate(user=customer)
        resp = api.post("/api/v1/retailers/register/", REGISTRATION_PAYLOAD, format="json")
        assert resp.status_code == 403

    def test_pending_retailer_not_in_public_directory(self, api, retailer_user):
        api.force_authenticate(user=retailer_user)
        api.post("/api/v1/retailers/register/", REGISTRATION_PAYLOAD, format="json")
        resp = api.get("/api/v1/retailers/")
        assert resp.status_code == 200
        assert resp.data["count"] == 0


class TestRetailerApproval:
    def test_admin_can_approve_retailer(self, api, retailer_user, admin_user):
        api.force_authenticate(user=retailer_user)
        api.post("/api/v1/retailers/register/", REGISTRATION_PAYLOAD, format="json")
        retailer = RetailerProfile.objects.get(user=retailer_user)

        api.force_authenticate(user=admin_user)
        resp = api.patch(f"/api/v1/admin/retailers/{retailer.id}/verify/", {"action": "approve"}, format="json")
        assert resp.status_code == 200
        retailer.refresh_from_db()
        assert retailer.status == RetailerProfile.APPROVED

    def test_approved_retailer_appears_in_directory(self, api, retailer_user, admin_user):
        api.force_authenticate(user=retailer_user)
        api.post("/api/v1/retailers/register/", REGISTRATION_PAYLOAD, format="json")
        retailer = RetailerProfile.objects.get(user=retailer_user)
        api.force_authenticate(user=admin_user)
        api.patch(f"/api/v1/admin/retailers/{retailer.id}/verify/", {"action": "approve"}, format="json")

        api.force_authenticate(user=None)
        resp = api.get("/api/v1/retailers/")
        assert resp.data["count"] == 1

    def test_reject_requires_reason(self, api, retailer_user, admin_user):
        api.force_authenticate(user=retailer_user)
        api.post("/api/v1/retailers/register/", REGISTRATION_PAYLOAD, format="json")
        retailer = RetailerProfile.objects.get(user=retailer_user)

        api.force_authenticate(user=admin_user)
        resp = api.patch(f"/api/v1/admin/retailers/{retailer.id}/verify/", {"action": "reject"}, format="json")
        assert resp.status_code == 400

    def test_non_admin_cannot_verify_retailer(self, api, retailer_user):
        api.force_authenticate(user=retailer_user)
        api.post("/api/v1/retailers/register/", REGISTRATION_PAYLOAD, format="json")
        retailer = RetailerProfile.objects.get(user=retailer_user)

        resp = api.patch(f"/api/v1/admin/retailers/{retailer.id}/verify/", {"action": "approve"}, format="json")
        assert resp.status_code == 403


class TestStoreManagement:
    def test_retailer_can_update_own_profile(self, api, retailer_user):
        api.force_authenticate(user=retailer_user)
        api.post("/api/v1/retailers/register/", REGISTRATION_PAYLOAD, format="json")
        resp = api.patch("/api/v1/retailers/me/", {"opening_hours": "8am - 8pm"}, format="json")
        assert resp.status_code == 200
        assert resp.data["opening_hours"] == "8am - 8pm"

    def test_retailer_cannot_set_own_status(self, api, retailer_user):
        api.force_authenticate(user=retailer_user)
        api.post("/api/v1/retailers/register/", REGISTRATION_PAYLOAD, format="json")
        resp = api.patch("/api/v1/retailers/me/", {"status": "Approved"}, format="json")
        assert resp.status_code == 200
        assert resp.data["status"] == "Pending"  # status field is read-only, silently ignored
