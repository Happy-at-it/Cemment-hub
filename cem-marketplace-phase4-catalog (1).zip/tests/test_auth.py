"""
Phase: Authentication tests. Run with `pytest` once the environment is
set up (see README). Uses pytest-django's `db` fixture so each test gets
a clean transactional database.
"""
import pytest
from rest_framework.test import APIClient
from apps.users.models import User, Role

pytestmark = pytest.mark.django_db


@pytest.fixture
def api():
    return APIClient()


@pytest.fixture
def customer_role():
    role, _ = Role.objects.get_or_create(role_name=Role.CUSTOMER)
    return role


class TestRegistration:
    def test_customer_can_register(self, api):
        resp = api.post("/api/v1/auth/register/", {
            "email": "ama@example.com", "phone": "+233200000001",
            "password": "StrongPass123!", "role": "Customer", "full_name": "Ama Mensah",
        })
        assert resp.status_code == 201
        assert User.objects.filter(email="ama@example.com").exists()
        user = User.objects.get(email="ama@example.com")
        assert user.customer_profile.full_name == "Ama Mensah"

    def test_customer_registration_requires_full_name(self, api):
        resp = api.post("/api/v1/auth/register/", {
            "email": "b@example.com", "phone": "+233200000002",
            "password": "StrongPass123!", "role": "Customer",
        })
        assert resp.status_code == 400

    def test_duplicate_email_rejected(self, api, customer_role):
        User.objects.create_user(email="dup@example.com", phone="+233200000003",
                                  password="x", role=customer_role)
        resp = api.post("/api/v1/auth/register/", {
            "email": "dup@example.com", "phone": "+233200000004",
            "password": "StrongPass123!", "role": "Customer", "full_name": "Dup Test",
        })
        assert resp.status_code == 400

    def test_weak_password_rejected(self, api):
        resp = api.post("/api/v1/auth/register/", {
            "email": "weak@example.com", "phone": "+233200000005",
            "password": "123", "role": "Customer", "full_name": "Weak Pass",
        })
        assert resp.status_code == 400


class TestLogin:
    def test_valid_login_returns_tokens(self, api, customer_role):
        User.objects.create_user(email="login@example.com", phone="+233200000006",
                                  password="StrongPass123!", role=customer_role)
        resp = api.post("/api/v1/auth/login/", {"email": "login@example.com", "password": "StrongPass123!"})
        assert resp.status_code == 200
        assert "access" in resp.data and "refresh" in resp.data

    def test_invalid_password_rejected(self, api, customer_role):
        User.objects.create_user(email="login2@example.com", phone="+233200000007",
                                  password="StrongPass123!", role=customer_role)
        resp = api.post("/api/v1/auth/login/", {"email": "login2@example.com", "password": "WrongPassword"})
        assert resp.status_code == 401

    def test_inactive_user_cannot_login(self, api, customer_role):
        user = User.objects.create_user(email="inactive@example.com", phone="+233200000008",
                                         password="StrongPass123!", role=customer_role)
        user.is_active = False
        user.save()
        resp = api.post("/api/v1/auth/login/", {"email": "inactive@example.com", "password": "StrongPass123!"})
        assert resp.status_code == 401


class TestPasswordReset:
    def test_reset_request_always_returns_200(self, api):
        # Even for a non-existent email — prevents account enumeration.
        resp = api.post("/api/v1/auth/password-reset/", {"email": "nobody@example.com"})
        assert resp.status_code == 200


class TestRolePermissions:
    def test_unauthenticated_cannot_view_profile(self, api):
        resp = api.get("/api/v1/users/me/")
        assert resp.status_code == 401

    def test_authenticated_customer_can_view_own_profile(self, api, customer_role):
        user = User.objects.create_user(email="me@example.com", phone="+233200000009",
                                         password="StrongPass123!", role=customer_role)
        api.force_authenticate(user=user)
        resp = api.get("/api/v1/users/me/")
        assert resp.status_code == 200
        assert resp.data["email"] == "me@example.com"
