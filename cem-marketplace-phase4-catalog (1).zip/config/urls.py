from django.contrib import admin
from django.urls import path, include
from django.conf import settings
from django.conf.urls.static import static
from drf_spectacular.views import SpectacularAPIView, SpectacularSwaggerView

urlpatterns = [
    path("admin/", admin.site.urls),

    # Each domain app owns its own urls.py, included here under /api/v1/.
    # Populated during the Authentication/API phase — auth is first since
    # every other endpoint depends on it.
    path("api/v1/auth/", include("apps.users.urls_auth")),
    path("api/v1/", include("apps.users.urls")),
    path("api/v1/", include("apps.retailers.urls")),
    path("api/v1/", include("apps.catalog.urls")),
    path("api/v1/", include("apps.cart.urls")),
    path("api/v1/", include("apps.orders.urls")),
    path("api/v1/", include("apps.payments.urls")),
    path("api/v1/", include("apps.delivery.urls")),
    path("api/v1/", include("apps.reviews.urls")),
    path("api/v1/", include("apps.disputes.urls")),
    path("api/v1/", include("apps.notifications.urls")),
    path("api/v1/admin/", include("apps.retailers.urls_admin")),
    path("api/v1/admin/", include("apps.commission.urls_admin")),

    path("api/v1/schema/", SpectacularAPIView.as_view(), name="schema"),
    path("api/v1/schema/swagger-ui/", SpectacularSwaggerView.as_view(url_name="schema")),
]

if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
