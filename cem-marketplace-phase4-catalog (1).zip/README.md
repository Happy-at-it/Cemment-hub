# CEM Marketplace — Backend (through Phase: Products & Catalog)

## Progress so far
- **Database**, **Authentication**, **Retailers** — see earlier phase notes below.
- **Products & Catalog** (this drop):
  - `GET /api/v1/categories/`, `GET /api/v1/brands/` — public
  - `GET /api/v1/products/?q=&brand=&category=&min_price=&max_price=&retailer=&in_stock=&rating_min=`
    — public search/filter; only Active products from Approved retailers are ever returned
  - `GET /api/v1/products/{id}/` — public detail
  - `GET /api/v1/products/compare/?brand=&category=&lat=&lng=` — cross-retailer comparison (price, stock,
    distance if lat/lng given, rating); never silently ranks by price, `is_sponsored` is always explicit
  - `GET/POST /api/v1/retailers/me/products/` — retailer's own products; `POST` accepts an `initial_stock`
    field that's applied through the same `adjust_stock()` used everywhere else (so it's logged to history)
  - `PATCH/DELETE /api/v1/retailers/me/products/{id}/` — `DELETE` soft-discontinues (sets `Discontinued`)
    rather than hard-deleting, since `OrderItem` rows reference products via `PROTECT`
  - `GET /api/v1/retailers/me/products/{id}/inventory/` — current stock
  - `POST /api/v1/retailers/me/products/{id}/inventory/adjust/` — `{"delta": 50, "reason": "Restock"}`,
    restricted to `Restock`/`ManualAdjustment` reasons (order-driven reasons are never client-settable)
  - `GET /api/v1/retailers/me/products/{id}/inventory/history/` — full stock change log
  - `tests/test_products_inventory.py` — product creation with initial stock, min/max validation, stock
    changes never leaking through a product PATCH, restock/history logging, oversell prevention
    (can't reduce below zero), stock-hits-zero auto-flips `OUT_OF_STOCK`, out-of-stock products excluded
    from public search, cross-retailer ownership isolation (404, not 403), brand/price filtering, compare
    endpoint validation

## Run it
```bash
python -m venv venv && source venv/bin/activate
pip install -r requirements/dev.txt
cp .env.example .env
python manage.py makemigrations && python manage.py migrate
python manage.py createsuperuser
python manage.py runserver
```
```bash
pytest   # runs all tests so far: auth, retailer lifecycle, products/inventory
```

## Still not run against a live interpreter
Syntax-checked (`py_compile` on every file) but not yet executed against
real Django/DRF/a real database — same sandbox limitation as every prior
phase. Please run `pytest` in Claude Code before we build more phases on
top — worth repeating since the Retailers-phase drop had a real (if
minor) logic bug that only `py_compile` alone didn't catch.

## What's next
Marketplace phase: retailer directory browsing polish, location-aware
"nearby retailers", and the customer-facing storefront view are mostly
already covered by the Retailers + Catalog phases — next up per your
phase list is **Cart**, formalizing `apps/cart/services.py` (already
written in the Database phase) behind real endpoints.
