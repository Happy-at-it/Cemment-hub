from django.db import transaction
from django.utils import timezone

from apps.audit import services as audit
from apps.notifications.services import notify
from apps.orders.state_machine import transition
from apps.orders.models import Order
from .models import Dispute


@transaction.atomic
def raise_dispute(order: Order, customer_profile, reason, description, evidence_files=None):
    dispute = Dispute.objects.create(
        order=order, customer_profile=customer_profile, retailer_profile=order.retailer_profile,
        reason=reason, description=description,
    )
    from .models import DisputeEvidence
    for f in (evidence_files or []):
        DisputeEvidence.objects.create(dispute=dispute, file=f)

    transition(order, Order.DISPUTED, changed_by=customer_profile.user, note=f"Dispute raised: {reason}")

    notify(order.retailer_profile.user, event_type="DisputeOpened",
           title="New dispute", message=f"A dispute was raised on order {order.order_number}.")
    audit.log(user=customer_profile.user, action="DisputeRaised", entity_type="Dispute", entity_id=dispute.id)
    return dispute


@transaction.atomic
def resolve_dispute(dispute: Dispute, resolution: str, refund_customer: bool, acting_admin, admin_notes=""):
    dispute.status = Dispute.RESOLVED
    dispute.resolution = resolution
    dispute.admin_notes = admin_notes
    dispute.resolution_date = timezone.now()
    dispute.save(update_fields=["status", "resolution", "admin_notes", "resolution_date"])

    order = dispute.order
    if refund_customer:
        transition(order, Order.REFUNDED, changed_by=acting_admin, note="Dispute resolved with refund")
        from apps.payments.services import refund_payment
        refund_payment(order.payment, amount=order.total_amount, reason=resolution, acting_admin=acting_admin)
    else:
        transition(order, Order.COMPLETED, changed_by=acting_admin, note="Dispute resolved, no refund")

    notify(order.customer_profile.user, event_type="DisputeResolved",
           title="Dispute resolved", message=f"Your dispute on {order.order_number} was resolved: {resolution}")
    audit.log(
        user=acting_admin, action="DisputeResolved", entity_type="Dispute", entity_id=dispute.id,
        new_value={"resolution": resolution, "refunded": refund_customer},
    )
    return dispute


def reject_dispute(dispute: Dispute, acting_admin, admin_notes=""):
    dispute.status = Dispute.REJECTED
    dispute.admin_notes = admin_notes
    dispute.resolution_date = timezone.now()
    dispute.save(update_fields=["status", "admin_notes", "resolution_date"])

    transition(dispute.order, Order.COMPLETED, changed_by=acting_admin, note="Dispute rejected")
    notify(dispute.order.customer_profile.user, event_type="DisputeUpdate",
           title="Dispute update", message="Your dispute was reviewed and rejected. See notes for details.")
    return dispute
