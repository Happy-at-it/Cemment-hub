from django.db import models
from apps.users.models import CustomerProfile
from apps.retailers.models import RetailerProfile
from apps.orders.models import Order


class Dispute(models.Model):
    MISSING_BAGS = "MissingBags"
    WRONG_PRODUCT = "WrongProduct"
    DAMAGED_PRODUCT = "DamagedProduct"
    FAILED_DELIVERY = "FailedDelivery"
    INCORRECT_QUANTITY = "IncorrectQuantity"
    PAYMENT_PROBLEM = "PaymentProblem"
    OTHER = "Other"
    REASON_CHOICES = [
        (MISSING_BAGS, "Missing bags"), (WRONG_PRODUCT, "Wrong product"),
        (DAMAGED_PRODUCT, "Damaged product"), (FAILED_DELIVERY, "Failed delivery"),
        (INCORRECT_QUANTITY, "Incorrect quantity"), (PAYMENT_PROBLEM, "Payment problem"),
        (OTHER, "Other"),
    ]

    OPEN, UNDER_REVIEW, RESOLVED, REJECTED = "Open", "UnderReview", "Resolved", "Rejected"
    STATUS_CHOICES = [
        (OPEN, "Open"), (UNDER_REVIEW, "Under Review"), (RESOLVED, "Resolved"), (REJECTED, "Rejected"),
    ]

    order = models.ForeignKey(Order, on_delete=models.CASCADE, related_name="disputes")
    customer_profile = models.ForeignKey(CustomerProfile, on_delete=models.CASCADE, related_name="disputes")
    retailer_profile = models.ForeignKey(RetailerProfile, on_delete=models.CASCADE, related_name="disputes")
    reason = models.CharField(max_length=50, choices=REASON_CHOICES)
    description = models.CharField(max_length=1000)
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default=OPEN)
    admin_notes = models.CharField(max_length=1000, blank=True, null=True)
    resolution = models.CharField(max_length=500, blank=True, null=True)
    resolution_date = models.DateTimeField(null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = "Disputes"
        indexes = [
            models.Index(fields=["order"], name="ix_disputes_order"),
            models.Index(fields=["status"], name="ix_disputes_status"),
        ]

    def __str__(self):
        return f"Dispute #{self.id} — {self.order.order_number} ({self.status})"


class DisputeEvidence(models.Model):
    dispute = models.ForeignKey(Dispute, on_delete=models.CASCADE, related_name="evidence")
    file = models.FileField(upload_to="dispute_evidence/")
    uploaded_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = "DisputeEvidence"

    def __str__(self):
        return f"Evidence for Dispute#{self.dispute_id}"
