from django.contrib import admin
from .models import Dispute, DisputeEvidence


class DisputeEvidenceInline(admin.TabularInline):
    model = DisputeEvidence
    extra = 0


@admin.register(Dispute)
class DisputeAdmin(admin.ModelAdmin):
    list_display = ("id", "order", "reason", "status", "created_at")
    list_filter = ("reason", "status")
    inlines = [DisputeEvidenceInline]
