"""Typed accessor for PlatformConfig, cached briefly so hot paths (like
checkout, run many times per minute) don't hit the DB for every read.
Falls back to settings.PLATFORM_DEFAULTS, then to the caller's own
default, so a missing config row never crashes a request."""
from django.conf import settings
from django.core.cache import cache

from .models import PlatformConfig

CACHE_TTL_SECONDS = 60


def get_config(key: str, default=None):
    cache_key = f"platform_config:{key}"
    cached = cache.get(cache_key)
    if cached is not None:
        return cached

    try:
        value = PlatformConfig.objects.get(config_key=key).config_value
    except PlatformConfig.DoesNotExist:
        value = settings.PLATFORM_DEFAULTS.get(key, default)

    cache.set(cache_key, value, CACHE_TTL_SECONDS)
    return value


def set_config(key: str, value: str, description: str = "", updated_by=None):
    from apps.audit import services as audit

    obj, created = PlatformConfig.objects.update_or_create(
        config_key=key, defaults={"config_value": value, "description": description, "updated_by": updated_by},
    )
    cache.delete(f"platform_config:{key}")
    audit.log(
        user=updated_by, action="PlatformConfigChanged", entity_type="PlatformConfig", entity_id=0,
        previous_value=None if created else {"key": key}, new_value={"key": key, "value": value},
    )
    return obj
