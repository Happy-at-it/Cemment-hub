from django.db import models
from apps.users.models import User


class PlatformConfig(models.Model):
    """Generic, admin-editable key/value store for business rules that
    shouldn't be hard-coded: commission defaults, cancellation windows,
    fee percentages, min/max order quantity defaults, etc. Structured
    rules that need their own relational shape (commission overrides,
    delivery pricing zones) get their own tables in apps.commission /
    apps.delivery instead — this table is for simple scalars."""

    config_key = models.CharField(max_length=100, primary_key=True)
    config_value = models.CharField(max_length=500)
    description = models.CharField(max_length=255, blank=True, null=True)
    updated_by = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, blank=True, related_name="+")
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        db_table = "PlatformConfig"

    def __str__(self):
        return f"{self.config_key} = {self.config_value}"
