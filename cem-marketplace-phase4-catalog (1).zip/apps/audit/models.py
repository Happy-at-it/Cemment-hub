from django.conf import settings
from django.db import models


class AuditLog(models.Model):
    """Immutable trail of sensitive mutations across the whole platform.
    Written to via apps.audit.services.log(...) from service-layer code in
    every other app — never edited or deleted through the API."""

    id = models.BigAutoField(primary_key=True)
    user = models.ForeignKey(
        settings.AUTH_USER_MODEL, null=True, blank=True,
        on_delete=models.SET_NULL, related_name="audit_logs",
    )
    action = models.CharField(max_length=100)  # e.g. 'RetailerApproved', 'PriceChanged'
    entity_type = models.CharField(max_length=50)
    entity_id = models.PositiveIntegerField()
    previous_value = models.JSONField(null=True, blank=True)
    new_value = models.JSONField(null=True, blank=True)
    ip_address = models.GenericIPAddressField(null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = "AuditLogs"
        indexes = [
            models.Index(fields=["entity_type", "entity_id"], name="ix_auditlogs_entity"),
            models.Index(fields=["created_at"], name="ix_auditlogs_created"),
        ]

    def __str__(self):
        return f"{self.action} on {self.entity_type}#{self.entity_id}"
