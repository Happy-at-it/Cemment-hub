import threading

_local = threading.local()


class RequestContextMiddleware:
    """Stashes the current request on thread-local storage so service-layer
    code (which doesn't have direct access to the request/response cycle)
    can still record the acting user's IP address in the audit log without
    every service function needing a `request` parameter threaded through."""

    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        _local.request = request
        try:
            return self.get_response(request)
        finally:
            _local.request = None


def get_current_request():
    return getattr(_local, "request", None)
