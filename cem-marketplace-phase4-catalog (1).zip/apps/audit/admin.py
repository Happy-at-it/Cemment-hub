from django.contrib import admin
from .models import AuditLog


@admin.register(AuditLog)
class AuditLogAdmin(admin.ModelAdmin):
    list_display = ("id", "action", "entity_type", "entity_id", "user", "created_at")
    list_filter = ("action", "entity_type")
    search_fields = ("entity_type", "action")
    readonly_fields = [f.name for f in AuditLog._meta.fields]  # audit logs are never hand-edited

    def has_add_permission(self, request):
        return False

    def has_delete_permission(self, request, obj=None):
        return False
