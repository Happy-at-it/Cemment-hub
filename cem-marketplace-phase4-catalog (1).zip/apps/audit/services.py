from .middleware import get_current_request
from .models import AuditLog


def log(user, action, entity_type, entity_id, previous_value=None, new_value=None):
    """Call this from every service function that performs a sensitive
    mutation: retailer approval, price change, inventory change, order
    status change, payment change, refund, settlement change, suspension.

    Example:
        audit.log(
            user=request.user, action="PriceChanged",
            entity_type="Product", entity_id=product.id,
            previous_value={"price": str(old_price)},
            new_value={"price": str(new_price)},
        )
    """
    request = get_current_request()
    ip = None
    if request is not None:
        forwarded = request.META.get("HTTP_X_FORWARDED_FOR")
        ip = forwarded.split(",")[0].strip() if forwarded else request.META.get("REMOTE_ADDR")

    AuditLog.objects.create(
        user=user,
        action=action,
        entity_type=entity_type,
        entity_id=entity_id,
        previous_value=previous_value,
        new_value=new_value,
        ip_address=ip,
    )
