from django.contrib import admin
from .models import Promotion, PromotionUsage


@admin.register(Promotion)
class PromotionAdmin(admin.ModelAdmin):
    list_display = ("name", "promotion_type", "code", "discount_type", "discount_value", "is_active")
    list_filter = ("promotion_type", "is_active")


@admin.register(PromotionUsage)
class PromotionUsageAdmin(admin.ModelAdmin):
    list_display = ("promotion", "order", "discount_amount", "created_at")
