from django.db import models
from apps.users.models import CustomerProfile
from apps.retailers.models import RetailerProfile
from apps.catalog.models import Product
from apps.orders.models import Order


class Promotion(models.Model):
    DISCOUNT_CODE = "DiscountCode"
    PRODUCT_DISCOUNT = "ProductDiscount"
    RETAILER_PROMOTION = "RetailerPromotion"
    FEATURED_PRODUCT = "FeaturedProduct"
    SEASONAL = "Seasonal"
    TYPE_CHOICES = [
        (DISCOUNT_CODE, "Discount Code"), (PRODUCT_DISCOUNT, "Product Discount"),
        (RETAILER_PROMOTION, "Retailer Promotion"), (FEATURED_PRODUCT, "Featured Product"),
        (SEASONAL, "Seasonal"),
    ]
    PERCENT, FIXED = "Percent", "Fixed"
    DISCOUNT_TYPE_CHOICES = [(PERCENT, "Percent"), (FIXED, "Fixed")]

    name = models.CharField(max_length=150)
    promotion_type = models.CharField(max_length=30, choices=TYPE_CHOICES)
    code = models.CharField(max_length=30, unique=True, blank=True, null=True)
    discount_type = models.CharField(max_length=10, choices=DISCOUNT_TYPE_CHOICES, blank=True, null=True)
    discount_value = models.DecimalField(max_digits=10, decimal_places=2, blank=True, null=True)
    retailer_profile = models.ForeignKey(
        RetailerProfile, on_delete=models.CASCADE, null=True, blank=True, related_name="promotions"
    )
    product = models.ForeignKey(Product, on_delete=models.CASCADE, null=True, blank=True, related_name="promotions")
    starts_at = models.DateTimeField()
    ends_at = models.DateTimeField()
    usage_limit = models.PositiveIntegerField(null=True, blank=True)
    is_active = models.BooleanField(default=True)

    class Meta:
        db_table = "Promotions"

    def __str__(self):
        return self.name


class PromotionUsage(models.Model):
    promotion = models.ForeignKey(Promotion, on_delete=models.CASCADE, related_name="usages")
    order = models.ForeignKey(Order, on_delete=models.CASCADE, related_name="promotion_usages")
    customer_profile = models.ForeignKey(CustomerProfile, on_delete=models.CASCADE, related_name="promotion_usages")
    discount_amount = models.DecimalField(max_digits=10, decimal_places=2)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = "PromotionUsages"

    def __str__(self):
        return f"{self.promotion} on {self.order}"
