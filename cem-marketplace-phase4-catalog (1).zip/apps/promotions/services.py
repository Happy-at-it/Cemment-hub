from decimal import Decimal
from django.core.exceptions import ValidationError
from django.utils import timezone

from .models import Promotion, PromotionUsage


class InvalidPromotionError(ValidationError):
    pass


def validate_and_apply_code(code: str, cart_subtotal: Decimal, customer_profile):
    try:
        promo = Promotion.objects.get(code=code, promotion_type=Promotion.DISCOUNT_CODE, is_active=True)
    except Promotion.DoesNotExist:
        raise InvalidPromotionError("This discount code is not valid.")

    now = timezone.now()
    if not (promo.starts_at <= now <= promo.ends_at):
        raise InvalidPromotionError("This discount code has expired or is not yet active.")

    if promo.usage_limit is not None:
        used_count = PromotionUsage.objects.filter(promotion=promo).count()
        if used_count >= promo.usage_limit:
            raise InvalidPromotionError("This discount code has reached its usage limit.")

    if promo.discount_type == Promotion.PERCENT:
        discount = (cart_subtotal * promo.discount_value / 100).quantize(Decimal("0.01"))
    else:
        discount = min(promo.discount_value, cart_subtotal)

    return promo, discount


def record_usage(promo: Promotion, order, customer_profile, discount_amount):
    PromotionUsage.objects.create(
        promotion=promo, order=order, customer_profile=customer_profile, discount_amount=discount_amount
    )
