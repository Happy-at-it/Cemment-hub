"""
v1 distance calculation: straight-line (haversine) distance between two
lat/lng points. Deliberately isolated behind GeoService so a real
maps/routing provider (Google Maps, Mapbox) can be swapped in later for
actual road-distance/ETA without touching pricing or checkout code —
per the spec's 'design so map/GPS can be integrated later' requirement.
"""
import math
from .base import GeoService

EARTH_RADIUS_KM = 6371.0


class HaversineGeoService(GeoService):
    def distance_km(self, lat1, lng1, lat2, lng2) -> float:
        lat1, lng1, lat2, lng2 = map(math.radians, [float(lat1), float(lng1), float(lat2), float(lng2)])
        dlat = lat2 - lat1
        dlng = lng2 - lng1
        a = math.sin(dlat / 2) ** 2 + math.cos(lat1) * math.cos(lat2) * math.sin(dlng / 2) ** 2
        c = 2 * math.asin(math.sqrt(a))
        return round(EARTH_RADIUS_KM * c, 2)
