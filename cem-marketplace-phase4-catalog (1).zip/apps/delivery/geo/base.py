from abc import ABC, abstractmethod


class GeoService(ABC):
    @abstractmethod
    def distance_km(self, lat1, lng1, lat2, lng2) -> float:
        ...
