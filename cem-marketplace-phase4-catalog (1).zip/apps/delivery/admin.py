from django.contrib import admin
from .models import DriverProfile, DeliveryPricingRule, Delivery, DeliveryStatusHistory


@admin.register(DriverProfile)
class DriverProfileAdmin(admin.ModelAdmin):
    list_display = ("user", "vehicle_type", "verification_status", "is_active")
    list_filter = ("verification_status", "is_active")


@admin.register(DeliveryPricingRule)
class DeliveryPricingRuleAdmin(admin.ModelAdmin):
    list_display = ("zone_name", "vehicle_type", "base_fee", "per_km_fee", "per_kg_fee", "is_active")


class DeliveryStatusHistoryInline(admin.TabularInline):
    model = DeliveryStatusHistory
    extra = 0
    readonly_fields = ("status", "changed_at")


@admin.register(Delivery)
class DeliveryAdmin(admin.ModelAdmin):
    list_display = ("order", "driver_profile", "status", "delivery_fee")
    list_filter = ("status",)
    inlines = [DeliveryStatusHistoryInline]
