"""Delivery pricing engine and assignment/status logic."""
from django.core.exceptions import ValidationError
from django.db import transaction
from django.utils import timezone

from apps.audit import services as audit
from apps.notifications.services import notify
from .geo.haversine import HaversineGeoService
from .models import Delivery, DeliveryPricingRule, DeliveryStatusHistory

_geo = HaversineGeoService()

# Valid delivery-status transitions — mirrors orders.state_machine's
# pattern so drivers can't skip steps (e.g. straight to Delivered).
VALID_TRANSITIONS = {
    Delivery.PENDING: {Delivery.CONFIRMED, Delivery.CANCELLED},
    Delivery.CONFIRMED: {Delivery.PREPARING, Delivery.CANCELLED},
    Delivery.PREPARING: {Delivery.DRIVER_ASSIGNED},
    Delivery.DRIVER_ASSIGNED: {Delivery.PICKED_UP, Delivery.FAILED},
    Delivery.PICKED_UP: {Delivery.OUT_FOR_DELIVERY},
    Delivery.OUT_FOR_DELIVERY: {Delivery.DELIVERED, Delivery.FAILED},
}


class IllegalDeliveryTransitionError(ValidationError):
    pass


def estimate_delivery_fee(retailer_profile, destination_lat, destination_lng, total_weight_kg, vehicle_type=None):
    """Resolves the active DeliveryPricingRule for the retailer's zone
    (v1: nearest match by vehicle_type, falling back to a rule with no
    vehicle_type set) and computes base + per-km + per-kg fee. Never
    hard-coded — every coefficient comes from the DB."""
    rule = (
        DeliveryPricingRule.objects.filter(is_active=True, vehicle_type=vehicle_type).first()
        or DeliveryPricingRule.objects.filter(is_active=True, vehicle_type__isnull=True).first()
    )
    if rule is None:
        raise ValidationError("No active delivery pricing rule is configured. Contact platform admin.")

    if retailer_profile.store_latitude is None or retailer_profile.store_longitude is None:
        raise ValidationError("Retailer location is not set; cannot calculate delivery distance.")

    distance = _geo.distance_km(
        retailer_profile.store_latitude, retailer_profile.store_longitude, destination_lat, destination_lng
    )
    fee = rule.base_fee + (rule.per_km_fee * distance) + (rule.per_kg_fee * total_weight_kg)
    return round(fee, 2), distance


@transaction.atomic
def assign_driver(delivery: Delivery, driver_profile, acting_user):
    _transition(delivery, Delivery.DRIVER_ASSIGNED, acting_user)
    delivery.driver_profile = driver_profile
    delivery.assigned_at = timezone.now()
    delivery.save(update_fields=["driver_profile", "assigned_at"])
    notify(driver_profile.user, event_type="NewAssignment",
           title="New delivery assignment", message=f"You've been assigned order {delivery.order.order_number}.")
    return delivery


@transaction.atomic
def update_status(delivery: Delivery, new_status: str, acting_user):
    _transition(delivery, new_status, acting_user)
    now = timezone.now()
    if new_status == Delivery.PICKED_UP:
        delivery.picked_up_at = now
        delivery.save(update_fields=["picked_up_at"])
    elif new_status == Delivery.DELIVERED:
        delivery.delivered_at = now
        delivery.save(update_fields=["delivered_at"])
        notify(delivery.order.customer_profile.user, event_type="Delivered",
               title="Delivered", message=f"Order {delivery.order.order_number} has been delivered.")
    return delivery


def _transition(delivery, new_status, acting_user):
    if new_status not in VALID_TRANSITIONS.get(delivery.status, set()):
        raise IllegalDeliveryTransitionError(f"Cannot move delivery from '{delivery.status}' to '{new_status}'.")
    previous = delivery.status
    delivery.status = new_status
    delivery.save(update_fields=["status"])
    DeliveryStatusHistory.objects.create(delivery=delivery, status=new_status)
    audit.log(
        user=acting_user, action="DeliveryStatusChanged", entity_type="Delivery", entity_id=delivery.id,
        previous_value={"status": previous}, new_value={"status": new_status},
    )
