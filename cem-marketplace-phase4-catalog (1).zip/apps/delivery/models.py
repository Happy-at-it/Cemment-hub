from django.db import models
from apps.users.models import User, Address
from apps.orders.models import Order


class DriverProfile(models.Model):
    PENDING, APPROVED, REJECTED = "Pending", "Approved", "Rejected"
    VERIFICATION_CHOICES = [(PENDING, "Pending"), (APPROVED, "Approved"), (REJECTED, "Rejected")]

    user = models.OneToOneField(User, on_delete=models.CASCADE, related_name="driver_profile")
    vehicle_type = models.CharField(max_length=50, blank=True, null=True)  # motorbike, truck, tricycle
    license_number = models.CharField(max_length=50, blank=True, null=True)
    verification_status = models.CharField(max_length=20, choices=VERIFICATION_CHOICES, default=PENDING)
    is_active = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = "DriverProfiles"

    def __str__(self):
        return f"Driver: {self.user.email}"


class DeliveryPricingRule(models.Model):
    """Configurable delivery pricing — nothing about fees is hard-coded
    elsewhere in the app; the pricing engine (see services.py) resolves
    the active rule for a zone/vehicle and computes the fee from it."""

    zone_name = models.CharField(max_length=100)
    base_fee = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    per_km_fee = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    per_kg_fee = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    vehicle_type = models.CharField(max_length=50, blank=True, null=True)
    is_active = models.BooleanField(default=True)
    effective_from = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = "DeliveryPricingRules"

    def __str__(self):
        return f"{self.zone_name} ({self.vehicle_type or 'any vehicle'})"


class Delivery(models.Model):
    PENDING = "Pending"
    CONFIRMED = "Confirmed"
    PREPARING = "Preparing"
    DRIVER_ASSIGNED = "DriverAssigned"
    PICKED_UP = "PickedUp"
    OUT_FOR_DELIVERY = "OutForDelivery"
    DELIVERED = "Delivered"
    FAILED = "Failed"
    CANCELLED = "Cancelled"
    STATUS_CHOICES = [
        (PENDING, "Pending"), (CONFIRMED, "Confirmed"), (PREPARING, "Preparing"),
        (DRIVER_ASSIGNED, "Driver Assigned"), (PICKED_UP, "Picked Up"),
        (OUT_FOR_DELIVERY, "Out for Delivery"), (DELIVERED, "Delivered"),
        (FAILED, "Failed"), (CANCELLED, "Cancelled"),
    ]

    order = models.OneToOneField(Order, on_delete=models.PROTECT, related_name="delivery")
    driver_profile = models.ForeignKey(
        DriverProfile, on_delete=models.SET_NULL, null=True, blank=True, related_name="deliveries"
    )
    pickup_address = models.ForeignKey(Address, on_delete=models.PROTECT, related_name="+")
    delivery_address = models.ForeignKey(Address, on_delete=models.PROTECT, related_name="+")
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default=PENDING)
    delivery_fee = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    # Stored for a future real GPS-based ETA; v1 just estimates from distance.
    estimated_delivery_time = models.DateTimeField(null=True, blank=True)
    delivery_instructions = models.CharField(max_length=255, blank=True, null=True)
    proof_of_delivery = models.ImageField(upload_to="proof_of_delivery/", blank=True, null=True)
    assigned_at = models.DateTimeField(null=True, blank=True)
    picked_up_at = models.DateTimeField(null=True, blank=True)
    delivered_at = models.DateTimeField(null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = "Deliveries"
        indexes = [
            models.Index(fields=["driver_profile"], name="ix_deliveries_driver"),
            models.Index(fields=["status"], name="ix_deliveries_status"),
        ]

    def __str__(self):
        return f"Delivery for {self.order.order_number} — {self.status}"

    def get_retailer_profile(self):
        return self.order.retailer_profile


class DeliveryStatusHistory(models.Model):
    delivery = models.ForeignKey(Delivery, on_delete=models.CASCADE, related_name="status_history")
    status = models.CharField(max_length=20, choices=Delivery.STATUS_CHOICES)
    changed_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = "DeliveryStatusHistory"
        ordering = ["changed_at"]

    def __str__(self):
        return f"{self.delivery} -> {self.status}"
