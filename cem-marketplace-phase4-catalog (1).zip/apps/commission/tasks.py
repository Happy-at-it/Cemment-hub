"""Celery periodic task — run e.g. weekly via CELERY_BEAT_SCHEDULE (wired
in when Phase 8 deployment/config is set up)."""
from celery import shared_task
from datetime import date, timedelta

from apps.retailers.models import RetailerProfile
from .services import run_settlement_for_retailer


@shared_task
def run_weekly_settlements():
    period_end = date.today()
    period_start = period_end - timedelta(days=7)
    for retailer in RetailerProfile.objects.filter(status=RetailerProfile.APPROVED):
        run_settlement_for_retailer(retailer, period_start, period_end)
