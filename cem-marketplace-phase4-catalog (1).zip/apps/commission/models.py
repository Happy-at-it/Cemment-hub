from django.db import models
from apps.retailers.models import RetailerProfile
from apps.catalog.models import Category
from apps.orders.models import Order


class CommissionRule(models.Model):
    PLATFORM, RETAILER, CATEGORY = "Platform", "Retailer", "Category"
    SCOPE_CHOICES = [(PLATFORM, "Platform"), (RETAILER, "Retailer"), (CATEGORY, "Category")]

    scope = models.CharField(max_length=20, choices=SCOPE_CHOICES)
    retailer_profile = models.ForeignKey(
        RetailerProfile, on_delete=models.CASCADE, null=True, blank=True, related_name="commission_rules"
    )
    category = models.ForeignKey(
        Category, on_delete=models.CASCADE, null=True, blank=True, related_name="commission_rules"
    )
    rate_percent = models.DecimalField(max_digits=5, decimal_places=2)
    is_active = models.BooleanField(default=True)
    effective_from = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = "CommissionRules"
        constraints = [
            models.CheckConstraint(
                check=models.Q(rate_percent__gte=0) & models.Q(rate_percent__lte=100),
                name="ck_commission_rate_range",
            ),
        ]

    def __str__(self):
        return f"{self.scope} — {self.rate_percent}%"


class Settlement(models.Model):
    PENDING, PROCESSING, PAID, FAILED, ON_HOLD = "Pending", "Processing", "Paid", "Failed", "OnHold"
    STATUS_CHOICES = [
        (PENDING, "Pending"), (PROCESSING, "Processing"), (PAID, "Paid"),
        (FAILED, "Failed"), (ON_HOLD, "On Hold"),
    ]

    retailer_profile = models.ForeignKey(RetailerProfile, on_delete=models.PROTECT, related_name="settlements")
    period_start = models.DateField()
    period_end = models.DateField()
    gross_amount = models.DecimalField(max_digits=14, decimal_places=2, default=0)
    commission_amount = models.DecimalField(max_digits=14, decimal_places=2, default=0)
    fees_amount = models.DecimalField(max_digits=14, decimal_places=2, default=0)
    refunds_amount = models.DecimalField(max_digits=14, decimal_places=2, default=0)
    net_amount = models.DecimalField(max_digits=14, decimal_places=2, default=0)
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default=PENDING)
    paid_at = models.DateTimeField(null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = "Settlements"
        indexes = [models.Index(fields=["retailer_profile"], name="ix_settlements_retailer")]

    def __str__(self):
        return f"Settlement #{self.id} — {self.retailer_profile.business_name} ({self.status})"


class SettlementItem(models.Model):
    settlement = models.ForeignKey(Settlement, on_delete=models.CASCADE, related_name="items")
    order = models.ForeignKey(Order, on_delete=models.PROTECT, related_name="settlement_items")
    amount = models.DecimalField(max_digits=12, decimal_places=2)

    class Meta:
        db_table = "SettlementItems"
        constraints = [models.UniqueConstraint(fields=["settlement", "order"], name="ux_settlementitem_order")]

    def __str__(self):
        return f"{self.order} -> Settlement#{self.settlement_id}"
