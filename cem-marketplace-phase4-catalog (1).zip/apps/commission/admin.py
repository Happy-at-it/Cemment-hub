from django.contrib import admin
from .models import CommissionRule, Settlement, SettlementItem


@admin.register(CommissionRule)
class CommissionRuleAdmin(admin.ModelAdmin):
    list_display = ("scope", "retailer_profile", "category", "rate_percent", "is_active")
    list_filter = ("scope", "is_active")


class SettlementItemInline(admin.TabularInline):
    model = SettlementItem
    extra = 0
    readonly_fields = ("order", "amount")


@admin.register(Settlement)
class SettlementAdmin(admin.ModelAdmin):
    list_display = ("id", "retailer_profile", "period_start", "period_end", "net_amount", "status")
    list_filter = ("status",)
    inlines = [SettlementItemInline]
    actions = ["put_on_hold"]

    @admin.action(description="Place selected settlements on hold")
    def put_on_hold(self, request, queryset):
        from .services import hold_settlement
        for settlement in queryset:
            hold_settlement(settlement, acting_admin=request.user, reason="Held via admin bulk action")
