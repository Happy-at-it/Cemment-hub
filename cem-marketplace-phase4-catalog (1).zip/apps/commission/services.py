"""
Commission resolution ('most specific rule wins': retailer-specific
override > category-specific override > platform default) and the
settlement batch job that turns a period of completed orders into a
payable settlement per retailer.
"""
from decimal import Decimal

from django.db import transaction
from django.db.models import Sum

from apps.audit import services as audit
from apps.config.services import get_config
from apps.orders.models import Order
from .models import CommissionRule, Settlement, SettlementItem


def resolve_commission_rate(retailer_profile, category=None) -> Decimal:
    retailer_rule = CommissionRule.objects.filter(
        scope=CommissionRule.RETAILER, retailer_profile=retailer_profile, is_active=True
    ).order_by("-effective_from").first()
    if retailer_rule:
        return retailer_rule.rate_percent

    if category:
        category_rule = CommissionRule.objects.filter(
            scope=CommissionRule.CATEGORY, category=category, is_active=True
        ).order_by("-effective_from").first()
        if category_rule:
            return category_rule.rate_percent

    platform_rule = CommissionRule.objects.filter(
        scope=CommissionRule.PLATFORM, is_active=True
    ).order_by("-effective_from").first()
    if platform_rule:
        return platform_rule.rate_percent

    return Decimal(get_config("DEFAULT_COMMISSION_PERCENT", default="3.00"))


def calculate_order_breakdown(order: Order) -> dict:
    """Returns gross order value, commission, delivery fee, other fees,
    retailer settlement amount, and platform revenue for one order —
    exactly the breakdown the spec's commission example asks for."""
    rate = resolve_commission_rate(order.retailer_profile)
    commission_amount = (order.subtotal * rate / 100).quantize(Decimal("0.01"))
    retailer_settlement_amount = order.subtotal - commission_amount
    platform_revenue = commission_amount + order.platform_fee
    return {
        "gross_order_value": order.subtotal,
        "commission_rate_percent": rate,
        "commission_amount": commission_amount,
        "delivery_fee": order.delivery_fee,
        "platform_fee": order.platform_fee,
        "retailer_settlement_amount": retailer_settlement_amount,
        "platform_revenue": platform_revenue,
    }


@transaction.atomic
def run_settlement_for_retailer(retailer_profile, period_start, period_end, acting_admin=None):
    """Aggregates all Completed orders for a retailer in [period_start,
    period_end] that aren't already settled, and creates one Settlement +
    its SettlementItems. Designed to be called from a periodic Celery task
    (apps/commission/tasks.py) rather than synchronously from a request."""
    already_settled_order_ids = SettlementItem.objects.values_list("order_id", flat=True)

    orders = Order.objects.filter(
        retailer_profile=retailer_profile,
        order_status=Order.COMPLETED,
        completed_at__date__gte=period_start,
        completed_at__date__lte=period_end,
    ).exclude(id__in=already_settled_order_ids)

    if not orders.exists():
        return None

    gross = orders.aggregate(total=Sum("subtotal"))["total"] or Decimal("0")
    commission_total = Decimal("0")
    for order in orders:
        commission_total += calculate_order_breakdown(order)["commission_amount"]

    fees_total = orders.aggregate(total=Sum("platform_fee"))["total"] or Decimal("0")
    refunds_total = Decimal("0")  # refunds are netted in a later phase once dispute-driven refunds are tallied
    net_amount = gross - commission_total - fees_total - refunds_total

    settlement = Settlement.objects.create(
        retailer_profile=retailer_profile, period_start=period_start, period_end=period_end,
        gross_amount=gross, commission_amount=commission_total, fees_amount=fees_total,
        refunds_amount=refunds_total, net_amount=net_amount, status=Settlement.PENDING,
    )
    SettlementItem.objects.bulk_create([
        SettlementItem(settlement=settlement, order=order, amount=order.subtotal) for order in orders
    ])

    audit.log(
        user=acting_admin, action="SettlementCreated", entity_type="Settlement", entity_id=settlement.id,
        new_value={"net_amount": str(net_amount), "order_count": orders.count()},
    )
    return settlement


def hold_settlement(settlement: Settlement, acting_admin, reason: str):
    previous = settlement.status
    settlement.status = Settlement.ON_HOLD
    settlement.save(update_fields=["status"])
    audit.log(
        user=acting_admin, action="SettlementHeld", entity_type="Settlement", entity_id=settlement.id,
        previous_value={"status": previous}, new_value={"status": settlement.status, "reason": reason},
    )
    return settlement
