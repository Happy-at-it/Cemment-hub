from django.urls import path

# Built out in the "Admin" phase.
urlpatterns = []
