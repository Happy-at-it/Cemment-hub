from rest_framework import generics, status
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response

from apps.audit import services as audit
from .models import Address
from .serializers import UserSerializer, AddressSerializer


class MeView(generics.RetrieveUpdateAPIView):
    """GET/PATCH /api/v1/users/me/
    Only email verification/phone verification/role/is_active are
    read-only — those change through dedicated flows (email/phone
    verification, admin action), never a plain profile PATCH."""
    serializer_class = UserSerializer
    permission_classes = [IsAuthenticated]

    def get_object(self):
        return self.request.user


class MyAddressListCreateView(generics.ListCreateAPIView):
    """GET/POST /api/v1/users/me/addresses/"""
    serializer_class = AddressSerializer
    permission_classes = [IsAuthenticated]

    def get_queryset(self):
        return Address.objects.filter(user=self.request.user).order_by("-is_default", "-created_at")


class MyAddressDetailView(generics.RetrieveUpdateDestroyAPIView):
    """PATCH/DELETE /api/v1/users/me/addresses/{id}/
    Queryset is scoped to the requesting user, so this 404s (rather than
    403s, avoiding confirming the address exists at all) for anyone else's
    address id — ownership can't be probed by guessing IDs."""
    serializer_class = AddressSerializer
    permission_classes = [IsAuthenticated]

    def get_queryset(self):
        return Address.objects.filter(user=self.request.user)

    def destroy(self, request, *args, **kwargs):
        instance = self.get_object()
        audit.log(user=request.user, action="AddressDeleted", entity_type="Address", entity_id=instance.id)
        return super().destroy(request, *args, **kwargs)
