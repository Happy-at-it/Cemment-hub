from django.contrib import admin
from django.contrib.auth.admin import UserAdmin as DjangoUserAdmin
from .models import Role, User, Address, CustomerProfile, ContractorProfile, Project


@admin.register(Role)
class RoleAdmin(admin.ModelAdmin):
    list_display = ("id", "role_name")


@admin.register(User)
class UserAdmin(DjangoUserAdmin):
    model = User
    list_display = ("email", "phone", "role", "is_active", "is_staff", "created_at")
    list_filter = ("role", "is_active", "is_staff")
    search_fields = ("email", "phone")
    ordering = ("-created_at",)
    fieldsets = (
        (None, {"fields": ("email", "phone", "password")}),
        ("Role & status", {"fields": ("role", "is_active", "is_staff", "is_superuser",
                                       "is_email_verified", "is_phone_verified")}),
        ("Permissions", {"fields": ("groups", "user_permissions")}),
    )
    add_fieldsets = (
        (None, {"classes": ("wide",), "fields": ("email", "phone", "role", "password1", "password2")}),
    )


@admin.register(Address)
class AddressAdmin(admin.ModelAdmin):
    list_display = ("id", "user", "city", "region", "is_default")
    search_fields = ("city", "region", "line1")


@admin.register(CustomerProfile)
class CustomerProfileAdmin(admin.ModelAdmin):
    list_display = ("id", "full_name", "user", "is_contractor")
    search_fields = ("full_name",)


@admin.register(ContractorProfile)
class ContractorProfileAdmin(admin.ModelAdmin):
    list_display = ("id", "company_name", "subscription_tier")
    search_fields = ("company_name",)


@admin.register(Project)
class ProjectAdmin(admin.ModelAdmin):
    list_display = ("id", "project_name", "contractor_profile", "is_active")
