from django.contrib.auth.base_user import AbstractBaseUser, BaseUserManager
from django.contrib.auth.models import PermissionsMixin
from django.db import models


class Role(models.Model):
    CUSTOMER, RETAILER, DRIVER, ADMIN = "Customer", "Retailer", "Driver", "Admin"
    ROLE_CHOICES = [
        (CUSTOMER, "Customer"),
        (RETAILER, "Retailer"),
        (DRIVER, "Driver"),
        (ADMIN, "Admin"),
    ]

    role_name = models.CharField(max_length=30, choices=ROLE_CHOICES, unique=True)

    class Meta:
        db_table = "Roles"

    def __str__(self):
        return self.role_name


class UserManager(BaseUserManager):
    def create_user(self, email, phone, password=None, role=None, **extra_fields):
        if not email:
            raise ValueError("Users must have an email address.")
        if not phone:
            raise ValueError("Users must have a phone number.")
        email = self.normalize_email(email)
        user = self.model(email=email, phone=phone, role=role, **extra_fields)
        user.set_password(password)  # PBKDF2 hashing via Django's password hasher
        user.save(using=self._db)
        return user

    def create_superuser(self, email, phone, password=None, **extra_fields):
        extra_fields.setdefault("is_staff", True)
        extra_fields.setdefault("is_superuser", True)
        admin_role, _ = Role.objects.get_or_create(role_name=Role.ADMIN)
        extra_fields.setdefault("role", admin_role)
        return self.create_user(email, phone, password, **extra_fields)


class User(AbstractBaseUser, PermissionsMixin):
    """Single Users table for all four roles, per the schema design.
    Role-specific data lives in the 1:1 profile tables in other apps
    (CustomerProfile, RetailerProfile, DriverProfile)."""

    email = models.EmailField(unique=True, max_length=255)
    phone = models.CharField(unique=True, max_length=20)
    role = models.ForeignKey(Role, on_delete=models.PROTECT, related_name="users")
    is_active = models.BooleanField(default=True)
    is_email_verified = models.BooleanField(default=False)
    is_phone_verified = models.BooleanField(default=False)
    is_staff = models.BooleanField(default=False)  # Django admin site access
    last_login_at = models.DateTimeField(null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    objects = UserManager()

    USERNAME_FIELD = "email"
    REQUIRED_FIELDS = ["phone"]

    class Meta:
        db_table = "Users"
        indexes = [models.Index(fields=["role"], name="ix_users_role")]

    def __str__(self):
        return self.email


class Address(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name="addresses")
    label = models.CharField(max_length=50, blank=True, null=True)  # 'Home', 'Site A', ...
    line1 = models.CharField(max_length=255)
    line2 = models.CharField(max_length=255, blank=True, null=True)
    city = models.CharField(max_length=100)
    region = models.CharField(max_length=100)
    latitude = models.DecimalField(max_digits=9, decimal_places=6, null=True, blank=True)
    longitude = models.DecimalField(max_digits=9, decimal_places=6, null=True, blank=True)
    is_default = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = "Addresses"
        indexes = [models.Index(fields=["user"], name="ix_addresses_user")]

    def __str__(self):
        return f"{self.line1}, {self.city}"


class CustomerProfile(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE, related_name="customer_profile")
    full_name = models.CharField(max_length=150)
    is_contractor = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = "CustomerProfiles"

    def __str__(self):
        return self.full_name


class ContractorProfile(models.Model):
    FREE, PREMIUM = "Free", "Premium"
    TIER_CHOICES = [(FREE, "Free"), (PREMIUM, "Premium")]

    customer_profile = models.OneToOneField(
        CustomerProfile, on_delete=models.CASCADE, related_name="contractor_profile"
    )
    company_name = models.CharField(max_length=200)
    business_contact_name = models.CharField(max_length=150)
    business_phone = models.CharField(max_length=20)
    business_email = models.EmailField()
    subscription_tier = models.CharField(max_length=30, choices=TIER_CHOICES, default=FREE)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = "ContractorProfiles"

    def __str__(self):
        return self.company_name


class Project(models.Model):
    """A contractor's construction/project site — enables project-based
    purchasing and spend reporting per project."""

    contractor_profile = models.ForeignKey(
        ContractorProfile, on_delete=models.CASCADE, related_name="projects"
    )
    project_name = models.CharField(max_length=200)
    site_address = models.ForeignKey(Address, on_delete=models.PROTECT, related_name="+")
    budget = models.DecimalField(max_digits=14, decimal_places=2, null=True, blank=True)
    is_active = models.BooleanField(default=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = "Projects"
        indexes = [models.Index(fields=["contractor_profile"], name="ix_projects_contractor")]

    def __str__(self):
        return self.project_name
