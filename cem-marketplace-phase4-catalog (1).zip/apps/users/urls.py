from django.urls import path
from .views import MeView, MyAddressListCreateView, MyAddressDetailView

# Mounted at /api/v1/ by config/urls.py, so these resolve to
# /api/v1/users/me/ and /api/v1/users/me/addresses/...
urlpatterns = [
    path("users/me/", MeView.as_view(), name="users-me"),
    path("users/me/addresses/", MyAddressListCreateView.as_view(), name="users-me-addresses"),
    path("users/me/addresses/<int:pk>/", MyAddressDetailView.as_view(), name="users-me-address-detail"),
]
