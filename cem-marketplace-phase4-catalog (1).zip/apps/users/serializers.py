from django.contrib.auth.password_validation import validate_password
from django.core.exceptions import ValidationError as DjangoValidationError
from rest_framework import serializers

from .models import User, Role, Address, CustomerProfile, ContractorProfile, Project


class RoleSerializer(serializers.ModelSerializer):
    class Meta:
        model = Role
        fields = ["id", "role_name"]


class RegisterSerializer(serializers.Serializer):
    """Registers a User with one of the three self-serve roles. Retailer
    and Driver registrations create the User + role here, but the actual
    business/vehicle profile (with documents) is completed via each role's
    own registration endpoint (apps.retailers / apps.delivery, next phases)
    — this mirrors the real-world flow: account first, verification second.
    Admin accounts are never created through this endpoint."""

    email = serializers.EmailField()
    phone = serializers.CharField(max_length=20)
    password = serializers.CharField(write_only=True)
    role = serializers.ChoiceField(choices=[Role.CUSTOMER, Role.RETAILER, Role.DRIVER])
    full_name = serializers.CharField(max_length=150, required=False)  # required if role=Customer

    def validate_email(self, value):
        if User.objects.filter(email__iexact=value).exists():
            raise serializers.ValidationError("An account with this email already exists.")
        return value

    def validate_phone(self, value):
        if User.objects.filter(phone=value).exists():
            raise serializers.ValidationError("An account with this phone number already exists.")
        return value

    def validate_password(self, value):
        try:
            validate_password(value)  # enforces Django's configured password strength rules
        except DjangoValidationError as exc:
            raise serializers.ValidationError(list(exc.messages))
        return value

    def validate(self, attrs):
        if attrs["role"] == Role.CUSTOMER and not attrs.get("full_name"):
            raise serializers.ValidationError({"full_name": "This field is required for customer registration."})
        return attrs

    def create(self, validated_data):
        role_obj, _ = Role.objects.get_or_create(role_name=validated_data["role"])
        user = User.objects.create_user(
            email=validated_data["email"], phone=validated_data["phone"],
            password=validated_data["password"], role=role_obj,
        )
        if validated_data["role"] == Role.CUSTOMER:
            CustomerProfile.objects.create(user=user, full_name=validated_data["full_name"])
        return user


class UserSerializer(serializers.ModelSerializer):
    role = RoleSerializer(read_only=True)

    class Meta:
        model = User
        fields = ["id", "email", "phone", "role", "is_active", "is_email_verified",
                  "is_phone_verified", "created_at"]
        read_only_fields = fields


class AddressSerializer(serializers.ModelSerializer):
    class Meta:
        model = Address
        fields = ["id", "label", "line1", "line2", "city", "region",
                  "latitude", "longitude", "is_default"]

    def create(self, validated_data):
        validated_data["user"] = self.context["request"].user
        if validated_data.get("is_default"):
            Address.objects.filter(user=validated_data["user"]).update(is_default=False)
        return super().create(validated_data)

    def update(self, instance, validated_data):
        if validated_data.get("is_default"):
            Address.objects.filter(user=instance.user).exclude(id=instance.id).update(is_default=False)
        return super().update(instance, validated_data)


class CustomerProfileSerializer(serializers.ModelSerializer):
    user = UserSerializer(read_only=True)

    class Meta:
        model = CustomerProfile
        fields = ["id", "user", "full_name", "is_contractor"]
        read_only_fields = ["id", "user", "is_contractor"]


class ContractorProfileSerializer(serializers.ModelSerializer):
    class Meta:
        model = ContractorProfile
        fields = ["id", "company_name", "business_contact_name", "business_phone",
                  "business_email", "subscription_tier"]
        read_only_fields = ["id", "subscription_tier"]


class ProjectSerializer(serializers.ModelSerializer):
    class Meta:
        model = Project
        fields = ["id", "project_name", "site_address", "budget", "is_active"]


class PasswordResetRequestSerializer(serializers.Serializer):
    email = serializers.EmailField()


class PasswordResetConfirmSerializer(serializers.Serializer):
    uid = serializers.CharField()
    token = serializers.CharField()
    new_password = serializers.CharField(write_only=True)

    def validate_new_password(self, value):
        try:
            validate_password(value)
        except DjangoValidationError as exc:
            raise serializers.ValidationError(list(exc.messages))
        return value
