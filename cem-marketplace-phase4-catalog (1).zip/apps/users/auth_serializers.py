from rest_framework_simplejwt.serializers import TokenObtainPairSerializer


class RoleAwareTokenObtainPairSerializer(TokenObtainPairSerializer):
    """Embeds the user's role into the JWT payload so the frontend can
    route/render without an extra profile fetch, and so downstream
    services could (if ever needed) check role from the token alone.
    Authorization decisions in the API itself still always re-check
    request.user.role from the DB, never trust the token claim alone."""

    @classmethod
    def get_token(cls, user):
        token = super().get_token(user)
        token["role"] = user.role.role_name
        token["email"] = user.email
        return token
