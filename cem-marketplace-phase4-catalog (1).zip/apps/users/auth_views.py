from django.contrib.auth.tokens import PasswordResetTokenGenerator
from django.utils.encoding import force_bytes, force_str
from django.utils.http import urlsafe_base64_encode, urlsafe_base64_decode
from rest_framework import status, generics
from rest_framework.permissions import AllowAny
from rest_framework.response import Response
from rest_framework.views import APIView
from rest_framework_simplejwt.tokens import RefreshToken
from rest_framework_simplejwt.views import TokenObtainPairView, TokenRefreshView
from rest_framework_simplejwt.exceptions import TokenError

from apps.audit import services as audit
from apps.notifications.services import notify
from .auth_serializers import RoleAwareTokenObtainPairSerializer
from .models import User
from .serializers import (
    RegisterSerializer, UserSerializer,
    PasswordResetRequestSerializer, PasswordResetConfirmSerializer,
)

_token_generator = PasswordResetTokenGenerator()


class RegisterView(generics.CreateAPIView):
    """POST /api/v1/auth/register/
    Public. Rate-limited via the 'auth' throttle scope to slow down
    automated account-creation abuse."""
    serializer_class = RegisterSerializer
    permission_classes = [AllowAny]
    throttle_scope = "auth"

    def create(self, request, *args, **kwargs):
        serializer = self.get_serializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        user = serializer.save()
        audit.log(user=user, action="UserRegistered", entity_type="User", entity_id=user.id)
        notify(user, event_type="Registration", title="Welcome to CEM Marketplace",
               message="Your account has been created.")
        return Response(UserSerializer(user).data, status=status.HTTP_201_CREATED)


class LoginView(TokenObtainPairView):
    """POST /api/v1/auth/login/  ->  { access, refresh }
    Uses RoleAwareTokenObtainPairSerializer so the token carries the
    user's role. Django's ModelBackend (used under the hood) already
    rejects is_active=False users with the same generic error message
    SimpleJWT returns for a wrong password, so failed logins never leak
    which part was wrong."""
    serializer_class = RoleAwareTokenObtainPairSerializer
    permission_classes = [AllowAny]
    throttle_scope = "auth"


class RefreshView(TokenRefreshView):
    """POST /api/v1/auth/refresh/"""
    permission_classes = [AllowAny]


class LogoutView(APIView):
    """POST /api/v1/auth/logout/  { "refresh": "..." }
    Blacklists the refresh token so it can't be replayed after logout —
    requires rest_framework_simplejwt.token_blacklist in INSTALLED_APPS."""
    permission_classes = [AllowAny]

    def post(self, request):
        refresh = request.data.get("refresh")
        if not refresh:
            return Response({"error": {"code": "MISSING_TOKEN", "message": "Refresh token is required."}},
                             status=status.HTTP_400_BAD_REQUEST)
        try:
            RefreshToken(refresh).blacklist()
        except TokenError:
            # Already invalid/expired — logout is idempotent either way.
            pass
        return Response(status=status.HTTP_204_NO_CONTENT)


class PasswordResetRequestView(APIView):
    """POST /api/v1/auth/password-reset/  { "email": "..." }
    Always returns 200 regardless of whether the email exists, so this
    endpoint can't be used to enumerate registered accounts."""
    permission_classes = [AllowAny]
    throttle_scope = "auth"

    def post(self, request):
        serializer = PasswordResetRequestSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        email = serializer.validated_data["email"]

        user = User.objects.filter(email__iexact=email).first()
        if user:
            uid = urlsafe_base64_encode(force_bytes(user.pk))
            token = _token_generator.make_token(user)
            # In production this becomes a link to the frontend's reset
            # page (e.g. https://app.example.com/reset?uid=...&token=...);
            # for now the token is delivered via the notification service's
            # email channel, which uses the console backend in dev.
            notify(user, event_type="PasswordReset", title="Reset your password",
                   message=f"Use this code to reset your password: uid={uid} token={token} "
                           f"(expires shortly, single use).")
            audit.log(user=user, action="PasswordResetRequested", entity_type="User", entity_id=user.id)

        return Response({"detail": "If that email is registered, a reset link has been sent."})


class PasswordResetConfirmView(APIView):
    """POST /api/v1/auth/password-reset/confirm/  { "uid", "token", "new_password" }"""
    permission_classes = [AllowAny]
    throttle_scope = "auth"

    def post(self, request):
        serializer = PasswordResetConfirmSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        data = serializer.validated_data

        try:
            user_id = force_str(urlsafe_base64_decode(data["uid"]))
            user = User.objects.get(pk=user_id)
        except (User.DoesNotExist, ValueError, TypeError, OverflowError):
            return Response({"error": {"code": "INVALID_LINK", "message": "This reset link is invalid."}},
                             status=status.HTTP_400_BAD_REQUEST)

        if not _token_generator.check_token(user, data["token"]):
            return Response({"error": {"code": "INVALID_OR_EXPIRED_TOKEN",
                                        "message": "This reset link is invalid or has expired."}},
                             status=status.HTTP_400_BAD_REQUEST)

        user.set_password(data["new_password"])
        user.save(update_fields=["password"])
        audit.log(user=user, action="PasswordResetCompleted", entity_type="User", entity_id=user.id)
        return Response({"detail": "Password has been reset. You can now log in."})
