"""
Inventory mutation logic. This is the single place stock is ever changed —
every caller (manual retailer adjustment, order placement, order
cancellation) goes through adjust_stock() so the history log and the
oversell guard can never be bypassed.
"""
from django.core.exceptions import ValidationError
from django.db import transaction

from apps.audit import services as audit
from .models import Inventory, InventoryHistory


class InsufficientStockError(ValidationError):
    pass


@transaction.atomic
def adjust_stock(product, delta: int, reason: str, changed_by=None):
    """Applies a signed delta to a product's stock inside a DB transaction,
    row-locking the Inventory row (select_for_update) so two concurrent
    checkouts can never both succeed against the same last few units —
    this is the concurrency safeguard the spec requires."""
    inventory = Inventory.objects.select_for_update().get(product=product)

    previous_qty = inventory.quantity_available
    new_qty = previous_qty + delta

    if new_qty < 0:
        raise InsufficientStockError(
            f"Cannot fulfill: only {previous_qty} units of '{product.product_name}' available."
        )

    inventory.quantity_available = new_qty
    inventory.save(update_fields=["quantity_available", "updated_at"])

    InventoryHistory.objects.create(
        product=product, change_quantity=delta, previous_quantity=previous_qty,
        new_quantity=new_qty, reason=reason, changed_by=changed_by,
    )

    if new_qty == 0 and product.availability_status == product.ACTIVE:
        product.availability_status = product.OUT_OF_STOCK
        product.save(update_fields=["availability_status", "updated_at"])

    if inventory.is_low_stock():
        _notify_low_stock(product, inventory)

    audit.log(
        user=changed_by, action="InventoryAdjusted", entity_type="Product", entity_id=product.id,
        previous_value={"quantity_available": previous_qty},
        new_value={"quantity_available": new_qty, "reason": reason},
    )
    return inventory


def reserve_for_order(product, quantity, changed_by=None):
    """Called at order-confirmation time. Raises InsufficientStockError
    (caught by the checkout view and surfaced as the friendly
    'This product is currently out of stock.' message) if unavailable."""
    return adjust_stock(product, delta=-quantity, reason=InventoryHistory.ORDER_PLACED, changed_by=changed_by)


def release_for_cancelled_order(product, quantity, changed_by=None):
    return adjust_stock(product, delta=quantity, reason=InventoryHistory.ORDER_CANCELLED, changed_by=changed_by)


def _notify_low_stock(product, inventory):
    from apps.notifications.services import notify
    notify(
        product.retailer_profile.user, event_type="LowStock",
        title="Low stock alert",
        message=f"'{product.product_name}' is down to {inventory.quantity_available} units "
                f"(threshold: {inventory.low_stock_threshold}).",
    )
