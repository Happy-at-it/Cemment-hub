from django.shortcuts import get_object_or_404
from rest_framework import generics
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.views import APIView

from apps.catalog.models import Product
from apps.common.permissions import IsRetailer
from .models import Inventory, InventoryHistory
from .serializers import InventorySerializer, InventoryAdjustSerializer, InventoryHistorySerializer
from .services import adjust_stock, InsufficientStockError


def _owned_product_or_404(user, product_id):
    return get_object_or_404(Product, id=product_id, retailer_profile__user=user)


class ProductInventoryView(generics.RetrieveAPIView):
    """GET /api/v1/retailers/me/products/{id}/inventory/"""
    serializer_class = InventorySerializer
    permission_classes = [IsAuthenticated, IsRetailer]

    def get_object(self):
        product = _owned_product_or_404(self.request.user, self.kwargs["product_id"])
        return product.inventory


class ProductInventoryAdjustView(APIView):
    """POST /api/v1/retailers/me/products/{id}/inventory/adjust/
    { "delta": 50, "reason": "Restock" }  — the only way stock changes
    outside of order placement/cancellation. Always goes through
    inventory.services.adjust_stock(), so row-locking, the oversell
    guard, low-stock notification, and audit logging all apply here too."""
    permission_classes = [IsAuthenticated, IsRetailer]

    def post(self, request, product_id):
        product = _owned_product_or_404(request.user, product_id)
        serializer = InventoryAdjustSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)

        try:
            inventory = adjust_stock(
                product, delta=serializer.validated_data["delta"],
                reason=serializer.validated_data["reason"], changed_by=request.user,
            )
        except InsufficientStockError as exc:
            return Response({"error": {"code": "INSUFFICIENT_STOCK", "message": str(exc)}}, status=400)

        return Response(InventorySerializer(inventory).data)


class ProductInventoryHistoryView(generics.ListAPIView):
    """GET /api/v1/retailers/me/products/{id}/inventory/history/"""
    serializer_class = InventoryHistorySerializer
    permission_classes = [IsAuthenticated, IsRetailer]

    def get_queryset(self):
        product = _owned_product_or_404(self.request.user, self.kwargs["product_id"])
        return InventoryHistory.objects.filter(product=product).order_by("-created_at")
