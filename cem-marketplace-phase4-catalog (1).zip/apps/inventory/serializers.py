from rest_framework import serializers
from .models import Inventory, InventoryHistory


class InventorySerializer(serializers.ModelSerializer):
    product_name = serializers.CharField(source="product.product_name", read_only=True)

    class Meta:
        model = Inventory
        fields = ["product", "product_name", "quantity_available", "low_stock_threshold", "updated_at"]
        read_only_fields = ["product", "product_name", "quantity_available", "updated_at"]


class InventoryAdjustSerializer(serializers.Serializer):
    delta = serializers.IntegerField(help_text="Positive to add stock, negative to remove/correct.")
    reason = serializers.ChoiceField(choices=[InventoryHistory.RESTOCK, InventoryHistory.MANUAL_ADJUSTMENT])

    def validate_delta(self, value):
        if value == 0:
            raise serializers.ValidationError("Delta must not be zero.")
        return value


class InventoryHistorySerializer(serializers.ModelSerializer):
    changed_by_email = serializers.CharField(source="changed_by.email", read_only=True, default=None)

    class Meta:
        model = InventoryHistory
        fields = ["id", "change_quantity", "previous_quantity", "new_quantity", "reason",
                  "changed_by_email", "created_at"]
