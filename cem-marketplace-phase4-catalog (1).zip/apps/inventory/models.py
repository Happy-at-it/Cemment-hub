from django.db import models
from apps.catalog.models import Product
from apps.users.models import User


class Inventory(models.Model):
    product = models.OneToOneField(Product, on_delete=models.CASCADE, primary_key=True, related_name="inventory")
    quantity_available = models.PositiveIntegerField(default=0)
    low_stock_threshold = models.PositiveIntegerField(default=20)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        db_table = "Inventory"
        constraints = [
            models.CheckConstraint(check=models.Q(quantity_available__gte=0), name="ck_inventory_qty_nonneg"),
        ]

    def __str__(self):
        return f"{self.product} — {self.quantity_available} in stock"

    def is_low_stock(self):
        return self.quantity_available <= self.low_stock_threshold


class InventoryHistory(models.Model):
    RESTOCK = "Restock"
    MANUAL_ADJUSTMENT = "ManualAdjustment"
    ORDER_PLACED = "OrderPlaced"
    ORDER_CANCELLED = "OrderCancelled"
    REASON_CHOICES = [
        (RESTOCK, "Restock"),
        (MANUAL_ADJUSTMENT, "Manual Adjustment"),
        (ORDER_PLACED, "Order Placed"),
        (ORDER_CANCELLED, "Order Cancelled"),
    ]

    product = models.ForeignKey(Product, on_delete=models.CASCADE, related_name="inventory_history")
    change_quantity = models.IntegerField()   # signed delta
    previous_quantity = models.PositiveIntegerField()
    new_quantity = models.PositiveIntegerField()
    reason = models.CharField(max_length=50, choices=REASON_CHOICES)
    changed_by = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, blank=True, related_name="+")
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = "InventoryHistory"
        indexes = [models.Index(fields=["product"], name="ix_invhistory_product")]

    def __str__(self):
        return f"{self.product} {self.change_quantity:+d} ({self.reason})"
