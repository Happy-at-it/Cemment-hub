from django.contrib import admin
from .models import Inventory, InventoryHistory


@admin.register(Inventory)
class InventoryAdmin(admin.ModelAdmin):
    list_display = ("product", "quantity_available", "low_stock_threshold", "updated_at")
    list_filter = ()
    search_fields = ("product__product_name",)


@admin.register(InventoryHistory)
class InventoryHistoryAdmin(admin.ModelAdmin):
    list_display = ("product", "change_quantity", "reason", "created_at")
    list_filter = ("reason",)
    readonly_fields = [f.name for f in InventoryHistory._meta.fields]

    def has_add_permission(self, request):
        return False
