from django.contrib import admin
from .models import Notification


@admin.register(Notification)
class NotificationAdmin(admin.ModelAdmin):
    list_display = ("user", "event_type", "title", "channel", "is_read", "created_at")
    list_filter = ("channel", "is_read", "event_type")
