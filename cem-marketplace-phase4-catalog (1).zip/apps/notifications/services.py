"""
Central dispatch: notify(user, event_type, title, message) fans out to
whichever channels are configured active for that event. v1 ships with
InApp always on; Email is used for a subset of high-importance events.
SMS/Push are wired into the same interface later without touching callers.
"""
from .channels.in_app import InAppChannel
from .channels.email import EmailChannel

EMAIL_EVENTS = {
    "RetailerApproved", "RetailerRejected", "RetailerSuspended",
    "PaymentSuccessful", "PaymentFailed", "OrderCancelled", "Refund",
}

_in_app = InAppChannel()
_email = EmailChannel()


def notify(user, event_type: str, title: str, message: str):
    _in_app.send(user, title, message, event_type)
    if event_type in EMAIL_EVENTS:
        _email.send(user, title, message, event_type)
