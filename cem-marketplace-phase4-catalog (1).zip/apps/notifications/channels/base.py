from abc import ABC, abstractmethod


class NotificationChannel(ABC):
    @abstractmethod
    def send(self, user, title: str, message: str, event_type: str) -> bool:
        """Returns True if the channel accepted/sent the message."""
        ...
