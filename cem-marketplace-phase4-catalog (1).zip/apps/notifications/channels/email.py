from django.core.mail import send_mail
from django.conf import settings
from .base import NotificationChannel


class EmailChannel(NotificationChannel):
    def send(self, user, title, message, event_type) -> bool:
        if not user.email:
            return False
        try:
            send_mail(title, message, settings.DEFAULT_FROM_EMAIL, [user.email], fail_silently=False)
            return True
        except Exception:
            # Email failures should never break the triggering request/transaction.
            return False
