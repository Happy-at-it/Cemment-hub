from .base import NotificationChannel


class SMSChannel(NotificationChannel):
    """Stubbed until an SMS provider (e.g. an Africa's Talking / Twilio
    integration for Ghana) is selected — isolated here so plugging one in
    later touches only this file."""

    def send(self, user, title, message, event_type) -> bool:
        raise NotImplementedError("SMS channel not yet configured with a provider.")
