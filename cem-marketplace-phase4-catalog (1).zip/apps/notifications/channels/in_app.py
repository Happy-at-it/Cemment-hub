from ..models import Notification
from .base import NotificationChannel


class InAppChannel(NotificationChannel):
    """v1's primary channel — always on, since it just writes a DB row the
    user's dashboard/notification bell reads from. No external dependency,
    so it's the most practical channel to implement first, per the spec."""

    def send(self, user, title, message, event_type) -> bool:
        Notification.objects.create(user=user, event_type=event_type, title=title, message=message, channel="InApp")
        return True
