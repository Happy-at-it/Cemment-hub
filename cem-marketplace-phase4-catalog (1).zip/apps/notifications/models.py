from django.db import models
from apps.users.models import User

CHANNEL_CHOICES = [("InApp", "In-App"), ("Email", "Email"), ("SMS", "SMS"), ("Push", "Push")]


class Notification(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name="notifications")
    event_type = models.CharField(max_length=50)   # 'OrderPlaced', 'LowStock', 'DriverAssigned', ...
    title = models.CharField(max_length=150)
    message = models.CharField(max_length=500)
    channel = models.CharField(max_length=20, choices=CHANNEL_CHOICES, default="InApp")
    is_read = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = "Notifications"
        indexes = [models.Index(fields=["user", "is_read"], name="ix_notifications_user_read")]
        ordering = ["-created_at"]

    def __str__(self):
        return f"{self.event_type} -> {self.user}"
