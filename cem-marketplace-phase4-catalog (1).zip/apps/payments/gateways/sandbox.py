"""
Development/test gateway. Deliberately isolated in its own module and only
ever selected when PAYMENT_PROVIDER=sandbox (the dev default) — never
wired in as a fallback inside production code paths, per the spec's
explicit instruction not to hard-code fake payment success into
production code.
"""
import uuid
from .base import PaymentGatewayService, ChargeResult, RefundResult


class SandboxGateway(PaymentGatewayService):
    """Simulates provider behavior for local development and automated
    tests only. A 'FAIL' amount sentinel lets tests exercise the failure
    path deterministically."""

    def charge(self, *, amount, currency, method, customer_reference, metadata) -> ChargeResult:
        reference = f"sandbox_{uuid.uuid4().hex[:12]}"
        if metadata.get("force_failure"):
            return ChargeResult(success=False, provider_reference=reference, status="Failed", raw_response={})
        return ChargeResult(success=True, provider_reference=reference, status="Successful", raw_response={})

    def refund(self, *, provider_reference, amount, reason) -> RefundResult:
        reference = f"sandbox_refund_{uuid.uuid4().hex[:12]}"
        return RefundResult(success=True, provider_reference=reference, status="Successful", raw_response={})

    def verify_webhook(self, *, headers, body) -> bool:
        return True  # sandbox has no real signature to verify
