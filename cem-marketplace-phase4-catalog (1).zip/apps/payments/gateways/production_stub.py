"""
Placeholder for the real provider integration (Paystack, MTN Mobile Money,
etc.). Intentionally raises until a real implementation is written and
wired in — this satisfies "do not hard-code fake payment success into
production code": there is no silent fallback to sandbox behavior here.
"""
from .base import PaymentGatewayService, ChargeResult, RefundResult


class ProductionGatewayNotConfiguredError(RuntimeError):
    pass


class ProductionGatewayStub(PaymentGatewayService):
    def charge(self, *, amount, currency, method, customer_reference, metadata) -> ChargeResult:
        raise ProductionGatewayNotConfiguredError(
            "No production payment provider is wired in yet. "
            "Implement this class against your chosen provider's API before deploying."
        )

    def refund(self, *, provider_reference, amount, reason) -> RefundResult:
        raise ProductionGatewayNotConfiguredError("Production refund path not yet implemented.")

    def verify_webhook(self, *, headers, body) -> bool:
        raise ProductionGatewayNotConfiguredError("Production webhook verification not yet implemented.")
