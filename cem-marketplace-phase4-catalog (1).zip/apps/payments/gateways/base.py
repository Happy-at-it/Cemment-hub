"""
PaymentGatewayService interface. Every real provider (Paystack, MTN MoMo,
Stripe, etc.) implements this same interface, so the rest of the codebase
never talks to a specific provider directly — it only talks to whatever
`get_gateway()` returns, selected by the PAYMENT_PROVIDER env var.

This is the "isolate external services behind a service/interface layer"
pattern required by the spec: swapping providers means writing a new class
here, not touching orders/checkout/views code anywhere else.
"""
from abc import ABC, abstractmethod
from dataclasses import dataclass


@dataclass
class ChargeResult:
    success: bool
    provider_reference: str
    status: str          # 'Successful' | 'Failed' | 'Processing'
    raw_response: dict


@dataclass
class RefundResult:
    success: bool
    provider_reference: str
    status: str
    raw_response: dict


class PaymentGatewayService(ABC):
    @abstractmethod
    def charge(self, *, amount, currency: str, method: str, customer_reference: str, metadata: dict) -> ChargeResult:
        ...

    @abstractmethod
    def refund(self, *, provider_reference: str, amount, reason: str) -> RefundResult:
        ...

    @abstractmethod
    def verify_webhook(self, *, headers: dict, body: bytes) -> bool:
        """Verifies a provider's webhook signature before trusting its payload."""
        ...
