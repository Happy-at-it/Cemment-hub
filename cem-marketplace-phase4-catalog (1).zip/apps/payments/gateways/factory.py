from decouple import config
from .sandbox import SandboxGateway
from .production_stub import ProductionGatewayStub


def get_gateway():
    provider = config("PAYMENT_PROVIDER", default="sandbox")
    if provider == "sandbox":
        return SandboxGateway()
    return ProductionGatewayStub()  # replace with real provider classes as they're implemented
