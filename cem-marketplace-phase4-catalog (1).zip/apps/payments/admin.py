from django.contrib import admin
from .models import Payment, PaymentTransaction


class PaymentTransactionInline(admin.TabularInline):
    model = PaymentTransaction
    extra = 0
    readonly_fields = ("transaction_type", "amount", "status", "provider_response_ref", "created_at")


@admin.register(Payment)
class PaymentAdmin(admin.ModelAdmin):
    list_display = ("order", "amount", "method", "status", "provider", "updated_at")
    list_filter = ("status", "method")
    inlines = [PaymentTransactionInline]
