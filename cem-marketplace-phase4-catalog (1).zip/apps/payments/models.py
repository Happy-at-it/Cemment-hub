from django.db import models
from apps.orders.models import Order

STATUS_CHOICES = [
    ("Pending", "Pending"), ("Processing", "Processing"), ("Successful", "Successful"),
    ("Failed", "Failed"), ("Refunded", "Refunded"), ("PartiallyRefunded", "Partially Refunded"),
]

METHOD_CHOICES = [
    ("MobileMoney", "Mobile Money"), ("Card", "Bank Card"), ("BankTransfer", "Bank Transfer"),
]


class Payment(models.Model):
    order = models.OneToOneField(Order, on_delete=models.PROTECT, related_name="payment")
    amount = models.DecimalField(max_digits=12, decimal_places=2)
    method = models.CharField(max_length=30, choices=METHOD_CHOICES)
    # Never raw card data — providers return a token/reference we store instead.
    provider = models.CharField(max_length=50, blank=True, null=True)
    provider_reference = models.CharField(max_length=100, blank=True, null=True)
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default="Pending")
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        db_table = "Payments"

    def __str__(self):
        return f"Payment for {self.order.order_number} — {self.status}"


class PaymentTransaction(models.Model):
    CHARGE, REFUND = "Charge", "Refund"
    TYPE_CHOICES = [(CHARGE, "Charge"), (REFUND, "Refund")]

    payment = models.ForeignKey(Payment, on_delete=models.CASCADE, related_name="transactions")
    transaction_type = models.CharField(max_length=20, choices=TYPE_CHOICES)
    amount = models.DecimalField(max_digits=12, decimal_places=2)
    status = models.CharField(max_length=20, choices=STATUS_CHOICES)
    provider_response_ref = models.CharField(max_length=255, blank=True, null=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = "PaymentTransactions"
        indexes = [models.Index(fields=["payment"], name="ix_paytxn_payment")]

    def __str__(self):
        return f"{self.transaction_type} {self.amount} ({self.status})"
