"""
Payment orchestration: initiate/verify charges, prevent duplicate
payments, apply results back onto Order/Payment records.
"""
from django.core.exceptions import ValidationError
from django.db import transaction

from apps.audit import services as audit
from apps.notifications.services import notify
from apps.orders.models import Order
from apps.orders.state_machine import transition
from .gateways.factory import get_gateway
from .models import Payment, PaymentTransaction


class DuplicatePaymentError(ValidationError):
    pass


@transaction.atomic
def initiate_payment(order: Order, method: str):
    existing = Payment.objects.filter(order=order).first()
    if existing and existing.status == "Successful":
        raise DuplicatePaymentError(f"Order {order.order_number} has already been paid.")

    payment, _ = Payment.objects.update_or_create(
        order=order, defaults={"amount": order.total_amount, "method": method, "status": "Processing"},
    )

    gateway = get_gateway()
    result = gateway.charge(
        amount=order.total_amount, currency="GHS", method=method,
        customer_reference=str(order.customer_profile.user_id),
        metadata={"order_number": order.order_number},
    )

    payment.status = result.status
    payment.provider_reference = result.provider_reference
    payment.save(update_fields=["status", "provider_reference", "updated_at"])

    PaymentTransaction.objects.create(
        payment=payment, transaction_type=PaymentTransaction.CHARGE,
        amount=order.total_amount, status=result.status,
        provider_response_ref=result.provider_reference,
    )

    if result.success:
        order.payment_status = Order.PAYMENT_SUCCESSFUL
        order.save(update_fields=["payment_status", "updated_at"])
        transition(order, Order.PAYMENT_CONFIRMED, changed_by=order.customer_profile.user)
        transition(order, Order.RETAILER_CONFIRMATION_PENDING, changed_by=order.customer_profile.user)
        notify(order.customer_profile.user, event_type="PaymentSuccessful",
               title="Payment successful", message=f"Payment for {order.order_number} was successful.")
        notify(order.retailer_profile.user, event_type="PaymentConfirmed",
               title="Payment confirmed", message=f"Payment received for order {order.order_number}.")
    else:
        order.payment_status = Order.PAYMENT_FAILED
        order.save(update_fields=["payment_status", "updated_at"])
        notify(order.customer_profile.user, event_type="PaymentFailed",
               title="Payment failed", message="Payment could not be completed. Please try again.")

    audit.log(
        user=order.customer_profile.user, action="PaymentAttempted", entity_type="Order", entity_id=order.id,
        new_value={"status": result.status, "provider_reference": result.provider_reference},
    )
    return payment


@transaction.atomic
def refund_payment(payment: Payment, amount, reason: str, acting_admin):
    gateway = get_gateway()
    result = gateway.refund(provider_reference=payment.provider_reference, amount=amount, reason=reason)

    PaymentTransaction.objects.create(
        payment=payment, transaction_type=PaymentTransaction.REFUND,
        amount=amount, status=result.status, provider_response_ref=result.provider_reference,
    )

    if result.success:
        full_refund = amount >= payment.amount
        payment.status = "Refunded" if full_refund else "PartiallyRefunded"
        payment.save(update_fields=["status", "updated_at"])

        order = payment.order
        order.payment_status = payment.status
        order.save(update_fields=["payment_status", "updated_at"])

        notify(order.customer_profile.user, event_type="Refund",
               title="Refund processed", message=f"A refund of {amount} was issued for {order.order_number}.")

    audit.log(
        user=acting_admin, action="Refund", entity_type="Payment", entity_id=payment.id,
        new_value={"amount": str(amount), "reason": reason, "status": result.status},
    )
    return payment
