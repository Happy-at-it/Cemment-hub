from django.contrib import admin
from .models import RetailerProfile, RetailerDocument


class RetailerDocumentInline(admin.TabularInline):
    model = RetailerDocument
    extra = 0


@admin.register(RetailerProfile)
class RetailerProfileAdmin(admin.ModelAdmin):
    list_display = ("business_name", "owner_name", "status", "rating_average", "created_at")
    list_filter = ("status", "delivery_available", "pickup_available")
    search_fields = ("business_name", "owner_name")
    inlines = [RetailerDocumentInline]
    actions = ["approve_retailers", "suspend_retailers"]

    @admin.action(description="Approve selected retailers")
    def approve_retailers(self, request, queryset):
        from .services import approve_retailer
        for retailer in queryset:
            approve_retailer(retailer, acting_admin=request.user)

    @admin.action(description="Suspend selected retailers")
    def suspend_retailers(self, request, queryset):
        from .services import suspend_retailer
        for retailer in queryset:
            suspend_retailer(retailer, acting_admin=request.user, reason="Suspended via admin bulk action")
