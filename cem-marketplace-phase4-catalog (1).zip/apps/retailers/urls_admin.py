from django.urls import path
from .admin_views import AdminRetailerListView, AdminRetailerVerifyView

# Mounted at /api/v1/admin/ by config/urls.py.
urlpatterns = [
    path("retailers/", AdminRetailerListView.as_view(), name="admin-retailer-list"),
    path("retailers/<int:pk>/verify/", AdminRetailerVerifyView.as_view(), name="admin-retailer-verify"),
]
