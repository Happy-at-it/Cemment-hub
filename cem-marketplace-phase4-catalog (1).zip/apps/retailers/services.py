"""Service layer for retailer lifecycle — kept out of views/admin so the
same logic runs whether triggered from the REST API or the Django admin,
and so it's independently testable."""
from django.utils import timezone

from apps.audit import services as audit
from apps.notifications.services import notify
from .models import RetailerProfile


def submit_registration(user, **profile_fields):
    """Creates a RetailerProfile in Pending status. Selling is blocked
    until an admin approves it — enforced by RetailerProfile.is_sellable()
    everywhere product/order creation is checked."""
    retailer = RetailerProfile.objects.create(user=user, status=RetailerProfile.PENDING, **profile_fields)
    audit.log(user=user, action="RetailerRegistered", entity_type="RetailerProfile", entity_id=retailer.id)
    return retailer


def approve_retailer(retailer: RetailerProfile, acting_admin):
    previous_status = retailer.status
    retailer.status = RetailerProfile.APPROVED
    retailer.updated_at = timezone.now()
    retailer.save(update_fields=["status", "updated_at"])

    audit.log(
        user=acting_admin, action="RetailerApproved", entity_type="RetailerProfile",
        entity_id=retailer.id, previous_value={"status": previous_status},
        new_value={"status": retailer.status},
    )
    notify(retailer.user, event_type="RetailerApproved",
           title="Your store is approved!",
           message="Your retailer account has been verified. You can now list products and start selling.")
    return retailer


def reject_retailer(retailer: RetailerProfile, acting_admin, reason: str):
    previous_status = retailer.status
    retailer.status = RetailerProfile.REJECTED
    retailer.save(update_fields=["status", "updated_at"])

    audit.log(
        user=acting_admin, action="RetailerRejected", entity_type="RetailerProfile",
        entity_id=retailer.id, previous_value={"status": previous_status},
        new_value={"status": retailer.status, "reason": reason},
    )
    notify(retailer.user, event_type="RetailerRejected",
           title="Registration not approved",
           message=f"Your retailer application was not approved. Reason: {reason}")
    return retailer


def suspend_retailer(retailer: RetailerProfile, acting_admin, reason: str):
    previous_status = retailer.status
    retailer.status = RetailerProfile.SUSPENDED
    retailer.save(update_fields=["status", "updated_at"])

    audit.log(
        user=acting_admin, action="RetailerSuspended", entity_type="RetailerProfile",
        entity_id=retailer.id, previous_value={"status": previous_status},
        new_value={"status": retailer.status, "reason": reason},
    )
    notify(retailer.user, event_type="RetailerSuspended",
           title="Your store has been suspended",
           message=f"Reason: {reason}. Contact support for details.")
    return retailer
