from django.shortcuts import get_object_or_404
from rest_framework import generics, status
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.views import APIView

from apps.common.permissions import IsAdminRole
from .models import RetailerProfile
from .serializers import RetailerOwnProfileSerializer, RetailerAdminActionSerializer
from .services import approve_retailer, reject_retailer, suspend_retailer


class AdminRetailerListView(generics.ListAPIView):
    """GET /api/v1/admin/retailers/?status=Pending
    Admin-only. Defaults to Pending so the verification queue is the
    natural landing view; pass ?status=Approved etc. to see others."""
    serializer_class = RetailerOwnProfileSerializer
    permission_classes = [IsAuthenticated, IsAdminRole]

    def get_queryset(self):
        status_filter = self.request.query_params.get("status", RetailerProfile.PENDING)
        qs = RetailerProfile.objects.select_related("business_address").prefetch_related("documents")
        if status_filter:
            qs = qs.filter(status=status_filter)
        return qs.order_by("-created_at")


class AdminRetailerVerifyView(APIView):
    """PATCH /api/v1/admin/retailers/{id}/verify/  { "action": "approve"|"reject"|"suspend", "reason": "..." }
    Admin-only. This is the single endpoint that drives the whole
    Pending -> Approved/Rejected/Suspended lifecycle — it delegates to the
    same service functions the Django admin's bulk actions call, so
    behavior (notifications, audit logging) is identical either way."""
    permission_classes = [IsAuthenticated, IsAdminRole]

    ACTIONS = {"approve", "reject", "suspend"}

    def patch(self, request, pk):
        retailer = get_object_or_404(RetailerProfile, pk=pk)
        action = request.data.get("action")
        if action not in self.ACTIONS:
            return Response(
                {"error": {"code": "INVALID_ACTION", "message": f"action must be one of {sorted(self.ACTIONS)}."}},
                status=status.HTTP_400_BAD_REQUEST,
            )

        serializer = RetailerAdminActionSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        reason = serializer.validated_data.get("reason", "")

        if action == "approve":
            retailer = approve_retailer(retailer, acting_admin=request.user)
        elif action == "reject":
            if not reason:
                return Response(
                    {"error": {"code": "REASON_REQUIRED", "message": "A reason is required to reject a retailer."}},
                    status=status.HTTP_400_BAD_REQUEST,
                )
            retailer = reject_retailer(retailer, acting_admin=request.user, reason=reason)
        elif action == "suspend":
            if not reason:
                return Response(
                    {"error": {"code": "REASON_REQUIRED", "message": "A reason is required to suspend a retailer."}},
                    status=status.HTTP_400_BAD_REQUEST,
                )
            retailer = suspend_retailer(retailer, acting_admin=request.user, reason=reason)

        return Response(RetailerOwnProfileSerializer(retailer).data)
