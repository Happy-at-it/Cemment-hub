from rest_framework import serializers

from apps.users.serializers import AddressSerializer
from apps.users.models import Address
from .models import RetailerProfile, RetailerDocument


class RetailerDocumentSerializer(serializers.ModelSerializer):
    class Meta:
        model = RetailerDocument
        fields = ["id", "document_type", "file", "status", "uploaded_at"]
        read_only_fields = ["id", "status", "uploaded_at"]


class RetailerRegistrationSerializer(serializers.Serializer):
    """POST /api/v1/retailers/register/
    Creates the RetailerProfile in Pending status plus its business
    address. Documents are uploaded separately (one call per file) via
    RetailerDocumentUploadView, since a registration may include a
    variable number of files (registration cert, owner ID, etc.)."""

    business_name = serializers.CharField(max_length=200)
    owner_name = serializers.CharField(max_length=150)
    business_registration_no = serializers.CharField(max_length=100, required=False, allow_blank=True)
    settlement_account_info = serializers.CharField(max_length=255, required=False, allow_blank=True)
    opening_hours = serializers.CharField(max_length=255, required=False, allow_blank=True)
    description = serializers.CharField(max_length=1000, required=False, allow_blank=True)
    delivery_available = serializers.BooleanField(default=False)
    pickup_available = serializers.BooleanField(default=True)
    store_latitude = serializers.DecimalField(max_digits=9, decimal_places=6, required=False, allow_null=True)
    store_longitude = serializers.DecimalField(max_digits=9, decimal_places=6, required=False, allow_null=True)

    # Business address, nested — a retailer must have exactly one at registration.
    address_line1 = serializers.CharField(max_length=255)
    address_line2 = serializers.CharField(max_length=255, required=False, allow_blank=True)
    address_city = serializers.CharField(max_length=100)
    address_region = serializers.CharField(max_length=100)

    def validate(self, attrs):
        user = self.context["request"].user
        if hasattr(user, "retailer_profile"):
            raise serializers.ValidationError("This account already has a retailer profile.")
        if user.role.role_name != "Retailer":
            raise serializers.ValidationError("Only accounts registered with role=Retailer can submit this form.")
        return attrs

    def create(self, validated_data):
        from .services import submit_registration
        user = self.context["request"].user

        address = Address.objects.create(
            user=user, label="Business address",
            line1=validated_data["address_line1"],
            line2=validated_data.get("address_line2", ""),
            city=validated_data["address_city"],
            region=validated_data["address_region"],
        )

        retailer = submit_registration(
            user=user,
            business_name=validated_data["business_name"],
            owner_name=validated_data["owner_name"],
            business_address=address,
            business_registration_no=validated_data.get("business_registration_no", ""),
            settlement_account_info=validated_data.get("settlement_account_info", ""),
            opening_hours=validated_data.get("opening_hours", ""),
            description=validated_data.get("description", ""),
            delivery_available=validated_data.get("delivery_available", False),
            pickup_available=validated_data.get("pickup_available", True),
            store_latitude=validated_data.get("store_latitude"),
            store_longitude=validated_data.get("store_longitude"),
        )
        return retailer


class RetailerPublicSerializer(serializers.ModelSerializer):
    """What a customer sees in the directory / storefront — no settlement
    info, no raw document data, nothing internal."""
    city = serializers.CharField(source="business_address.city", read_only=True)

    class Meta:
        model = RetailerProfile
        fields = ["id", "business_name", "city", "opening_hours", "delivery_available",
                  "pickup_available", "description", "status", "rating_average",
                  "completed_orders_count", "store_latitude", "store_longitude"]


class RetailerOwnProfileSerializer(serializers.ModelSerializer):
    """What the retailer sees/edits about their own profile. Status,
    rating, and completed-order-count are read-only — those only change
    through the admin verification workflow or order completion, never a
    direct PATCH from the retailer."""
    business_address = AddressSerializer(read_only=True)
    documents = RetailerDocumentSerializer(many=True, read_only=True)

    class Meta:
        model = RetailerProfile
        fields = ["id", "business_name", "owner_name", "business_address", "opening_hours",
                  "delivery_available", "pickup_available", "description", "status",
                  "rating_average", "completed_orders_count", "store_latitude", "store_longitude",
                  "documents"]
        read_only_fields = ["id", "status", "rating_average", "completed_orders_count",
                             "business_address", "documents"]


class RetailerAdminActionSerializer(serializers.Serializer):
    reason = serializers.CharField(max_length=255, required=False, allow_blank=True)
