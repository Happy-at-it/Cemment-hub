from datetime import date, timedelta

from django.db.models import Sum, Count, Q
from django.http import Http404
from django.shortcuts import get_object_or_404
from rest_framework import generics, status
from rest_framework.exceptions import PermissionDenied
from rest_framework.parsers import MultiPartParser, FormParser
from rest_framework.permissions import AllowAny, IsAuthenticated
from rest_framework.response import Response
from rest_framework.views import APIView

from apps.audit import services as audit
from apps.common.permissions import IsRetailer
from .models import RetailerProfile, RetailerDocument
from .serializers import (
    RetailerRegistrationSerializer, RetailerDocumentSerializer,
    RetailerPublicSerializer, RetailerOwnProfileSerializer,
)


class RetailerRegisterView(generics.CreateAPIView):
    """POST /api/v1/retailers/register/
    Requires an authenticated User already created with role=Retailer
    (via /auth/register/). Creates the RetailerProfile in Pending status —
    selling stays blocked until an admin approves it."""
    serializer_class = RetailerRegistrationSerializer
    permission_classes = [IsAuthenticated, IsRetailer]

    def create(self, request, *args, **kwargs):
        serializer = self.get_serializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        retailer = serializer.save()
        return Response(RetailerOwnProfileSerializer(retailer).data, status=status.HTTP_201_CREATED)


class RetailerDocumentUploadView(generics.CreateAPIView):
    """POST /api/v1/retailers/me/documents/  (multipart/form-data)
    One call per document. Only the retailer who owns the profile can
    upload to it, and only while the profile isn't already Approved+locked
    (v1 keeps this simple: always allowed, since re-verification may need
    updated documents even after approval)."""
    serializer_class = RetailerDocumentSerializer
    permission_classes = [IsAuthenticated, IsRetailer]
    parser_classes = [MultiPartParser, FormParser]

    def perform_create(self, serializer):
        retailer_profile = get_object_or_404(RetailerProfile, user=self.request.user)
        document = serializer.save(retailer_profile=retailer_profile)
        audit.log(
            user=self.request.user, action="RetailerDocumentUploaded",
            entity_type="RetailerDocument", entity_id=document.id,
        )


class RetailerDirectoryListView(generics.ListAPIView):
    """GET /api/v1/retailers/
    Public. Only Approved retailers are ever listed here — Pending,
    Rejected and Suspended retailers are invisible to customers, not just
    unsellable."""
    serializer_class = RetailerPublicSerializer
    permission_classes = [AllowAny]

    def get_queryset(self):
        qs = RetailerProfile.objects.filter(status=RetailerProfile.APPROVED).select_related("business_address")
        city = self.request.query_params.get("city")
        if city:
            qs = qs.filter(business_address__city__iexact=city)
        delivery = self.request.query_params.get("delivery")
        if delivery is not None:
            qs = qs.filter(delivery_available=(delivery.lower() == "true"))
        return qs.order_by("-rating_average")


class RetailerStorefrontDetailView(generics.RetrieveAPIView):
    """GET /api/v1/retailers/{id}/
    Public. Returns 404 (not 403) for a non-Approved retailer, so a
    Pending/Suspended/Rejected retailer's existence isn't confirmed to
    an anonymous browser."""
    serializer_class = RetailerPublicSerializer
    permission_classes = [AllowAny]
    queryset = RetailerProfile.objects.filter(status=RetailerProfile.APPROVED)


class MyRetailerProfileView(generics.RetrieveUpdateAPIView):
    """GET/PATCH /api/v1/retailers/me/"""
    serializer_class = RetailerOwnProfileSerializer
    permission_classes = [IsAuthenticated, IsRetailer]

    def get_object(self):
        try:
            return self.request.user.retailer_profile
        except RetailerProfile.DoesNotExist:
            raise Http404("No retailer profile yet — submit /retailers/register/ first.")

    def perform_update(self, serializer):
        instance = serializer.instance
        before = {"delivery_available": instance.delivery_available, "opening_hours": instance.opening_hours}
        updated = serializer.save()
        audit.log(
            user=self.request.user, action="RetailerProfileUpdated",
            entity_type="RetailerProfile", entity_id=updated.id,
            previous_value=before,
            new_value={"delivery_available": updated.delivery_available, "opening_hours": updated.opening_hours},
        )


class RetailerDashboardView(APIView):
    """GET /api/v1/retailers/me/dashboard/
    Aggregated sales/orders/inventory snapshot, per the spec's retailer
    dashboard requirement. Reads Order/Inventory/Settlement models
    directly — this view has no write path."""
    permission_classes = [IsAuthenticated, IsRetailer]

    def get(self, request):
        from apps.orders.models import Order
        from apps.inventory.models import Inventory
        from apps.commission.models import Settlement

        retailer = get_object_or_404(RetailerProfile, user=request.user)
        today = date.today()
        thirty_days_ago = today - timedelta(days=30)

        orders_qs = Order.objects.filter(retailer_profile=retailer)
        total_sales = orders_qs.filter(order_status=Order.COMPLETED).aggregate(s=Sum("total_amount"))["s"] or 0
        today_sales = orders_qs.filter(
            order_status=Order.COMPLETED, placed_at__date=today
        ).aggregate(s=Sum("total_amount"))["s"] or 0

        counts = orders_qs.aggregate(
            pending=Count("id", filter=Q(order_status__in=[
                Order.ORDER_PLACED, Order.PAYMENT_PENDING_STATUS, Order.PAYMENT_CONFIRMED,
                Order.RETAILER_CONFIRMATION_PENDING, Order.CONFIRMED, Order.PREPARING,
            ])),
            completed=Count("id", filter=Q(order_status=Order.COMPLETED)),
            cancelled=Count("id", filter=Q(order_status=Order.CANCELLED)),
        )

        low_stock_qs = Inventory.objects.filter(product__retailer_profile=retailer).select_related("product")
        low_stock_list = [inv for inv in low_stock_qs if inv.is_low_stock()]

        pending_settlement = Settlement.objects.filter(
            retailer_profile=retailer, status__in=[Settlement.PENDING, Settlement.PROCESSING]
        ).aggregate(s=Sum("net_amount"))["s"] or 0

        recent_customers = list(
            orders_qs.order_by("-placed_at").values_list("customer_profile__full_name", flat=True)[:5]
        )

        # Simple day-by-day sales trend for the last 7 days.
        trend = []
        for i in range(6, -1, -1):
            day = today - timedelta(days=i)
            day_total = orders_qs.filter(
                order_status=Order.COMPLETED, placed_at__date=day
            ).aggregate(s=Sum("total_amount"))["s"] or 0
            trend.append({"date": day.isoformat(), "total": float(day_total)})

        return Response({
            "total_sales_30d": float(total_sales),
            "today_sales": float(today_sales),
            "pending_orders": counts["pending"],
            "completed_orders": counts["completed"],
            "cancelled_orders": counts["cancelled"],
            "low_stock_products": [
                {"product_id": inv.product_id, "name": inv.product.product_name, "quantity": inv.quantity_available}
                for inv in low_stock_list
            ],
            "pending_settlement_amount": float(pending_settlement),
            "recent_customers": recent_customers,
            "sales_trend_7d": trend,
        })


class RetailerPerformanceView(APIView):
    """GET /api/v1/retailers/me/performance/
    Metrics that can later feed marketplace ranking, per the spec."""
    permission_classes = [IsAuthenticated, IsRetailer]

    def get(self, request):
        from apps.orders.models import Order

        retailer = get_object_or_404(RetailerProfile, user=request.user)
        orders_qs = Order.objects.filter(retailer_profile=retailer)
        total = orders_qs.count()
        completed = orders_qs.filter(order_status=Order.COMPLETED).count()
        cancelled = orders_qs.filter(order_status=Order.CANCELLED).count()
        fulfillment_rate = round((completed / total) * 100, 1) if total else 0.0

        repeat_customers = (
            orders_qs.values("customer_profile").annotate(n=Count("id")).filter(n__gt=1).count()
        )

        return Response({
            "total_orders": total,
            "completed_orders": completed,
            "cancelled_orders": cancelled,
            "fulfillment_rate_percent": fulfillment_rate,
            "average_rating": float(retailer.rating_average),
            "repeat_customers": repeat_customers,
        })
