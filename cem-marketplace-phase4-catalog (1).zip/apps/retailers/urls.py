from django.urls import path
from .views import (
    RetailerRegisterView, RetailerDocumentUploadView, RetailerDirectoryListView,
    RetailerStorefrontDetailView, MyRetailerProfileView, RetailerDashboardView,
    RetailerPerformanceView,
)

# Mounted at /api/v1/ by config/urls.py.
urlpatterns = [
    path("retailers/register/", RetailerRegisterView.as_view(), name="retailer-register"),
    path("retailers/me/", MyRetailerProfileView.as_view(), name="retailer-me"),
    path("retailers/me/documents/", RetailerDocumentUploadView.as_view(), name="retailer-me-documents"),
    path("retailers/me/dashboard/", RetailerDashboardView.as_view(), name="retailer-me-dashboard"),
    path("retailers/me/performance/", RetailerPerformanceView.as_view(), name="retailer-me-performance"),
    path("retailers/", RetailerDirectoryListView.as_view(), name="retailer-directory"),
    path("retailers/<int:pk>/", RetailerStorefrontDetailView.as_view(), name="retailer-storefront"),
]
