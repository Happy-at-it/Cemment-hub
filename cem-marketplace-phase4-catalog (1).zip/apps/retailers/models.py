from django.db import models
from apps.users.models import User, Address


class RetailerProfile(models.Model):
    PENDING, UNDER_REVIEW, APPROVED, SUSPENDED, REJECTED = (
        "Pending", "UnderReview", "Approved", "Suspended", "Rejected",
    )
    STATUS_CHOICES = [
        (PENDING, "Pending"),
        (UNDER_REVIEW, "Under Review"),
        (APPROVED, "Approved"),
        (SUSPENDED, "Suspended"),
        (REJECTED, "Rejected"),
    ]

    user = models.OneToOneField(User, on_delete=models.CASCADE, related_name="retailer_profile")
    business_name = models.CharField(max_length=200)
    owner_name = models.CharField(max_length=150)
    business_address = models.ForeignKey(Address, on_delete=models.PROTECT, related_name="+")
    store_latitude = models.DecimalField(max_digits=9, decimal_places=6, null=True, blank=True)
    store_longitude = models.DecimalField(max_digits=9, decimal_places=6, null=True, blank=True)
    business_registration_no = models.CharField(max_length=100, blank=True, null=True)
    # Never raw bank details — this stores a reference/token from the settlement provider.
    settlement_account_info = models.CharField(max_length=255, blank=True, null=True)
    opening_hours = models.CharField(max_length=255, blank=True, null=True)
    delivery_available = models.BooleanField(default=False)
    pickup_available = models.BooleanField(default=True)
    description = models.CharField(max_length=1000, blank=True, null=True)
    logo = models.ImageField(upload_to="retailer_logos/", blank=True, null=True)
    store_image = models.ImageField(upload_to="retailer_stores/", blank=True, null=True)
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default=PENDING)
    rating_average = models.DecimalField(max_digits=3, decimal_places=2, default=0)
    completed_orders_count = models.PositiveIntegerField(default=0)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        db_table = "RetailerProfiles"
        indexes = [models.Index(fields=["status"], name="ix_retailer_status")]

    def __str__(self):
        return self.business_name

    def is_sellable(self):
        """Retailers must be Approved before they can list active products
        or receive orders — checked at the service layer, not just here."""
        return self.status == self.APPROVED


class RetailerDocument(models.Model):
    PENDING, APPROVED, REJECTED = "Pending", "Approved", "Rejected"
    STATUS_CHOICES = [(PENDING, "Pending"), (APPROVED, "Approved"), (REJECTED, "Rejected")]

    retailer_profile = models.ForeignKey(
        RetailerProfile, on_delete=models.CASCADE, related_name="documents"
    )
    document_type = models.CharField(max_length=50)  # e.g. 'BusinessRegistration', 'OwnerID'
    file = models.FileField(upload_to="retailer_documents/")
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default=PENDING)
    uploaded_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = "RetailerDocuments"

    def __str__(self):
        return f"{self.document_type} — {self.retailer_profile.business_name}"
