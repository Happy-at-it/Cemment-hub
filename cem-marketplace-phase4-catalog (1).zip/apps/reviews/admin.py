from django.contrib import admin
from .models import Review


@admin.register(Review)
class ReviewAdmin(admin.ModelAdmin):
    list_display = ("order", "review_type", "rating", "status", "created_at")
    list_filter = ("review_type", "status")
    actions = ["hide_reviews", "flag_reviews"]

    @admin.action(description="Hide selected reviews")
    def hide_reviews(self, request, queryset):
        from .services import moderate_review
        for review in queryset:
            moderate_review(review, Review.HIDDEN, acting_admin=request.user)

    @admin.action(description="Flag selected reviews")
    def flag_reviews(self, request, queryset):
        from .services import moderate_review
        for review in queryset:
            moderate_review(review, Review.FLAGGED, acting_admin=request.user)
