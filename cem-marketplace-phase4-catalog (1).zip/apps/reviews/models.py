from django.db import models
from apps.users.models import CustomerProfile
from apps.orders.models import Order
from apps.retailers.models import RetailerProfile
from apps.catalog.models import Product
from apps.delivery.models import Delivery


class Review(models.Model):
    RETAILER, PRODUCT, DELIVERY = "Retailer", "Product", "Delivery"
    TYPE_CHOICES = [(RETAILER, "Retailer"), (PRODUCT, "Product"), (DELIVERY, "Delivery")]

    VISIBLE, HIDDEN, FLAGGED = "Visible", "Hidden", "Flagged"
    STATUS_CHOICES = [(VISIBLE, "Visible"), (HIDDEN, "Hidden"), (FLAGGED, "Flagged")]

    order = models.ForeignKey(Order, on_delete=models.CASCADE, related_name="reviews")
    customer_profile = models.ForeignKey(CustomerProfile, on_delete=models.CASCADE, related_name="reviews")
    review_type = models.CharField(max_length=20, choices=TYPE_CHOICES)
    retailer_profile = models.ForeignKey(
        RetailerProfile, on_delete=models.CASCADE, null=True, blank=True, related_name="reviews"
    )
    product = models.ForeignKey(Product, on_delete=models.CASCADE, null=True, blank=True, related_name="reviews")
    delivery = models.ForeignKey(Delivery, on_delete=models.CASCADE, null=True, blank=True, related_name="reviews")
    rating = models.PositiveSmallIntegerField()
    comment = models.CharField(max_length=1000, blank=True, null=True)
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default=VISIBLE)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = "Reviews"
        indexes = [
            models.Index(fields=["retailer_profile"], name="ix_reviews_retailer"),
            models.Index(fields=["product"], name="ix_reviews_product"),
        ]
        constraints = [
            models.CheckConstraint(check=models.Q(rating__gte=1) & models.Q(rating__lte=5), name="ck_review_rating_range"),
        ]

    def __str__(self):
        return f"{self.review_type} review — {self.rating}/5"
