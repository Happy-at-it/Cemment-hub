"""Only verified purchasers may review, and a review's rating average on
the target (retailer/product) is recalculated after every new review."""
from decimal import Decimal
from django.core.exceptions import ValidationError, PermissionDenied
from django.db import transaction
from django.db.models import Avg

from apps.orders.models import Order
from .models import Review


class NotAVerifiedPurchaseError(PermissionDenied):
    pass


@transaction.atomic
def submit_review(customer_profile, order: Order, review_type, rating, comment="",
                   retailer_profile=None, product=None, delivery=None):
    if order.customer_profile_id != customer_profile.id:
        raise NotAVerifiedPurchaseError("You can only review orders you placed.")
    if order.order_status != Order.COMPLETED:
        raise ValidationError("You can only review completed orders.")

    review = Review.objects.create(
        order=order, customer_profile=customer_profile, review_type=review_type, rating=rating,
        comment=comment, retailer_profile=retailer_profile, product=product, delivery=delivery,
    )

    if review_type == Review.RETAILER and retailer_profile:
        _recalculate_retailer_rating(retailer_profile)

    return review


def _recalculate_retailer_rating(retailer_profile):
    avg = Review.objects.filter(
        retailer_profile=retailer_profile, review_type=Review.RETAILER, status=Review.VISIBLE
    ).aggregate(avg=Avg("rating"))["avg"] or Decimal("0")
    retailer_profile.rating_average = round(Decimal(avg), 2)
    retailer_profile.save(update_fields=["rating_average"])


def moderate_review(review: Review, new_status: str, acting_admin):
    from apps.audit import services as audit
    previous = review.status
    review.status = new_status
    review.save(update_fields=["status"])
    if review.review_type == Review.RETAILER and review.retailer_profile:
        _recalculate_retailer_rating(review.retailer_profile)
    audit.log(
        user=acting_admin, action="ReviewModerated", entity_type="Review", entity_id=review.id,
        previous_value={"status": previous}, new_value={"status": new_status},
    )
    return review
