class TimestampedModel:
    """Documented convention (not a concrete abstract base to keep MSSQL
    column ordering predictable per app) — every model below defines its
    own created_at/updated_at following this same pattern:

        created_at = models.DateTimeField(auto_now_add=True)
        updated_at = models.DateTimeField(auto_now=True)
    """
    pass
