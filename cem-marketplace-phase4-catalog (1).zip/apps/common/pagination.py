from rest_framework.pagination import PageNumberPagination


class StandardResultsPagination(PageNumberPagination):
    """Every list endpoint uses this — no unbounded querysets are ever
    returned to a client, per the performance requirement."""
    page_size = 20
    page_size_query_param = "page_size"
    max_page_size = 100
