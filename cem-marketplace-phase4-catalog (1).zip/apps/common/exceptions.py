from rest_framework.views import exception_handler


def consistent_error_handler(exc, context):
    """Wraps every DRF error response into the shape the API spec promises:
    { "error": { "code": "...", "message": "..." } }
    Technical detail (stack traces, DB errors) is never exposed to the
    client — it is logged server-side by Django's logging config instead.
    """
    response = exception_handler(exc, context)
    if response is None:
        return None

    detail = response.data
    code = getattr(exc, "default_code", exc.__class__.__name__.upper())

    if isinstance(detail, dict) and "detail" in detail:
        message = str(detail["detail"])
    elif isinstance(detail, list):
        message = "; ".join(str(d) for d in detail)
    else:
        message = str(detail)

    response.data = {"error": {"code": code, "message": message}}
    return response
