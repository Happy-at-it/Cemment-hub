"""
Shared DRF permission classes. Every domain app composes these rather than
re-implementing ownership checks, so the "customers can't see retailer data,
retailers only see their own data, drivers only see assigned deliveries"
rule is enforced in one place and can't drift between apps.
"""
from rest_framework.permissions import BasePermission


class IsRole(BasePermission):
    """Base class: subclass and set `role_name`."""
    role_name = None

    def has_permission(self, request, view):
        return bool(
            request.user
            and request.user.is_authenticated
            and request.user.role.role_name == self.role_name
        )


class IsCustomer(IsRole):
    role_name = "Customer"


class IsRetailer(IsRole):
    role_name = "Retailer"


class IsDriver(IsRole):
    role_name = "Driver"


class IsAdminRole(IsRole):
    role_name = "Admin"


class IsRetailerOwner(BasePermission):
    """Object-level: the retailer making the request owns this object.
    Assumes the object exposes `.retailer_profile` (directly or via a
    `get_retailer_profile()` method) that resolves to a RetailerProfile."""

    def has_object_permission(self, request, view, obj):
        retailer_profile = getattr(obj, "retailer_profile", None) or getattr(
            obj, "get_retailer_profile", lambda: None
        )()
        return bool(
            retailer_profile is not None
            and retailer_profile.user_id == request.user.id
        )


class IsOwner(BasePermission):
    """Generic: obj.user_id (or obj.customer_profile.user_id) must match
    the requesting user."""

    def has_object_permission(self, request, view, obj):
        user_id = getattr(obj, "user_id", None)
        if user_id is None:
            customer_profile = getattr(obj, "customer_profile", None)
            user_id = customer_profile.user_id if customer_profile else None
        return user_id == request.user.id


class IsAssignedDriver(BasePermission):
    def has_object_permission(self, request, view, obj):
        driver_profile = getattr(obj, "driver_profile", None)
        return bool(
            driver_profile is not None and driver_profile.user_id == request.user.id
        )
