from django.db.models import Q
from rest_framework import generics
from rest_framework.permissions import AllowAny
from rest_framework.response import Response
from rest_framework.views import APIView

from apps.retailers.models import RetailerProfile
from .models import Category, Brand, Product
from .serializers import CategorySerializer, BrandSerializer, ProductPublicSerializer


class CategoryListView(generics.ListAPIView):
    """GET /api/v1/categories/
    Public. Returns the full tree flattened (parent_category on each row
    lets the client build the tree) — only 'Cement' and its subcategories
    exist today, but this scales to Blocks/Iron Rods/Sand/etc. without an
    endpoint change."""
    serializer_class = CategorySerializer
    permission_classes = [AllowAny]
    queryset = Category.objects.filter(is_active=True).order_by("name")


class BrandListView(generics.ListAPIView):
    """GET /api/v1/brands/"""
    serializer_class = BrandSerializer
    permission_classes = [AllowAny]
    queryset = Brand.objects.filter(is_active=True).order_by("name")


class ProductSearchView(generics.ListAPIView):
    """GET /api/v1/products/
    Public search/filter, per the spec's discovery requirements. Only
    products from Approved retailers with Active availability are ever
    returned — a suspended retailer's listings disappear from search
    immediately, without deleting the underlying rows.

    Query params: q, brand, category, min_price, max_price, retailer,
    in_stock (true/false), rating_min
    """
    serializer_class = ProductPublicSerializer
    permission_classes = [AllowAny]

    def get_queryset(self):
        qs = Product.objects.filter(
            availability_status=Product.ACTIVE,
            retailer_profile__status=RetailerProfile.APPROVED,
        ).select_related("brand", "category", "retailer_profile", "retailer_profile__business_address", "inventory")

        params = self.request.query_params
        q = params.get("q")
        if q:
            qs = qs.filter(Q(product_name__icontains=q) | Q(brand__name__icontains=q) | Q(cement_type__icontains=q))
        brand = params.get("brand")
        if brand:
            qs = qs.filter(brand__name__iexact=brand)
        category = params.get("category")
        if category:
            qs = qs.filter(category__slug=category)
        retailer = params.get("retailer")
        if retailer:
            qs = qs.filter(retailer_profile_id=retailer)
        min_price = params.get("min_price")
        if min_price:
            qs = qs.filter(price_per_unit__gte=min_price)
        max_price = params.get("max_price")
        if max_price:
            qs = qs.filter(price_per_unit__lte=max_price)
        rating_min = params.get("rating_min")
        if rating_min:
            qs = qs.filter(retailer_profile__rating_average__gte=rating_min)
        in_stock = params.get("in_stock")
        if in_stock is not None:
            if in_stock.lower() == "true":
                qs = qs.filter(inventory__quantity_available__gt=0)
            else:
                qs = qs.filter(inventory__quantity_available=0)

        return qs.order_by("-retailer_profile__rating_average", "price_per_unit")


class ProductDetailView(generics.RetrieveAPIView):
    """GET /api/v1/products/{id}/"""
    serializer_class = ProductPublicSerializer
    permission_classes = [AllowAny]
    queryset = Product.objects.filter(
        availability_status=Product.ACTIVE, retailer_profile__status=RetailerProfile.APPROVED
    ).select_related("brand", "category", "retailer_profile", "retailer_profile__business_address", "inventory")


class ProductCompareView(APIView):
    """GET /api/v1/products/compare/?brand=Ghacem&category=cement&lat=&lng=
    Same brand/category across every retailer that stocks it, so the
    customer can compare price, stock, distance and rating side by side —
    per the spec's price-comparison requirement. Never ranks by price
    alone: results are returned with all four factors and it's left to
    the client to sort/display; sponsored listings carry `is_sponsored`
    (v1: always False — sponsorship isn't implemented yet, but the field
    exists so the frontend contract doesn't change when it is) so they
    can always be labelled rather than silently reordered above a better
    match."""
    permission_classes = [AllowAny]

    def get(self, request):
        brand = request.query_params.get("brand")
        category = request.query_params.get("category")
        if not brand and not category:
            return Response(
                {"error": {"code": "MISSING_PARAM", "message": "Provide at least a brand or category to compare."}},
                status=400,
            )

        qs = Product.objects.filter(
            availability_status=Product.ACTIVE, retailer_profile__status=RetailerProfile.APPROVED,
        ).select_related("brand", "category", "retailer_profile", "retailer_profile__business_address", "inventory")
        if brand:
            qs = qs.filter(brand__name__iexact=brand)
        if category:
            qs = qs.filter(category__slug=category)

        lat = request.query_params.get("lat")
        lng = request.query_params.get("lng")
        distance_by_product = {}
        if lat and lng:
            from apps.delivery.geo.haversine import HaversineGeoService
            geo = HaversineGeoService()
            for p in qs:
                r = p.retailer_profile
                if r.store_latitude is not None and r.store_longitude is not None:
                    distance_by_product[p.id] = geo.distance_km(lat, lng, r.store_latitude, r.store_longitude)

        results = []
        for p in qs:
            results.append({
                "product_id": p.id,
                "retailer_id": p.retailer_profile_id,
                "retailer_name": p.retailer_profile.business_name,
                "brand": p.brand.name,
                "price_per_unit": str(p.price_per_unit),
                "quantity_available": p.inventory.quantity_available if hasattr(p, "inventory") else 0,
                "distance_km": distance_by_product.get(p.id),
                "retailer_rating": str(p.retailer_profile.rating_average),
                "is_sponsored": False,
            })

        return Response({"count": len(results), "results": results})
