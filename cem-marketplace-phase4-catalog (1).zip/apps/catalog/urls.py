from django.urls import path
from .views import CategoryListView, BrandListView, ProductSearchView, ProductDetailView, ProductCompareView
from .retailer_views import RetailerProductListCreateView, RetailerProductDetailView
from apps.inventory.views import ProductInventoryView, ProductInventoryAdjustView, ProductInventoryHistoryView

# Mounted at /api/v1/ by config/urls.py.
urlpatterns = [
    # Public catalog
    path("categories/", CategoryListView.as_view(), name="category-list"),
    path("brands/", BrandListView.as_view(), name="brand-list"),
    path("products/compare/", ProductCompareView.as_view(), name="product-compare"),
    path("products/<int:pk>/", ProductDetailView.as_view(), name="product-detail"),
    path("products/", ProductSearchView.as_view(), name="product-search"),

    # Retailer product management
    path("retailers/me/products/", RetailerProductListCreateView.as_view(), name="retailer-product-list"),
    path("retailers/me/products/<int:pk>/", RetailerProductDetailView.as_view(), name="retailer-product-detail"),

    # Inventory (nested under a retailer's own product)
    path("retailers/me/products/<int:product_id>/inventory/",
         ProductInventoryView.as_view(), name="product-inventory"),
    path("retailers/me/products/<int:product_id>/inventory/adjust/",
         ProductInventoryAdjustView.as_view(), name="product-inventory-adjust"),
    path("retailers/me/products/<int:product_id>/inventory/history/",
         ProductInventoryHistoryView.as_view(), name="product-inventory-history"),
]
