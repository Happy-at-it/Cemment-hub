from rest_framework import generics
from rest_framework.permissions import IsAuthenticated

from apps.common.permissions import IsRetailer
from .models import Product
from .serializers import RetailerProductSerializer


class RetailerProductListCreateView(generics.ListCreateAPIView):
    """GET/POST /api/v1/retailers/me/products/
    Scoped to the requesting retailer's own products — never trusts a
    client-supplied retailer_id."""
    serializer_class = RetailerProductSerializer
    permission_classes = [IsAuthenticated, IsRetailer]

    def get_queryset(self):
        return Product.objects.filter(
            retailer_profile__user=self.request.user
        ).select_related("inventory", "brand", "category").order_by("-created_at")


class RetailerProductDetailView(generics.RetrieveUpdateDestroyAPIView):
    """PATCH/DELETE /api/v1/retailers/me/products/{id}/
    Queryset scoping (not just object-level permission checking) means a
    retailer requesting another retailer's product id gets a 404, not a
    403 — existence of the other retailer's product isn't confirmed."""
    serializer_class = RetailerProductSerializer
    permission_classes = [IsAuthenticated, IsRetailer]

    def get_queryset(self):
        return Product.objects.filter(retailer_profile__user=self.request.user)

    def perform_destroy(self, instance):
        from apps.audit import services as audit
        # Soft behavior: products with order history should never be hard
        # -deleted (OrderItem snapshots reference them via PROTECT), so a
        # DELETE here just discontinues the listing rather than removing
        # the row — matches the "soft-delete where downstream references
        # exist" convention from the API spec.
        instance.availability_status = Product.DISCONTINUED
        instance.save(update_fields=["availability_status", "updated_at"])
        audit.log(
            user=self.request.user, action="ProductDiscontinued",
            entity_type="Product", entity_id=instance.id,
        )
