from django.db import models
from apps.retailers.models import RetailerProfile


class Category(models.Model):
    """Self-referencing so the catalog can grow from 'Cement' into
    'Blocks', 'Iron Rods', 'Sand', etc. without any schema change —
    this is what satisfies the future product-expansion requirement."""

    name = models.CharField(max_length=100)
    slug = models.SlugField(max_length=120, unique=True)
    parent_category = models.ForeignKey(
        "self", null=True, blank=True, on_delete=models.SET_NULL, related_name="subcategories"
    )
    is_active = models.BooleanField(default=True)

    class Meta:
        db_table = "Categories"
        verbose_name_plural = "Categories"

    def __str__(self):
        return self.name


class Brand(models.Model):
    name = models.CharField(max_length=100, unique=True)
    logo = models.ImageField(upload_to="brand_logos/", blank=True, null=True)
    is_active = models.BooleanField(default=True)

    class Meta:
        db_table = "Brands"

    def __str__(self):
        return self.name


class Product(models.Model):
    ACTIVE, OUT_OF_STOCK, DISCONTINUED = "Active", "OutOfStock", "Discontinued"
    AVAILABILITY_CHOICES = [
        (ACTIVE, "Active"), (OUT_OF_STOCK, "Out of Stock"), (DISCONTINUED, "Discontinued"),
    ]

    retailer_profile = models.ForeignKey(RetailerProfile, on_delete=models.CASCADE, related_name="products")
    category = models.ForeignKey(Category, on_delete=models.PROTECT, related_name="products")
    brand = models.ForeignKey(Brand, on_delete=models.PROTECT, related_name="products")
    product_name = models.CharField(max_length=200)
    # Cement-specific fields are nullable so the same table serves future
    # non-cement categories (blocks, iron rods, ...) without alteration.
    cement_type = models.CharField(max_length=50, blank=True, null=True)   # OPC, PPC...
    strength_class = models.CharField(max_length=20, blank=True, null=True)  # 32.5R, 42.5N...
    bag_weight_kg = models.DecimalField(max_digits=6, decimal_places=2, blank=True, null=True)
    description = models.CharField(max_length=1000, blank=True, null=True)
    image = models.ImageField(upload_to="product_images/", blank=True, null=True)
    price_per_unit = models.DecimalField(max_digits=10, decimal_places=2)
    min_order_quantity = models.PositiveIntegerField(default=1)
    max_order_quantity = models.PositiveIntegerField(blank=True, null=True)
    availability_status = models.CharField(max_length=20, choices=AVAILABILITY_CHOICES, default=ACTIVE)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        db_table = "Products"
        indexes = [
            models.Index(fields=["retailer_profile"], name="ix_products_retailer"),
            models.Index(fields=["category"], name="ix_products_category"),
            models.Index(fields=["brand"], name="ix_products_brand"),
            models.Index(fields=["availability_status"], name="ix_products_availability"),
        ]
        constraints = [
            models.CheckConstraint(
                check=models.Q(price_per_unit__gte=0), name="ck_product_price_nonneg"
            ),
            models.CheckConstraint(
                check=models.Q(max_order_quantity__isnull=True)
                | models.Q(max_order_quantity__gte=models.F("min_order_quantity")),
                name="ck_product_max_gte_min",
            ),
        ]

    def __str__(self):
        return f"{self.brand} {self.product_name} ({self.retailer_profile.business_name})"

    def get_retailer_profile(self):
        """Used by apps.common.permissions.IsRetailerOwner."""
        return self.retailer_profile
