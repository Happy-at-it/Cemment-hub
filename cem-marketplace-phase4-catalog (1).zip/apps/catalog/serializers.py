from rest_framework import serializers

from .models import Category, Brand, Product


class CategorySerializer(serializers.ModelSerializer):
    class Meta:
        model = Category
        fields = ["id", "name", "slug", "parent_category", "is_active"]


class BrandSerializer(serializers.ModelSerializer):
    class Meta:
        model = Brand
        fields = ["id", "name", "logo", "is_active"]


class ProductPublicSerializer(serializers.ModelSerializer):
    """What a customer sees when browsing/searching — includes just
    enough retailer context (name, city, distance-independent fields) to
    render a product card without a second request per item."""
    retailer_id = serializers.IntegerField(source="retailer_profile_id", read_only=True)
    retailer_name = serializers.CharField(source="retailer_profile.business_name", read_only=True)
    retailer_city = serializers.CharField(source="retailer_profile.business_address.city", read_only=True)
    retailer_rating = serializers.DecimalField(
        source="retailer_profile.rating_average", max_digits=3, decimal_places=2, read_only=True
    )
    retailer_verified = serializers.SerializerMethodField()
    brand = BrandSerializer(read_only=True)
    category = CategorySerializer(read_only=True)
    quantity_available = serializers.IntegerField(source="inventory.quantity_available", read_only=True)

    class Meta:
        model = Product
        fields = [
            "id", "product_name", "cement_type", "strength_class", "bag_weight_kg", "description", "image",
            "price_per_unit", "min_order_quantity", "max_order_quantity", "availability_status",
            "brand", "category", "quantity_available",
            "retailer_id", "retailer_name", "retailer_city", "retailer_rating", "retailer_verified",
        ]

    def get_retailer_verified(self, obj):
        return obj.retailer_profile.status == obj.retailer_profile.APPROVED


class RetailerProductSerializer(serializers.ModelSerializer):
    """What a retailer sees/edits for their own product. Accepts an
    `initial_stock` write-only field on create only — stock afterwards is
    managed exclusively through the inventory endpoints, never a product
    PATCH, so every change is logged to InventoryHistory."""
    quantity_available = serializers.IntegerField(source="inventory.quantity_available", read_only=True)
    initial_stock = serializers.IntegerField(write_only=True, required=False, min_value=0, default=0)

    class Meta:
        model = Product
        fields = [
            "id", "category", "brand", "product_name", "cement_type", "strength_class", "bag_weight_kg",
            "description", "image", "price_per_unit", "min_order_quantity", "max_order_quantity",
            "availability_status", "quantity_available", "initial_stock", "created_at", "updated_at",
        ]
        read_only_fields = ["id", "quantity_available", "created_at", "updated_at"]

    def validate(self, attrs):
        min_qty = attrs.get("min_order_quantity", getattr(self.instance, "min_order_quantity", 1))
        max_qty = attrs.get("max_order_quantity", getattr(self.instance, "max_order_quantity", None))
        if max_qty is not None and max_qty < min_qty:
            raise serializers.ValidationError({"max_order_quantity": "Must be greater than or equal to minimum order quantity."})
        return attrs

    def create(self, validated_data):
        from apps.inventory.models import Inventory, InventoryHistory
        from apps.inventory.services import adjust_stock

        initial_stock = validated_data.pop("initial_stock", 0)
        validated_data["retailer_profile"] = self.context["request"].user.retailer_profile
        product = Product.objects.create(**validated_data)
        Inventory.objects.create(product=product, quantity_available=0)
        if initial_stock:
            adjust_stock(product, delta=initial_stock, reason=InventoryHistory.RESTOCK,
                          changed_by=self.context["request"].user)
        return product

    def update(self, instance, validated_data):
        from apps.audit import services as audit
        validated_data.pop("initial_stock", None)  # stock changes never happen via product PATCH
        before = {"price_per_unit": str(instance.price_per_unit), "availability_status": instance.availability_status}
        instance = super().update(instance, validated_data)
        audit.log(
            user=self.context["request"].user, action="ProductUpdated",
            entity_type="Product", entity_id=instance.id, previous_value=before,
            new_value={"price_per_unit": str(instance.price_per_unit), "availability_status": instance.availability_status},
        )
        return instance
