from django.db import models
from apps.users.models import CustomerProfile
from apps.retailers.models import RetailerProfile
from apps.catalog.models import Product


class Cart(models.Model):
    """v1: one active cart per customer, scoped to a single retailer
    (retailer is set on the first item added, cleared when the cart is
    emptied). Multi-retailer carts can be added later by moving the
    retailer reference onto CartItem instead — see docs/03-er-diagram.md."""

    customer_profile = models.OneToOneField(
        CustomerProfile, on_delete=models.CASCADE, related_name="cart"
    )
    retailer_profile = models.ForeignKey(
        RetailerProfile, on_delete=models.SET_NULL, null=True, blank=True, related_name="+"
    )
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        db_table = "Carts"

    def __str__(self):
        return f"Cart({self.customer_profile})"


class CartItem(models.Model):
    cart = models.ForeignKey(Cart, on_delete=models.CASCADE, related_name="items")
    product = models.ForeignKey(Product, on_delete=models.CASCADE, related_name="+")
    quantity = models.PositiveIntegerField()

    class Meta:
        db_table = "CartItems"
        constraints = [
            models.UniqueConstraint(fields=["cart", "product"], name="ux_cartitem_product"),
            models.CheckConstraint(check=models.Q(quantity__gt=0), name="ck_cartitem_qty_positive"),
        ]

    def __str__(self):
        return f"{self.quantity} x {self.product}"

    def line_total(self):
        return self.quantity * self.product.price_per_unit
