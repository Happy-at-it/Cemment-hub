from django.core.exceptions import ValidationError

from .models import Cart, CartItem


class DifferentRetailerError(ValidationError):
    pass


class QuantityOutOfRangeError(ValidationError):
    pass


def get_or_create_cart(customer_profile):
    cart, _ = Cart.objects.get_or_create(customer_profile=customer_profile)
    return cart


def add_item(customer_profile, product, quantity):
    cart = get_or_create_cart(customer_profile)

    if cart.retailer_profile_id and cart.retailer_profile_id != product.retailer_profile_id:
        raise DifferentRetailerError(
            "Your cart already has items from a different retailer. "
            "Checkout or clear your cart before adding items from another store."
        )

    if quantity < product.min_order_quantity:
        raise QuantityOutOfRangeError(f"Minimum order quantity for this product is {product.min_order_quantity}.")
    if product.max_order_quantity and quantity > product.max_order_quantity:
        raise QuantityOutOfRangeError(f"Maximum order quantity for this product is {product.max_order_quantity}.")

    item, created = CartItem.objects.get_or_create(
        cart=cart, product=product, defaults={"quantity": quantity}
    )
    if not created:
        item.quantity += quantity
        item.save(update_fields=["quantity"])

    if not cart.retailer_profile_id:
        cart.retailer_profile = product.retailer_profile
        cart.save(update_fields=["retailer_profile", "updated_at"])

    return item


def remove_item(cart, item_id):
    CartItem.objects.filter(cart=cart, id=item_id).delete()
    if not cart.items.exists():
        cart.retailer_profile = None
        cart.save(update_fields=["retailer_profile", "updated_at"])


def clear_cart(cart):
    cart.items.all().delete()
    cart.retailer_profile = None
    cart.save(update_fields=["retailer_profile", "updated_at"])


def cart_subtotal(cart):
    return sum((item.line_total() for item in cart.items.select_related("product")), start=0)
