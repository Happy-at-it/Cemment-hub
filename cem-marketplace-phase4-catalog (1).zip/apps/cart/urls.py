from django.urls import path

# Built out in a later phase — empty for now so the project boots
# and the Authentication phase can be tested in isolation.
urlpatterns = []
