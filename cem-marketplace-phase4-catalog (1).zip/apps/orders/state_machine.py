"""
Valid order-status transition map. All status changes go through
transition() so illegal jumps (e.g. OrderPlaced -> Delivered) are rejected
server-side regardless of what a client sends.
"""
from django.core.exceptions import ValidationError
from .models import Order as O

# Pickup and delivery orders diverge after 'Preparing'.
VALID_TRANSITIONS = {
    O.ORDER_PLACED: {O.PAYMENT_PENDING_STATUS, O.CANCELLED},
    O.PAYMENT_PENDING_STATUS: {O.PAYMENT_CONFIRMED, O.CANCELLED},
    O.PAYMENT_CONFIRMED: {O.RETAILER_CONFIRMATION_PENDING},
    O.RETAILER_CONFIRMATION_PENDING: {O.CONFIRMED, O.CANCELLED},
    O.CONFIRMED: {O.PREPARING, O.CANCELLED},
    O.PREPARING: {O.READY_FOR_PICKUP, O.DRIVER_ASSIGNED},
    O.READY_FOR_PICKUP: {O.COMPLETED},
    O.DRIVER_ASSIGNED: {O.PICKED_UP},
    O.PICKED_UP: {O.OUT_FOR_DELIVERY},
    O.OUT_FOR_DELIVERY: {O.DELIVERED},
    O.DELIVERED: {O.COMPLETED},
    O.COMPLETED: {O.DISPUTED},
    O.DISPUTED: {O.COMPLETED, O.REFUNDED},
    O.CANCELLED: {O.REFUNDED},
}


class IllegalTransitionError(ValidationError):
    pass


def can_transition(current_status: str, new_status: str) -> bool:
    return new_status in VALID_TRANSITIONS.get(current_status, set())


def transition(order, new_status: str, changed_by=None, note: str = ""):
    from .models import OrderStatusHistory
    from apps.audit import services as audit

    if not can_transition(order.order_status, new_status):
        raise IllegalTransitionError(
            f"Cannot move order from '{order.order_status}' to '{new_status}'."
        )

    previous_status = order.order_status
    order.order_status = new_status
    if new_status == O.COMPLETED:
        from django.utils import timezone
        order.completed_at = timezone.now()
    order.save(update_fields=["order_status", "completed_at", "updated_at"]
               if new_status == O.COMPLETED else ["order_status", "updated_at"])

    OrderStatusHistory.objects.create(order=order, status=new_status, changed_by=changed_by, note=note)
    audit.log(
        user=changed_by, action="OrderStatusChanged", entity_type="Order", entity_id=order.id,
        previous_value={"order_status": previous_status}, new_value={"order_status": new_status},
    )
    return order
