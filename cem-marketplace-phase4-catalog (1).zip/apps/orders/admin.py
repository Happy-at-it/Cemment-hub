from django.contrib import admin
from .models import Order, OrderItem, OrderStatusHistory


class OrderItemInline(admin.TabularInline):
    model = OrderItem
    extra = 0
    readonly_fields = ("product", "product_name_snapshot", "unit_price_snapshot", "quantity", "line_total")


class OrderStatusHistoryInline(admin.TabularInline):
    model = OrderStatusHistory
    extra = 0
    readonly_fields = ("status", "changed_by", "note", "changed_at")


@admin.register(Order)
class OrderAdmin(admin.ModelAdmin):
    list_display = ("order_number", "customer_profile", "retailer_profile", "order_status",
                     "payment_status", "total_amount", "placed_at")
    list_filter = ("order_status", "payment_status", "fulfillment_method")
    search_fields = ("order_number",)
    inlines = [OrderItemInline, OrderStatusHistoryInline]
    readonly_fields = ("order_number", "placed_at")
