from django.db import models
from apps.users.models import CustomerProfile, Address, Project, User
from apps.retailers.models import RetailerProfile
from apps.catalog.models import Product


class Order(models.Model):
    PICKUP, DELIVERY = "Pickup", "Delivery"
    FULFILLMENT_CHOICES = [(PICKUP, "Pickup"), (DELIVERY, "Delivery")]

    PAYMENT_PENDING = "Pending"
    PAYMENT_PROCESSING = "Processing"
    PAYMENT_SUCCESSFUL = "Successful"
    PAYMENT_FAILED = "Failed"
    PAYMENT_REFUNDED = "Refunded"
    PAYMENT_PARTIALLY_REFUNDED = "PartiallyRefunded"
    PAYMENT_STATUS_CHOICES = [
        (PAYMENT_PENDING, "Pending"), (PAYMENT_PROCESSING, "Processing"),
        (PAYMENT_SUCCESSFUL, "Successful"), (PAYMENT_FAILED, "Failed"),
        (PAYMENT_REFUNDED, "Refunded"), (PAYMENT_PARTIALLY_REFUNDED, "Partially Refunded"),
    ]

    # Full status list from the spec; not every status applies to every
    # fulfillment method (enforced by orders.state_machine, not the DB).
    ORDER_PLACED = "OrderPlaced"
    PAYMENT_PENDING_STATUS = "PaymentPending"
    PAYMENT_CONFIRMED = "PaymentConfirmed"
    RETAILER_CONFIRMATION_PENDING = "RetailerConfirmationPending"
    CONFIRMED = "Confirmed"
    PREPARING = "Preparing"
    READY_FOR_PICKUP = "ReadyForPickup"
    DRIVER_ASSIGNED = "DriverAssigned"
    PICKED_UP = "PickedUp"
    OUT_FOR_DELIVERY = "OutForDelivery"
    DELIVERED = "Delivered"
    COMPLETED = "Completed"
    CANCELLED = "Cancelled"
    REFUNDED = "Refunded"
    DISPUTED = "Disputed"
    ORDER_STATUS_CHOICES = [
        (ORDER_PLACED, "Order Placed"), (PAYMENT_PENDING_STATUS, "Payment Pending"),
        (PAYMENT_CONFIRMED, "Payment Confirmed"),
        (RETAILER_CONFIRMATION_PENDING, "Retailer Confirmation Pending"),
        (CONFIRMED, "Confirmed"), (PREPARING, "Preparing"), (READY_FOR_PICKUP, "Ready for Pickup"),
        (DRIVER_ASSIGNED, "Driver Assigned"), (PICKED_UP, "Picked Up"),
        (OUT_FOR_DELIVERY, "Out for Delivery"), (DELIVERED, "Delivered"),
        (COMPLETED, "Completed"), (CANCELLED, "Cancelled"), (REFUNDED, "Refunded"),
        (DISPUTED, "Disputed"),
    ]

    order_number = models.CharField(max_length=20, unique=True, editable=False)  # CEM-YYYY-NNNNNN
    customer_profile = models.ForeignKey(CustomerProfile, on_delete=models.PROTECT, related_name="orders")
    retailer_profile = models.ForeignKey(RetailerProfile, on_delete=models.PROTECT, related_name="orders")
    project = models.ForeignKey(Project, on_delete=models.SET_NULL, null=True, blank=True, related_name="orders")
    fulfillment_method = models.CharField(max_length=10, choices=FULFILLMENT_CHOICES)
    delivery_address = models.ForeignKey(
        Address, on_delete=models.PROTECT, null=True, blank=True, related_name="+"
    )
    subtotal = models.DecimalField(max_digits=12, decimal_places=2)
    delivery_fee = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    platform_fee = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    discount_amount = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    total_amount = models.DecimalField(max_digits=12, decimal_places=2)
    payment_status = models.CharField(max_length=20, choices=PAYMENT_STATUS_CHOICES, default=PAYMENT_PENDING)
    order_status = models.CharField(max_length=30, choices=ORDER_STATUS_CHOICES, default=ORDER_PLACED)
    cancellation_reason = models.CharField(max_length=255, blank=True, null=True)
    cancelled_at = models.DateTimeField(null=True, blank=True)
    placed_at = models.DateTimeField(auto_now_add=True)
    completed_at = models.DateTimeField(null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        db_table = "Orders"
        indexes = [
            models.Index(fields=["customer_profile"], name="ix_orders_customer"),
            models.Index(fields=["retailer_profile"], name="ix_orders_retailer"),
            models.Index(fields=["order_status"], name="ix_orders_status"),
            models.Index(fields=["placed_at"], name="ix_orders_placedat"),
        ]
        constraints = [
            models.CheckConstraint(check=models.Q(subtotal__gte=0), name="ck_order_subtotal_nonneg"),
            models.CheckConstraint(check=models.Q(total_amount__gte=0), name="ck_order_total_nonneg"),
        ]

    def __str__(self):
        return self.order_number

    def get_retailer_profile(self):
        return self.retailer_profile


class OrderItem(models.Model):
    order = models.ForeignKey(Order, on_delete=models.CASCADE, related_name="items")
    product = models.ForeignKey(Product, on_delete=models.PROTECT, related_name="+")
    # Snapshots preserve what the customer actually saw/paid, even if the
    # retailer edits the product name/price afterwards.
    product_name_snapshot = models.CharField(max_length=200)
    unit_price_snapshot = models.DecimalField(max_digits=10, decimal_places=2)
    quantity = models.PositiveIntegerField()
    line_total = models.DecimalField(max_digits=12, decimal_places=2)

    class Meta:
        db_table = "OrderItems"
        indexes = [models.Index(fields=["order"], name="ix_orderitems_order")]
        constraints = [models.CheckConstraint(check=models.Q(quantity__gt=0), name="ck_orderitem_qty_positive")]

    def __str__(self):
        return f"{self.quantity} x {self.product_name_snapshot}"


class OrderStatusHistory(models.Model):
    order = models.ForeignKey(Order, on_delete=models.CASCADE, related_name="status_history")
    status = models.CharField(max_length=30, choices=Order.ORDER_STATUS_CHOICES)
    changed_by = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, blank=True, related_name="+")
    note = models.CharField(max_length=255, blank=True, null=True)
    changed_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = "OrderStatusHistory"
        indexes = [models.Index(fields=["order"], name="ix_orderstatushist_order")]
        ordering = ["changed_at"]

    def __str__(self):
        return f"{self.order} -> {self.status}"


class OrderNumberCounter(models.Model):
    """One row per year; NNNNNN increments within that year to produce
    order numbers like CEM-2026-000001 (see order_numbering.py)."""
    year = models.PositiveIntegerField(unique=True)
    last_sequence = models.PositiveIntegerField(default=0)

    class Meta:
        db_table = "OrderNumberCounters"
