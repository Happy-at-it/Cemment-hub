"""
Checkout and cancellation service layer. This is where the "essential
marketplace transaction" (Customer -> Product -> Retailer -> Cart ->
Checkout -> Payment -> Order -> Delivery/Pickup -> Completion ->
Settlement) actually gets stitched together.
"""
from django.core.exceptions import ValidationError
from django.db import transaction
from django.utils import timezone

from apps.audit import services as audit
from apps.cart.services import cart_subtotal, clear_cart
from apps.config.services import get_config
from apps.inventory.services import reserve_for_order, release_for_cancelled_order, InsufficientStockError
from apps.notifications.services import notify
from .models import Order, OrderItem
from .order_numbering import generate_order_number
from .state_machine import transition


class EmptyCartError(ValidationError):
    pass


class RetailerNotSellableError(ValidationError):
    pass


@transaction.atomic
def checkout(cart, fulfillment_method, delivery_address=None, delivery_fee=0, project=None):
    """Creates an Order + OrderItems from a Cart, reserving stock for every
    line item. Raises InsufficientStockError (caught by the API view and
    turned into 'This product is currently out of stock.') if anything
    can't be fulfilled — the whole transaction rolls back, so nothing is
    partially reserved."""
    items = list(cart.items.select_related("product", "product__retailer_profile"))
    if not items:
        raise EmptyCartError("Your cart is empty.")

    retailer = cart.retailer_profile
    if not retailer.is_sellable():
        raise RetailerNotSellableError("This retailer is not currently accepting orders.")

    if fulfillment_method == Order.DELIVERY and delivery_address is None:
        raise ValidationError("A delivery address is required for delivery orders.")

    subtotal = cart_subtotal(cart)
    platform_fee_percent = get_config("PLATFORM_SERVICE_FEE_PERCENT", default="0")
    platform_fee = (subtotal * platform_fee_percent / 100) if platform_fee_percent else 0
    total = subtotal + delivery_fee + platform_fee

    order = Order.objects.create(
        order_number=generate_order_number(),
        customer_profile=cart.customer_profile,
        retailer_profile=retailer,
        project=project,
        fulfillment_method=fulfillment_method,
        delivery_address=delivery_address,
        subtotal=subtotal,
        delivery_fee=delivery_fee,
        platform_fee=platform_fee,
        total_amount=total,
        order_status=Order.ORDER_PLACED,
    )

    for item in items:
        # Row-locks & decrements stock; raises InsufficientStockError on failure,
        # which rolls back order creation for every item via the outer @transaction.atomic.
        reserve_for_order(item.product, item.quantity, changed_by=cart.customer_profile.user)
        OrderItem.objects.create(
            order=order, product=item.product,
            product_name_snapshot=item.product.product_name,
            unit_price_snapshot=item.product.price_per_unit,
            quantity=item.quantity,
            line_total=item.line_total(),
        )

    audit.log(
        user=cart.customer_profile.user, action="OrderPlaced", entity_type="Order", entity_id=order.id,
        new_value={"order_number": order.order_number, "total": str(total)},
    )
    clear_cart(cart)

    notify(order.customer_profile.user, event_type="OrderPlaced",
           title="Order placed", message=f"Your order {order.order_number} has been placed.")
    notify(retailer.user, event_type="NewOrder",
           title="New order received", message=f"You have a new order: {order.order_number}.")

    return order


def confirm_order(order: Order, acting_user):
    """Called once payment is confirmed (order is in
    RetailerConfirmationPending) and the retailer accepts the order."""
    transition(order, Order.CONFIRMED, changed_by=acting_user, note="Retailer confirmed order")
    notify(order.customer_profile.user, event_type="OrderConfirmed",
           title="Order confirmed", message=f"{order.retailer_profile.business_name} confirmed your order.")
    return order


class CancellationNotAllowedError(ValidationError):
    pass


def can_cancel(order: Order) -> tuple:
    """Returns (allowed: bool, reason: str). Cancellation rules are
    config-driven, not hard-coded, per the spec."""
    if order.order_status in (Order.CANCELLED, Order.COMPLETED, Order.DELIVERED, Order.REFUNDED):
        return False, f"Order is already {order.order_status} and cannot be cancelled."

    if order.order_status in (Order.PICKED_UP, Order.OUT_FOR_DELIVERY):
        return False, "Order has already been dispatched and cannot be cancelled."

    window_minutes = int(get_config("CANCELLATION_WINDOW_MINUTES", default="30"))
    if order.order_status in (Order.CONFIRMED, Order.PREPARING):
        elapsed = (timezone.now() - order.placed_at).total_seconds() / 60
        if elapsed > window_minutes:
            return False, f"Cancellation window of {window_minutes} minutes has passed."

    return True, ""


@transaction.atomic
def cancel_order(order: Order, acting_user, reason: str):
    allowed, why = can_cancel(order)
    if not allowed:
        raise CancellationNotAllowedError(why)

    transition(order, Order.CANCELLED, changed_by=acting_user, note=reason)
    order.cancellation_reason = reason
    order.cancelled_at = timezone.now()
    order.save(update_fields=["cancellation_reason", "cancelled_at", "updated_at"])

    for item in order.items.select_related("product"):
        release_for_cancelled_order(item.product, item.quantity, changed_by=acting_user)

    notify(order.customer_profile.user, event_type="OrderCancelled",
           title="Order cancelled", message=f"Order {order.order_number} was cancelled. Reason: {reason}")
    notify(order.retailer_profile.user, event_type="OrderCancelled",
           title="Order cancelled", message=f"Order {order.order_number} was cancelled. Reason: {reason}")
    return order
