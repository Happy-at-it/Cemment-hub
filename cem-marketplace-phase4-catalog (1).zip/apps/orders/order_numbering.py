"""Generates unique order numbers in the CEM-YYYY-NNNNNN format required
by the spec. Uses a DB-level row lock on the current year's counter so
concurrent checkouts never collide on the same number."""
from django.db import transaction
from django.utils import timezone

from .models import OrderNumberCounter


@transaction.atomic
def generate_order_number() -> str:
    year = timezone.now().year
    counter, _ = OrderNumberCounter.objects.select_for_update().get_or_create(year=year)
    counter.last_sequence += 1
    counter.save(update_fields=["last_sequence"])
    return f"CEM-{year}-{counter.last_sequence:06d}"
