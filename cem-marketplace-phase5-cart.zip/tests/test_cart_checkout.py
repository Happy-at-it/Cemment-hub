"""Phase: Cart tests — add/update/remove, single-retailer enforcement,
quantity validation, and promo codes."""
import pytest
from rest_framework.test import APIClient

from apps.users.models import User, Role, CustomerProfile, Address
from apps.retailers.models import RetailerProfile
from apps.catalog.models import Category, Brand, Product
from apps.inventory.models import Inventory

pytestmark = pytest.mark.django_db


@pytest.fixture
def api():
    return APIClient()


@pytest.fixture
def customer(db):
    role, _ = Role.objects.get_or_create(role_name=Role.CUSTOMER)
    user = User.objects.create_user(email="c1@example.com", phone="+233500000001", password="x", role=role)
    CustomerProfile.objects.create(user=user, full_name="Test Customer")
    return user


def _make_retailer(email, phone):
    role, _ = Role.objects.get_or_create(role_name=Role.RETAILER)
    user = User.objects.create_user(email=email, phone=phone, password="x", role=role)
    address = Address.objects.create(user=user, line1="1 St", city="Kumasi", region="Ashanti")
    return RetailerProfile.objects.create(
        user=user, business_name=f"Retailer {email}", owner_name="Owner",
        business_address=address, status=RetailerProfile.APPROVED,
    )


def _make_product(retailer, name, price=78, stock=100, min_qty=5, max_qty=500):
    category, _ = Category.objects.get_or_create(name="Cement", slug="cement")
    brand, _ = Brand.objects.get_or_create(name="Ghacem")
    p = Product.objects.create(
        retailer_profile=retailer, category=category, brand=brand, product_name=name,
        price_per_unit=price, min_order_quantity=min_qty, max_order_quantity=max_qty,
    )
    Inventory.objects.create(product=p, quantity_available=stock)
    return p


class TestAddToCart:
    def test_add_item_creates_cart(self, api, customer):
        retailer = _make_retailer("r1@example.com", "+233500000002")
        product = _make_product(retailer, "Super Strong 42.5R")
        api.force_authenticate(user=customer)
        resp = api.post("/api/v1/cart/items/", {"product_id": product.id, "quantity": 10}, format="json")
        assert resp.status_code == 201
        assert resp.data["items"][0]["quantity"] == 10
        assert resp.data["retailer_id"] == retailer.id

    def test_below_min_quantity_rejected(self, api, customer):
        retailer = _make_retailer("r2@example.com", "+233500000003")
        product = _make_product(retailer, "Diamond OPC", min_qty=10)
        api.force_authenticate(user=customer)
        resp = api.post("/api/v1/cart/items/", {"product_id": product.id, "quantity": 3}, format="json")
        assert resp.status_code == 400
        assert resp.data["error"]["code"] == "CART_VALIDATION_ERROR"

    def test_cannot_mix_retailers_in_one_cart(self, api, customer):
        r1 = _make_retailer("r3@example.com", "+233500000004")
        r2 = _make_retailer("r4@example.com", "+233500000005")
        p1 = _make_product(r1, "Ghacem A")
        p2 = _make_product(r2, "Ghacem B")
        api.force_authenticate(user=customer)
        api.post("/api/v1/cart/items/", {"product_id": p1.id, "quantity": 10}, format="json")
        resp = api.post("/api/v1/cart/items/", {"product_id": p2.id, "quantity": 10}, format="json")
        assert resp.status_code == 400
        assert resp.data["error"]["code"] == "CART_VALIDATION_ERROR"


class TestUpdateRemove:
    def test_update_quantity_respects_stock(self, api, customer):
        retailer = _make_retailer("r5@example.com", "+233500000006")
        product = _make_product(retailer, "Ghacem", stock=15)
        api.force_authenticate(user=customer)
        add_resp = api.post("/api/v1/cart/items/", {"product_id": product.id, "quantity": 10}, format="json")
        item_id = add_resp.data["items"][0]["id"]

        resp = api.patch(f"/api/v1/cart/items/{item_id}/", {"quantity": 50}, format="json")
        assert resp.status_code == 400
        assert resp.data["error"]["code"] == "OUT_OF_STOCK"

    def test_remove_item_empties_cart(self, api, customer):
        retailer = _make_retailer("r6@example.com", "+233500000007")
        product = _make_product(retailer, "Ghacem")
        api.force_authenticate(user=customer)
        add_resp = api.post("/api/v1/cart/items/", {"product_id": product.id, "quantity": 10}, format="json")
        item_id = add_resp.data["items"][0]["id"]

        resp = api.delete(f"/api/v1/cart/items/{item_id}/")
        assert resp.status_code == 204

        cart_resp = api.get("/api/v1/cart/")
        assert len(cart_resp.data["items"]) == 0
        assert cart_resp.data["retailer_id"] is None

    def test_cannot_modify_another_customers_cart_item(self, api, customer):
        retailer = _make_retailer("r7@example.com", "+233500000008")
        product = _make_product(retailer, "Ghacem")
        api.force_authenticate(user=customer)
        add_resp = api.post("/api/v1/cart/items/", {"product_id": product.id, "quantity": 10}, format="json")
        item_id = add_resp.data["items"][0]["id"]

        role, _ = Role.objects.get_or_create(role_name=Role.CUSTOMER)
        other = User.objects.create_user(email="other@example.com", phone="+233500000009", password="x", role=role)
        CustomerProfile.objects.create(user=other, full_name="Other Customer")
        api.force_authenticate(user=other)
        resp = api.patch(f"/api/v1/cart/items/{item_id}/", {"quantity": 5}, format="json")
        assert resp.status_code == 404


class TestPromoCode:
    def test_invalid_code_rejected(self, api, customer):
        retailer = _make_retailer("r8@example.com", "+233500000010")
        product = _make_product(retailer, "Ghacem")
        api.force_authenticate(user=customer)
        api.post("/api/v1/cart/items/", {"product_id": product.id, "quantity": 10}, format="json")

        resp = api.post("/api/v1/cart/apply-promo/", {"code": "DOESNOTEXIST"}, format="json")
        assert resp.status_code == 400
        assert resp.data["error"]["code"] == "INVALID_PROMO"

    def test_promo_on_empty_cart_rejected(self, api, customer):
        api.force_authenticate(user=customer)
        resp = api.post("/api/v1/cart/apply-promo/", {"code": "ANYTHING"}, format="json")
        assert resp.status_code == 400
        assert resp.data["error"]["code"] == "EMPTY_CART"
