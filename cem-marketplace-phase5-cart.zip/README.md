# CEM Marketplace — Backend (through Phase: Cart)

## Progress so far
- **Database**, **Authentication**, **Retailers**, **Products & Catalog** — see prior phase notes.
- **Cart** (this drop):
  - `GET /api/v1/cart/` — current cart with items, subtotal, and which retailer it's scoped to
  - `POST /api/v1/cart/items/` — `{"product_id": 4, "quantity": 20}`; enforces single-retailer-per-cart
    and min/max order quantity via `apps/cart/services.py` (written in the Database phase, now actually wired up)
  - `PATCH /api/v1/cart/items/{id}/` — quantity update; re-checks min/max **and** live stock
  - `DELETE /api/v1/cart/items/{id}/` — removing the last item clears the cart's retailer lock
  - `POST /api/v1/cart/apply-promo/` — validates a discount code against `apps/promotions/services.py`
  - All cart-item endpoints are scoped to `request.user.customer_profile` — another customer's item id
    returns 404, not 403
  - `tests/test_cart_checkout.py` — add-to-cart, min-quantity rejection, cross-retailer rejection,
    stock-aware quantity updates, item removal, cross-customer isolation, promo code validation

## Run it
```bash
python -m venv venv && source venv/bin/activate
pip install -r requirements/dev.txt
cp .env.example .env
python manage.py makemigrations && python manage.py migrate
python manage.py createsuperuser
python manage.py runserver
```
```bash
pytest   # auth, retailer lifecycle, products/inventory, cart
```

## Still not run against a live interpreter
Same caveat as every phase so far — syntax-checked, not execution-tested,
because this sandbox has no internet access to install Django. Please run
`pytest` for real in Claude Code; a couple of real bugs have already
turned up that way in earlier phases and only running the code catches them.

## What's next
**Orders**: wiring `apps/orders/services.py:checkout()` (already written) to a
real `POST /orders/checkout/` endpoint, plus order confirmation, cancellation,
and status-update endpoints.
