from rest_framework import serializers
from .models import Cart, CartItem


class CartItemProductSerializer(serializers.Serializer):
    """Minimal product snapshot embedded in a cart item response — enough
    for the frontend to render a cart row without a second request."""
    id = serializers.IntegerField()
    product_name = serializers.CharField()
    brand_name = serializers.CharField(source="brand.name")
    price_per_unit = serializers.DecimalField(max_digits=10, decimal_places=2)
    min_order_quantity = serializers.IntegerField()
    max_order_quantity = serializers.IntegerField(allow_null=True)
    quantity_available = serializers.SerializerMethodField()

    def get_quantity_available(self, obj):
        return getattr(getattr(obj, "inventory", None), "quantity_available", 0)


class CartItemSerializer(serializers.ModelSerializer):
    product = CartItemProductSerializer(read_only=True)
    line_total = serializers.SerializerMethodField()

    class Meta:
        model = CartItem
        fields = ["id", "product", "quantity", "line_total"]

    def get_line_total(self, obj):
        return obj.line_total()


class CartSerializer(serializers.ModelSerializer):
    items = CartItemSerializer(many=True, read_only=True)
    retailer_id = serializers.IntegerField(source="retailer_profile_id", read_only=True)
    retailer_name = serializers.CharField(source="retailer_profile.business_name", read_only=True, default=None)
    subtotal = serializers.SerializerMethodField()

    class Meta:
        model = Cart
        fields = ["id", "retailer_id", "retailer_name", "items", "subtotal", "updated_at"]

    def get_subtotal(self, obj):
        from .services import cart_subtotal
        return cart_subtotal(obj)


class AddCartItemSerializer(serializers.Serializer):
    product_id = serializers.IntegerField()
    quantity = serializers.IntegerField(min_value=1)


class UpdateCartItemSerializer(serializers.Serializer):
    quantity = serializers.IntegerField(min_value=1)


class ApplyPromoSerializer(serializers.Serializer):
    code = serializers.CharField(max_length=30)
