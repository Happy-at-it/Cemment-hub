from django.urls import path
from .views import CartDetailView, CartItemCreateView, CartItemDetailView, CartApplyPromoView

# Mounted at /api/v1/ by config/urls.py.
urlpatterns = [
    path("cart/", CartDetailView.as_view(), name="cart-detail"),
    path("cart/items/", CartItemCreateView.as_view(), name="cart-item-create"),
    path("cart/items/<int:item_id>/", CartItemDetailView.as_view(), name="cart-item-detail"),
    path("cart/apply-promo/", CartApplyPromoView.as_view(), name="cart-apply-promo"),
]
