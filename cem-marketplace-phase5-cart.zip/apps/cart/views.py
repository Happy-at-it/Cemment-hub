from django.core.exceptions import ValidationError as DjangoValidationError
from django.shortcuts import get_object_or_404
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.views import APIView

from apps.catalog.models import Product
from apps.common.permissions import IsCustomer
from .models import CartItem
from .serializers import CartSerializer, AddCartItemSerializer, UpdateCartItemSerializer, ApplyPromoSerializer
from .services import get_or_create_cart, add_item, remove_item


def _error(code, message, status=400):
    return Response({"error": {"code": code, "message": message}}, status=status)


class CartDetailView(APIView):
    """GET /api/v1/cart/"""
    permission_classes = [IsAuthenticated, IsCustomer]

    def get(self, request):
        cart = get_or_create_cart(request.user.customer_profile)
        return Response(CartSerializer(cart).data)


class CartItemCreateView(APIView):
    """POST /api/v1/cart/items/  { "product_id": 4, "quantity": 20 }
    All validation (single-retailer enforcement, min/max quantity) lives
    in apps.cart.services.add_item — this view only translates its
    exceptions into the API's consistent error shape. Stock availability
    is re-checked again at checkout (the authoritative moment), so a
    product going out of stock between add-to-cart and checkout is still
    caught."""
    permission_classes = [IsAuthenticated, IsCustomer]

    def post(self, request):
        serializer = AddCartItemSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        product = get_object_or_404(Product, id=serializer.validated_data["product_id"], availability_status=Product.ACTIVE)

        try:
            add_item(request.user.customer_profile, product, serializer.validated_data["quantity"])
        except DjangoValidationError as exc:
            return _error("CART_VALIDATION_ERROR", "; ".join(exc.messages) if hasattr(exc, "messages") else str(exc))

        cart = get_or_create_cart(request.user.customer_profile)
        return Response(CartSerializer(cart).data, status=201)


class CartItemDetailView(APIView):
    """PATCH/DELETE /api/v1/cart/items/{id}/"""
    permission_classes = [IsAuthenticated, IsCustomer]

    def _get_item(self, request, item_id):
        return get_object_or_404(CartItem, id=item_id, cart__customer_profile=request.user.customer_profile)

    def patch(self, request, item_id):
        item = self._get_item(request, item_id)
        serializer = UpdateCartItemSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        new_qty = serializer.validated_data["quantity"]
        product = item.product

        if new_qty < product.min_order_quantity:
            return _error("QUANTITY_TOO_LOW", f"Minimum order quantity for this product is {product.min_order_quantity}.")
        if product.max_order_quantity and new_qty > product.max_order_quantity:
            return _error("QUANTITY_TOO_HIGH", f"Maximum order quantity for this product is {product.max_order_quantity}.")
        available = getattr(getattr(product, "inventory", None), "quantity_available", 0)
        if new_qty > available:
            return _error("OUT_OF_STOCK", "This product is currently out of stock at that quantity.")

        item.quantity = new_qty
        item.save(update_fields=["quantity"])
        return Response(CartSerializer(item.cart).data)

    def delete(self, request, item_id):
        item = self._get_item(request, item_id)
        remove_item(item.cart, item.id)
        return Response(status=204)


class CartApplyPromoView(APIView):
    """POST /api/v1/cart/apply-promo/  { "code": "SAVE10" }"""
    permission_classes = [IsAuthenticated, IsCustomer]

    def post(self, request):
        from apps.promotions.services import validate_and_apply_code, InvalidPromotionError
        from .services import cart_subtotal

        serializer = ApplyPromoSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        cart = get_or_create_cart(request.user.customer_profile)

        if not cart.items.exists():
            return _error("EMPTY_CART", "Your cart is empty.")

        try:
            promo, discount = validate_and_apply_code(
                serializer.validated_data["code"], cart_subtotal(cart), request.user.customer_profile
            )
        except InvalidPromotionError as exc:
            return _error("INVALID_PROMO", "; ".join(exc.messages) if hasattr(exc, "messages") else str(exc))

        return Response({
            "code": promo.code, "discount_amount": str(discount),
            "new_subtotal": str(cart_subtotal(cart) - discount),
        })
