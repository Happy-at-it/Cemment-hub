# CEM Marketplace — Backend (through Phase: Authentication)

## Progress so far
- **Database**: all 15 domain apps' models, service-layer business logic, admin wiring (see previous drop / this same tree).
- **Authentication** (this drop):
  - `POST /api/v1/auth/register/` — customer/retailer/driver self-registration (role-aware; customer gets a `CustomerProfile` immediately, retailer/driver complete their profile via their own registration endpoint in a later phase)
  - `POST /api/v1/auth/login/` — JWT access + refresh tokens, role embedded in the token claim
  - `POST /api/v1/auth/refresh/` — refresh access token (rotates + blacklists old refresh token)
  - `POST /api/v1/auth/logout/` — blacklists the refresh token
  - `POST /api/v1/auth/password-reset/` and `/confirm/` — token-based reset, account-enumeration-safe (always 200s)
  - `GET/PATCH /api/v1/users/me/` — own profile
  - `GET/POST /api/v1/users/me/addresses/`, `PATCH/DELETE /api/v1/users/me/addresses/{id}/`
  - Rate limiting on all auth endpoints via DRF's `ScopedRateThrottle` (`auth` scope, 10/min — tune in `config/settings/base.py`)
  - Password strength enforced via Django's validators (min length 10, common-password check, etc. — see `AUTH_PASSWORD_VALIDATORS`)
  - `tests/test_auth.py` — registration, login (valid/invalid/inactive-user), password reset, and profile access-control tests

## Run it
```bash
python -m venv venv && source venv/bin/activate
pip install -r requirements/dev.txt
cp .env.example .env   # fill in SECRET_KEY + your MSSQL connection details
python manage.py makemigrations
python manage.py migrate
python manage.py createsuperuser
python manage.py runserver
```
Then, e.g.:
```bash
curl -X POST http://localhost:8000/api/v1/auth/register/ \
  -H "Content-Type: application/json" \
  -d '{"email":"ama@example.com","phone":"+233200000001","password":"StrongPass123!","role":"Customer","full_name":"Ama Mensah"}'
```

Run the test suite (once Django + a test DB are available):
```bash
pytest
```

## Still not run against a live interpreter
Same caveat as before: this sandbox has no internet access, so none of this
has executed against real Django/DRF/SimpleJWT yet — only syntax-checked.
Please run `pytest` in Claude Code (or your own machine) as the real
verification step, per the roadmap's "test each module before moving on."

## What's next
Retailers phase: retailer self-service registration (submitting documents),
admin approval endpoints, retailer dashboard/storefront endpoints — building
on the `apps/retailers/services.py` logic already written in the Database phase.
