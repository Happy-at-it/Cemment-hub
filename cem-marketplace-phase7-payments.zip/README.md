# CEM Marketplace — Backend (through Phase: Payments)

## Progress so far
- **Database**, **Authentication**, **Retailers**, **Products & Catalog**, **Cart**, **Orders** — see prior notes.
- **Payments** (this drop):
  - `POST /api/v1/payments/{order_id}/initiate/` — `{"method": "MobileMoney"}`; customer-only, own order only
  - `GET /api/v1/payments/{order_id}/` — order owner or admin only (403 for anyone else)
  - `POST /api/v1/payments/{order_id}/refund/` — admin-only; `amount` optional (defaults to full payment), capped at the original amount
  - `POST /api/v1/payments/webhook/{provider}/` — verifies signature via the gateway interface before trusting the payload; resolves an async (real-provider) payment from `PaymentPending`
  - `tests/test_payments.py` — successful payment confirms order + advances status, duplicate-payment rejection, cross-customer access blocked, payment detail visibility, refund (success, non-admin blocked, over-amount rejected)

## A real bug found and fixed while building this phase
`initiate_payment()` originally tried to transition a freshly-checked-out order straight from `OrderPlaced` to `PaymentConfirmed`. The order state machine (built in the Orders phase) requires passing through `PaymentPending` first — skipping it would raise `IllegalTransitionError` on **every single successful payment**, a request-breaking bug. I caught this by tracing the actual transition sequence against `apps/orders/state_machine.py`'s rules (confirmed with a standalone Python reproduction — no Django needed for that part) rather than trusting that the code merely compiling meant it worked. Fixed by inserting the `OrderPlaced → PaymentPending` step before `PaymentConfirmed`, and while there, added proper handling for an async/"Processing" gateway response (relevant once a real, non-sandbox provider is wired in) so the webhook's assumption — that the order is sitting at `PaymentPending` when it fires — actually holds.

This is exactly the category of bug `py_compile` cannot catch, because both the buggy and fixed versions are syntactically valid Python. It's also a good demonstration of why the roadmap's "test each module before moving to the next" instruction matters — please run `pytest` for real in Claude Code before we build the next phase on top of this one.

## Run it
```bash
python -m venv venv && source venv/bin/activate
pip install -r requirements/dev.txt
cp .env.example .env
python manage.py makemigrations && python manage.py migrate
python manage.py createsuperuser
python manage.py runserver
```
```bash
pytest   # auth, retailer lifecycle, products/inventory, cart, orders, payments
```

## What's next
**Delivery**: driver assignment, delivery status endpoints (which call the
same `apps.orders.state_machine.transition()` pattern), and the delivery
pricing estimate endpoint — building on `apps/delivery/services.py` and
`apps/delivery/geo/` already written.
