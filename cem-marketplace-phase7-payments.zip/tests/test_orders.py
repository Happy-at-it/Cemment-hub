"""Phase: Orders tests — checkout, confirmation, cancellation rules, and
status transition enforcement."""
import pytest
from rest_framework.test import APIClient

from apps.users.models import User, Role, CustomerProfile, Address
from apps.retailers.models import RetailerProfile
from apps.catalog.models import Category, Brand, Product
from apps.inventory.models import Inventory
from apps.orders.models import Order

pytestmark = pytest.mark.django_db


@pytest.fixture
def api():
    return APIClient()


@pytest.fixture
def customer(db):
    role, _ = Role.objects.get_or_create(role_name=Role.CUSTOMER)
    user = User.objects.create_user(email="c1@example.com", phone="+233600000001", password="x", role=role)
    CustomerProfile.objects.create(user=user, full_name="Test Customer")
    Address.objects.create(user=user, label="Site", line1="1 Ridge Ave", city="Kumasi", region="Ashanti")
    return user


@pytest.fixture
def retailer(db):
    role, _ = Role.objects.get_or_create(role_name=Role.RETAILER)
    user = User.objects.create_user(email="r1@example.com", phone="+233600000002", password="x", role=role)
    address = Address.objects.create(user=user, line1="1 St", city="Kumasi", region="Ashanti")
    return RetailerProfile.objects.create(
        user=user, business_name="Test Retailer", owner_name="Owner",
        business_address=address, status=RetailerProfile.APPROVED,
    )


@pytest.fixture
def product(retailer):
    category, _ = Category.objects.get_or_create(name="Cement", slug="cement")
    brand, _ = Brand.objects.get_or_create(name="Ghacem")
    p = Product.objects.create(
        retailer_profile=retailer, category=category, brand=brand, product_name="Super Strong 42.5R",
        price_per_unit=78, min_order_quantity=5, max_order_quantity=500,
    )
    Inventory.objects.create(product=p, quantity_available=50)
    return p


def _add_to_cart(api, customer, product, qty=10):
    api.force_authenticate(user=customer)
    return api.post("/api/v1/cart/items/", {"product_id": product.id, "quantity": qty}, format="json")


class TestCheckout:
    def test_pickup_checkout_creates_order_and_reserves_stock(self, api, customer, product):
        _add_to_cart(api, customer, product, 10)
        resp = api.post("/api/v1/orders/checkout/", {"fulfillment_method": "Pickup"}, format="json")
        assert resp.status_code == 201
        assert resp.data["order_number"].startswith("CEM-")
        assert resp.data["order_status"] == Order.ORDER_PLACED

        product.inventory.refresh_from_db()
        assert product.inventory.quantity_available == 40  # 50 - 10

    def test_checkout_empties_cart(self, api, customer, product):
        _add_to_cart(api, customer, product, 10)
        api.post("/api/v1/orders/checkout/", {"fulfillment_method": "Pickup"}, format="json")
        cart_resp = api.get("/api/v1/cart/")
        assert len(cart_resp.data["items"]) == 0

    def test_delivery_checkout_requires_address(self, api, customer, product):
        _add_to_cart(api, customer, product, 10)
        resp = api.post("/api/v1/orders/checkout/", {"fulfillment_method": "Delivery"}, format="json")
        assert resp.status_code == 400

    def test_checkout_with_empty_cart_rejected(self, api, customer):
        api.force_authenticate(user=customer)
        resp = api.post("/api/v1/orders/checkout/", {"fulfillment_method": "Pickup"}, format="json")
        assert resp.status_code == 400
        assert resp.data["error"]["code"] == "EMPTY_CART"

    def test_checkout_insufficient_stock_rejected(self, api, customer, product):
        _add_to_cart(api, customer, product, 50)  # equals current stock, allowed at cart stage
        # Simulate a concurrent sale reducing stock between add-to-cart and checkout.
        product.inventory.quantity_available = 10
        product.inventory.save(update_fields=["quantity_available"])

        api.force_authenticate(user=customer)
        resp = api.post("/api/v1/orders/checkout/", {"fulfillment_method": "Pickup"}, format="json")
        assert resp.status_code == 400
        assert resp.data["error"]["code"] == "OUT_OF_STOCK"
        # Nothing was reserved from the remaining 10 — the whole order rolled back.
        product.inventory.refresh_from_db()
        assert product.inventory.quantity_available == 10


class TestConfirmAndCancel:
    def test_retailer_can_confirm_own_order(self, api, customer, retailer, product):
        _add_to_cart(api, customer, product, 10)
        checkout_resp = api.post("/api/v1/orders/checkout/", {"fulfillment_method": "Pickup"}, format="json")
        order_id = checkout_resp.data["id"]

        # simulate payment confirmation having already moved the order forward
        from apps.orders.state_machine import transition
        order = Order.objects.get(id=order_id)
        transition(order, Order.PAYMENT_PENDING_STATUS, changed_by=customer)
        transition(order, Order.PAYMENT_CONFIRMED, changed_by=customer)
        transition(order, Order.RETAILER_CONFIRMATION_PENDING, changed_by=customer)

        api.force_authenticate(user=retailer.user)
        resp = api.post(f"/api/v1/orders/{order_id}/confirm/")
        assert resp.status_code == 200
        assert resp.data["order_status"] == Order.CONFIRMED

    def test_other_retailer_cannot_confirm_order(self, api, customer, retailer, product):
        _add_to_cart(api, customer, product, 10)
        checkout_resp = api.post("/api/v1/orders/checkout/", {"fulfillment_method": "Pickup"}, format="json")
        order_id = checkout_resp.data["id"]

        role, _ = Role.objects.get_or_create(role_name=Role.RETAILER)
        other = User.objects.create_user(email="r2@example.com", phone="+233600000003", password="x", role=role)
        api.force_authenticate(user=other)
        resp = api.post(f"/api/v1/orders/{order_id}/confirm/")
        assert resp.status_code == 404

    def test_customer_can_cancel_fresh_order(self, api, customer, product):
        _add_to_cart(api, customer, product, 10)
        checkout_resp = api.post("/api/v1/orders/checkout/", {"fulfillment_method": "Pickup"}, format="json")
        order_id = checkout_resp.data["id"]

        resp = api.post(f"/api/v1/orders/{order_id}/cancel/", {"reason": "Changed my mind"}, format="json")
        assert resp.status_code == 200
        assert resp.data["order_status"] == Order.CANCELLED

    def test_cancel_releases_stock(self, api, customer, product):
        _add_to_cart(api, customer, product, 10)
        checkout_resp = api.post("/api/v1/orders/checkout/", {"fulfillment_method": "Pickup"}, format="json")
        order_id = checkout_resp.data["id"]

        api.post(f"/api/v1/orders/{order_id}/cancel/", {"reason": "Changed my mind"}, format="json")
        product.inventory.refresh_from_db()
        assert product.inventory.quantity_available == 50  # fully released

    def test_cannot_cancel_completed_order(self, api, customer, product):
        _add_to_cart(api, customer, product, 10)
        checkout_resp = api.post("/api/v1/orders/checkout/", {"fulfillment_method": "Pickup"}, format="json")
        order_id = checkout_resp.data["id"]
        order = Order.objects.get(id=order_id)
        order.order_status = Order.COMPLETED
        order.save()

        resp = api.post(f"/api/v1/orders/{order_id}/cancel/", {"reason": "Too late"}, format="json")
        assert resp.status_code == 400
        assert resp.data["error"]["code"] == "CANCELLATION_NOT_ALLOWED"


class TestStatusTransitions:
    def test_retailer_cannot_skip_statuses(self, api, customer, retailer, product):
        _add_to_cart(api, customer, product, 10)
        checkout_resp = api.post("/api/v1/orders/checkout/", {"fulfillment_method": "Pickup"}, format="json")
        order_id = checkout_resp.data["id"]

        api.force_authenticate(user=retailer.user)
        # Order is still 'OrderPlaced' — jumping straight to 'Delivered' must be rejected.
        resp = api.patch(f"/api/v1/orders/{order_id}/status/", {"status": "Delivered"}, format="json")
        assert resp.status_code == 400
        assert resp.data["error"]["code"] == "ILLEGAL_TRANSITION"

    def test_customer_cannot_update_order_status(self, api, customer, product):
        _add_to_cart(api, customer, product, 10)
        checkout_resp = api.post("/api/v1/orders/checkout/", {"fulfillment_method": "Pickup"}, format="json")
        order_id = checkout_resp.data["id"]

        resp = api.patch(f"/api/v1/orders/{order_id}/status/", {"status": "Confirmed"}, format="json")
        assert resp.status_code == 403


class TestOrderVisibility:
    def test_customer_sees_only_own_orders(self, api, customer, product):
        _add_to_cart(api, customer, product, 10)
        api.post("/api/v1/orders/checkout/", {"fulfillment_method": "Pickup"}, format="json")

        role, _ = Role.objects.get_or_create(role_name=Role.CUSTOMER)
        other = User.objects.create_user(email="c2@example.com", phone="+233600000004", password="x", role=role)
        CustomerProfile.objects.create(user=other, full_name="Other Customer")
        api.force_authenticate(user=other)
        resp = api.get("/api/v1/orders/")
        assert resp.data["count"] == 0

    def test_retailer_sees_orders_placed_with_them(self, api, customer, retailer, product):
        _add_to_cart(api, customer, product, 10)
        api.post("/api/v1/orders/checkout/", {"fulfillment_method": "Pickup"}, format="json")

        api.force_authenticate(user=retailer.user)
        resp = api.get("/api/v1/orders/")
        assert resp.data["count"] == 1
