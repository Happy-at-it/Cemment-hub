"""Phase: Payments tests — successful/failed payment, duplicate
prevention, refund, and access control. Uses the sandbox gateway
(PAYMENT_PROVIDER defaults to 'sandbox' in .env.example / dev settings)."""
import pytest
from rest_framework.test import APIClient

from apps.users.models import User, Role, CustomerProfile, Address
from apps.retailers.models import RetailerProfile
from apps.catalog.models import Category, Brand, Product
from apps.inventory.models import Inventory
from apps.orders.models import Order

pytestmark = pytest.mark.django_db


@pytest.fixture
def api():
    return APIClient()


@pytest.fixture
def customer(db):
    role, _ = Role.objects.get_or_create(role_name=Role.CUSTOMER)
    user = User.objects.create_user(email="c1@example.com", phone="+233700000001", password="x", role=role)
    CustomerProfile.objects.create(user=user, full_name="Test Customer")
    return user


@pytest.fixture
def admin(db):
    role, _ = Role.objects.get_or_create(role_name=Role.ADMIN)
    return User.objects.create_user(email="admin@example.com", phone="+233700000002", password="x",
                                     role=role, is_staff=True)


@pytest.fixture
def order(customer, db):
    role, _ = Role.objects.get_or_create(role_name=Role.RETAILER)
    r_user = User.objects.create_user(email="r1@example.com", phone="+233700000003", password="x", role=role)
    address = Address.objects.create(user=r_user, line1="1 St", city="Kumasi", region="Ashanti")
    retailer = RetailerProfile.objects.create(
        user=r_user, business_name="Test Retailer", owner_name="Owner",
        business_address=address, status=RetailerProfile.APPROVED,
    )
    category, _ = Category.objects.get_or_create(name="Cement", slug="cement")
    brand, _ = Brand.objects.get_or_create(name="Ghacem")
    product = Product.objects.create(
        retailer_profile=retailer, category=category, brand=brand, product_name="Ghacem 42.5R",
        price_per_unit=78, min_order_quantity=5, max_order_quantity=500,
    )
    Inventory.objects.create(product=product, quantity_available=100)

    api = APIClient()
    api.force_authenticate(user=customer)
    api.post("/api/v1/cart/items/", {"product_id": product.id, "quantity": 10}, format="json")
    resp = api.post("/api/v1/orders/checkout/", {"fulfillment_method": "Pickup"}, format="json")
    return Order.objects.get(id=resp.data["id"])


class TestInitiatePayment:
    def test_successful_payment_confirms_order(self, api, customer, order):
        api.force_authenticate(user=customer)
        resp = api.post(f"/api/v1/payments/{order.id}/initiate/", {"method": "MobileMoney"}, format="json")
        assert resp.status_code == 200
        assert resp.data["status"] == "Successful"

        order.refresh_from_db()
        assert order.payment_status == Order.PAYMENT_SUCCESSFUL
        assert order.order_status == Order.RETAILER_CONFIRMATION_PENDING

    def test_duplicate_payment_rejected(self, api, customer, order):
        api.force_authenticate(user=customer)
        api.post(f"/api/v1/payments/{order.id}/initiate/", {"method": "MobileMoney"}, format="json")
        resp = api.post(f"/api/v1/payments/{order.id}/initiate/", {"method": "MobileMoney"}, format="json")
        assert resp.status_code == 400
        assert resp.data["error"]["code"] == "DUPLICATE_PAYMENT"

    def test_other_customer_cannot_pay_for_this_order(self, api, order):
        role, _ = Role.objects.get_or_create(role_name=Role.CUSTOMER)
        other = User.objects.create_user(email="c2@example.com", phone="+233700000004", password="x", role=role)
        CustomerProfile.objects.create(user=other, full_name="Other")
        api.force_authenticate(user=other)
        resp = api.post(f"/api/v1/payments/{order.id}/initiate/", {"method": "MobileMoney"}, format="json")
        assert resp.status_code == 404


class TestPaymentDetail:
    def test_owner_can_view_payment(self, api, customer, order):
        api.force_authenticate(user=customer)
        api.post(f"/api/v1/payments/{order.id}/initiate/", {"method": "Card"}, format="json")
        resp = api.get(f"/api/v1/payments/{order.id}/")
        assert resp.status_code == 200
        assert resp.data["order_number"] == order.order_number

    def test_stranger_cannot_view_payment(self, api, customer, order):
        api.force_authenticate(user=customer)
        api.post(f"/api/v1/payments/{order.id}/initiate/", {"method": "Card"}, format="json")

        role, _ = Role.objects.get_or_create(role_name=Role.CUSTOMER)
        stranger = User.objects.create_user(email="s@example.com", phone="+233700000005", password="x", role=role)
        CustomerProfile.objects.create(user=stranger, full_name="Stranger")
        api.force_authenticate(user=stranger)
        resp = api.get(f"/api/v1/payments/{order.id}/")
        assert resp.status_code == 403


class TestRefund:
    def test_admin_can_refund_successful_payment(self, api, customer, admin, order):
        api.force_authenticate(user=customer)
        api.post(f"/api/v1/payments/{order.id}/initiate/", {"method": "Card"}, format="json")

        api.force_authenticate(user=admin)
        resp = api.post(f"/api/v1/payments/{order.id}/refund/", {"reason": "Damaged goods"}, format="json")
        assert resp.status_code == 200
        assert resp.data["status"] == "Refunded"

    def test_non_admin_cannot_refund(self, api, customer, order):
        api.force_authenticate(user=customer)
        api.post(f"/api/v1/payments/{order.id}/initiate/", {"method": "Card"}, format="json")
        resp = api.post(f"/api/v1/payments/{order.id}/refund/", {"reason": "Trying my luck"}, format="json")
        assert resp.status_code == 403

    def test_refund_amount_cannot_exceed_payment(self, api, customer, admin, order):
        api.force_authenticate(user=customer)
        api.post(f"/api/v1/payments/{order.id}/initiate/", {"method": "Card"}, format="json")

        api.force_authenticate(user=admin)
        resp = api.post(f"/api/v1/payments/{order.id}/refund/",
                         {"amount": "999999.00", "reason": "Testing overage"}, format="json")
        assert resp.status_code == 400
        assert resp.data["error"]["code"] == "AMOUNT_TOO_HIGH"
