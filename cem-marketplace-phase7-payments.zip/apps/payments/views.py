from django.shortcuts import get_object_or_404
from rest_framework.permissions import AllowAny, IsAuthenticated
from rest_framework.response import Response
from rest_framework.views import APIView

from apps.common.permissions import IsAdminRole, IsCustomer
from apps.orders.models import Order
from .gateways.factory import get_gateway
from .gateways.production_stub import ProductionGatewayNotConfiguredError
from .models import Payment
from .serializers import PaymentSerializer, InitiatePaymentSerializer, RefundSerializer
from .services import initiate_payment, refund_payment, DuplicatePaymentError


def _error(code, message, status=400):
    return Response({"error": {"code": code, "message": message}}, status=status)


class PaymentInitiateView(APIView):
    """POST /api/v1/payments/{order_id}/initiate/  { "method": "MobileMoney" }
    Customer-only, and only for their own order. Delegates entirely to
    apps.payments.services.initiate_payment(), which talks to whichever
    gateway PAYMENT_PROVIDER selects — this view never touches a provider
    SDK directly."""
    permission_classes = [IsAuthenticated, IsCustomer]

    def post(self, request, order_id):
        order = get_object_or_404(Order, id=order_id, customer_profile__user=request.user)

        serializer = InitiatePaymentSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)

        try:
            payment = initiate_payment(order, method=serializer.validated_data["method"])
        except DuplicatePaymentError as exc:
            return _error("DUPLICATE_PAYMENT", str(exc))
        except ProductionGatewayNotConfiguredError:
            # No real provider wired in yet outside PAYMENT_PROVIDER=sandbox — this is a
            # server/config problem, not something retrying fixes, so 502 rather than 400.
            return _error("PAYMENT_PROVIDER_UNAVAILABLE",
                           "Payment could not be completed. Please try again later.", status=502)

        status_code = 402 if payment.status == "Failed" else 200
        return Response(PaymentSerializer(payment).data, status=status_code)


class PaymentDetailView(APIView):
    """GET /api/v1/payments/{order_id}/  — order owner or admin only."""
    permission_classes = [IsAuthenticated]

    def get(self, request, order_id):
        payment = get_object_or_404(Payment, order_id=order_id)
        user = request.user
        is_owner = payment.order.customer_profile.user_id == user.id
        is_admin = user.role.role_name == "Admin"
        if not (is_owner or is_admin):
            return _error("FORBIDDEN", "You do not have access to this payment.", status=403)
        return Response(PaymentSerializer(payment).data)


class PaymentRefundView(APIView):
    """POST /api/v1/payments/{order_id}/refund/  { "amount": 100.00, "reason": "..." }
    Admin-only. `amount` defaults to the full payment amount if omitted."""
    permission_classes = [IsAuthenticated, IsAdminRole]

    def post(self, request, order_id):
        payment = get_object_or_404(Payment, order_id=order_id)
        if payment.status not in ("Successful", "PartiallyRefunded"):
            return _error("NOT_REFUNDABLE", f"Payment is '{payment.status}' and cannot be refunded.")

        serializer = RefundSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        amount = serializer.validated_data.get("amount") or payment.amount
        if amount > payment.amount:
            return _error("AMOUNT_TOO_HIGH", "Refund amount cannot exceed the original payment amount.")

        payment = refund_payment(
            payment, amount=amount, reason=serializer.validated_data["reason"], acting_admin=request.user
        )
        return Response(PaymentSerializer(payment).data)


class PaymentWebhookView(APIView):
    """POST /api/v1/payments/webhook/{provider}/
    Receives async confirmation from a real payment provider (used once a
    production gateway that returns 'Processing' from charge() and
    confirms later is wired in — the sandbox gateway resolves
    synchronously, so this path isn't exercised in dev). The webhook
    signature is verified via the same gateway interface before any
    payload data is trusted, so a forged request can't fake a payment
    success."""
    permission_classes = [AllowAny]

    def post(self, request, provider):
        gateway = get_gateway()
        if not gateway.verify_webhook(headers=request.headers, body=request.body):
            return _error("INVALID_SIGNATURE", "Webhook signature verification failed.", status=401)

        order_number = request.data.get("order_number")
        provider_status = request.data.get("status")
        if not order_number or not provider_status:
            return _error("MALFORMED_PAYLOAD", "Missing order_number or status.")

        order = get_object_or_404(Order, order_number=order_number)
        payment = get_object_or_404(Payment, order=order)
        payment.status = provider_status
        payment.save(update_fields=["status", "updated_at"])

        if provider_status == "Successful":
            from apps.orders.state_machine import transition
            order.payment_status = Order.PAYMENT_SUCCESSFUL
            order.save(update_fields=["payment_status", "updated_at"])
            if order.order_status == Order.PAYMENT_PENDING_STATUS:
                transition(order, Order.PAYMENT_CONFIRMED, changed_by=None)
                transition(order, Order.RETAILER_CONFIRMATION_PENDING, changed_by=None)

        return Response({"received": True})
