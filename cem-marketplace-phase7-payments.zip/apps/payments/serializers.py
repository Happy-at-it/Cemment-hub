from rest_framework import serializers
from .models import Payment, PaymentTransaction


class PaymentTransactionSerializer(serializers.ModelSerializer):
    class Meta:
        model = PaymentTransaction
        fields = ["id", "transaction_type", "amount", "status", "provider_response_ref", "created_at"]


class PaymentSerializer(serializers.ModelSerializer):
    order_number = serializers.CharField(source="order.order_number", read_only=True)
    transactions = PaymentTransactionSerializer(many=True, read_only=True)

    class Meta:
        model = Payment
        fields = ["id", "order", "order_number", "amount", "method", "provider",
                  "provider_reference", "status", "transactions", "created_at", "updated_at"]
        read_only_fields = fields


class InitiatePaymentSerializer(serializers.Serializer):
    method = serializers.ChoiceField(choices=["MobileMoney", "Card", "BankTransfer"])


class RefundSerializer(serializers.Serializer):
    amount = serializers.DecimalField(max_digits=12, decimal_places=2, required=False)
    reason = serializers.CharField(max_length=255)
