from django.urls import path
from .views import PaymentInitiateView, PaymentDetailView, PaymentRefundView, PaymentWebhookView

# Mounted at /api/v1/ by config/urls.py.
urlpatterns = [
    path("payments/<int:order_id>/initiate/", PaymentInitiateView.as_view(), name="payment-initiate"),
    path("payments/<int:order_id>/", PaymentDetailView.as_view(), name="payment-detail"),
    path("payments/<int:order_id>/refund/", PaymentRefundView.as_view(), name="payment-refund"),
    path("payments/webhook/<str:provider>/", PaymentWebhookView.as_view(), name="payment-webhook"),
]
