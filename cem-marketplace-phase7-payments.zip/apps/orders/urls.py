from django.urls import path
from .views import (
    CheckoutView, OrderListView, OrderDetailView,
    OrderConfirmView, OrderCancelView, OrderStatusUpdateView,
)

# Mounted at /api/v1/ by config/urls.py.
urlpatterns = [
    path("orders/checkout/", CheckoutView.as_view(), name="order-checkout"),
    path("orders/", OrderListView.as_view(), name="order-list"),
    path("orders/<int:pk>/", OrderDetailView.as_view(), name="order-detail"),
    path("orders/<int:pk>/confirm/", OrderConfirmView.as_view(), name="order-confirm"),
    path("orders/<int:pk>/cancel/", OrderCancelView.as_view(), name="order-cancel"),
    path("orders/<int:pk>/status/", OrderStatusUpdateView.as_view(), name="order-status-update"),
]
