from django.core.exceptions import ValidationError as DjangoValidationError
from django.shortcuts import get_object_or_404
from rest_framework import generics
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.views import APIView

from apps.cart.services import get_or_create_cart
from apps.common.permissions import IsCustomer, IsRetailer, IsAdminRole
from apps.users.models import Address
from .models import Order
from .serializers import (
    OrderListSerializer, OrderDetailSerializer, CheckoutSerializer,
    CancelOrderSerializer, OrderStatusUpdateSerializer,
)
from .services import checkout, confirm_order, cancel_order, can_cancel, EmptyCartError, RetailerNotSellableError
from .state_machine import transition, IllegalTransitionError


def _error(code, message, status=400):
    return Response({"error": {"code": code, "message": message}}, status=status)


class CheckoutView(APIView):
    """POST /api/v1/orders/checkout/
    Creates an Order from the customer's current cart. Delivery fee is
    NOT calculated here yet — that's the Delivery phase's pricing engine;
    for now a delivery order is created with delivery_fee=0 and the fee
    is filled in once a DeliveryPricingRule-based estimate is wired to
    checkout. Payment is a separate step: POST /payments/{order_id}/initiate/."""
    permission_classes = [IsAuthenticated, IsCustomer]

    def post(self, request):
        serializer = CheckoutSerializer(data=request.data, context={"request": request})
        serializer.is_valid(raise_exception=True)
        data = serializer.validated_data

        cart = get_or_create_cart(request.user.customer_profile)
        delivery_address = None
        if data["fulfillment_method"] == Order.DELIVERY:
            delivery_address = get_object_or_404(Address, id=data["delivery_address_id"], user=request.user)

        project = None
        if data.get("project_id"):
            from apps.users.models import Project
            project = get_object_or_404(
                Project, id=data["project_id"],
                contractor_profile__customer_profile=request.user.customer_profile,
            )

        try:
            order = checkout(
                cart, fulfillment_method=data["fulfillment_method"],
                delivery_address=delivery_address, delivery_fee=0, project=project,
            )
        except EmptyCartError as exc:
            return _error("EMPTY_CART", str(exc))
        except RetailerNotSellableError as exc:
            return _error("RETAILER_NOT_SELLABLE", str(exc))
        except DjangoValidationError as exc:
            # Covers InsufficientStockError bubbling up from reserve_for_order.
            message = "; ".join(exc.messages) if hasattr(exc, "messages") else str(exc)
            return _error("OUT_OF_STOCK", message)

        return Response(OrderDetailSerializer(order).data, status=201)


class OrderListView(generics.ListAPIView):
    """GET /api/v1/orders/
    Customers see their own orders; retailers see orders placed with
    them. Which one depends entirely on request.user.role — never a
    client-supplied filter, so a customer can't pass a query param to see
    another customer's orders or a retailer's incoming ones."""
    serializer_class = OrderListSerializer
    permission_classes = [IsAuthenticated]

    def get_queryset(self):
        user = self.request.user
        if user.role.role_name == "Customer":
            return Order.objects.filter(customer_profile__user=user).order_by("-placed_at")
        if user.role.role_name == "Retailer":
            return Order.objects.filter(retailer_profile__user=user).order_by("-placed_at")
        if user.role.role_name == "Admin":
            return Order.objects.all().order_by("-placed_at")
        return Order.objects.none()


class OrderDetailView(generics.RetrieveAPIView):
    """GET /api/v1/orders/{id}/
    Scoped the same way as the list view — a 404 (not 403) is returned
    for an order that exists but isn't this user's, so its existence
    isn't confirmed to someone probing IDs."""
    serializer_class = OrderDetailSerializer
    permission_classes = [IsAuthenticated]

    def get_queryset(self):
        user = self.request.user
        if user.role.role_name == "Customer":
            return Order.objects.filter(customer_profile__user=user)
        if user.role.role_name == "Retailer":
            return Order.objects.filter(retailer_profile__user=user)
        if user.role.role_name == "Admin":
            return Order.objects.all()
        return Order.objects.none()


class OrderConfirmView(APIView):
    """POST /api/v1/orders/{id}/confirm/  — retailer confirms their own order."""
    permission_classes = [IsAuthenticated, IsRetailer]

    def post(self, request, pk):
        order = get_object_or_404(Order, pk=pk, retailer_profile__user=request.user)
        try:
            order = confirm_order(order, acting_user=request.user)
        except IllegalTransitionError as exc:
            return _error("ILLEGAL_TRANSITION", str(exc))
        return Response(OrderDetailSerializer(order).data)


class OrderCancelView(APIView):
    """POST /api/v1/orders/{id}/cancel/  { "reason": "..." }
    Available to the customer who placed it or the retailer fulfilling
    it. Eligibility is entirely config/state-driven (apps.orders.services.can_cancel)
    — never hard-coded per caller."""
    permission_classes = [IsAuthenticated]

    def post(self, request, pk):
        user = request.user
        if user.role.role_name == "Customer":
            order = get_object_or_404(Order, pk=pk, customer_profile__user=user)
        elif user.role.role_name == "Retailer":
            order = get_object_or_404(Order, pk=pk, retailer_profile__user=user)
        elif user.role.role_name == "Admin":
            order = get_object_or_404(Order, pk=pk)
        else:
            return _error("FORBIDDEN", "You are not permitted to cancel orders.", status=403)

        serializer = CancelOrderSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)

        allowed, why = can_cancel(order)
        if not allowed:
            return _error("CANCELLATION_NOT_ALLOWED", why)

        order = cancel_order(order, acting_user=user, reason=serializer.validated_data["reason"])
        return Response(OrderDetailSerializer(order).data)


class OrderStatusUpdateView(APIView):
    """PATCH /api/v1/orders/{id}/status/  { "status": "Preparing", "note": "..." }
    Retailer (own order) or Admin only in this phase — driver-driven
    status changes (PickedUp, OutForDelivery, Delivered) happen via the
    Delivery app's own status endpoints in the Delivery phase, which call
    the same underlying transition() so the two stay consistent."""
    permission_classes = [IsAuthenticated]

    def patch(self, request, pk):
        user = request.user
        if user.role.role_name == "Retailer":
            order = get_object_or_404(Order, pk=pk, retailer_profile__user=user)
        elif user.role.role_name == "Admin":
            order = get_object_or_404(Order, pk=pk)
        else:
            return _error("FORBIDDEN", "Only the fulfilling retailer or an admin can update order status.", status=403)

        serializer = OrderStatusUpdateSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)

        try:
            order = transition(
                order, serializer.validated_data["status"], changed_by=user,
                note=serializer.validated_data.get("note", ""),
            )
        except IllegalTransitionError as exc:
            return _error("ILLEGAL_TRANSITION", str(exc))

        return Response(OrderDetailSerializer(order).data)
