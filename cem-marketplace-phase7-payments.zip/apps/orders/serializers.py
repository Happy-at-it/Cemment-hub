from rest_framework import serializers

from apps.users.models import Address
from .models import Order, OrderItem, OrderStatusHistory


class OrderItemSerializer(serializers.ModelSerializer):
    class Meta:
        model = OrderItem
        fields = ["id", "product", "product_name_snapshot", "unit_price_snapshot", "quantity", "line_total"]


class OrderStatusHistorySerializer(serializers.ModelSerializer):
    class Meta:
        model = OrderStatusHistory
        fields = ["status", "note", "changed_at"]


class OrderListSerializer(serializers.ModelSerializer):
    """Lighter shape for list views — no items/timeline, to keep the
    paginated response small."""
    customer_name = serializers.CharField(source="customer_profile.full_name", read_only=True)
    retailer_name = serializers.CharField(source="retailer_profile.business_name", read_only=True)

    class Meta:
        model = Order
        fields = ["id", "order_number", "customer_name", "retailer_name", "fulfillment_method",
                  "subtotal", "delivery_fee", "platform_fee", "total_amount",
                  "payment_status", "order_status", "placed_at"]


class OrderDetailSerializer(serializers.ModelSerializer):
    """Full order with items and the complete status timeline — this is
    what /orders/{id}/ returns, matching the spec's 'complete order
    timeline' requirement."""
    items = OrderItemSerializer(many=True, read_only=True)
    status_history = OrderStatusHistorySerializer(many=True, read_only=True)
    customer_name = serializers.CharField(source="customer_profile.full_name", read_only=True)
    retailer_name = serializers.CharField(source="retailer_profile.business_name", read_only=True)

    class Meta:
        model = Order
        fields = [
            "id", "order_number", "customer_name", "retailer_name", "fulfillment_method",
            "delivery_address", "subtotal", "delivery_fee", "platform_fee", "discount_amount",
            "total_amount", "payment_status", "order_status", "cancellation_reason", "cancelled_at",
            "placed_at", "completed_at", "items", "status_history",
        ]


class CheckoutSerializer(serializers.Serializer):
    fulfillment_method = serializers.ChoiceField(choices=[Order.PICKUP, Order.DELIVERY])
    delivery_address_id = serializers.IntegerField(required=False, allow_null=True)
    project_id = serializers.IntegerField(required=False, allow_null=True)

    def validate(self, attrs):
        request = self.context["request"]
        if attrs["fulfillment_method"] == Order.DELIVERY:
            if not attrs.get("delivery_address_id"):
                raise serializers.ValidationError({"delivery_address_id": "Required for delivery orders."})
            if not Address.objects.filter(id=attrs["delivery_address_id"], user=request.user).exists():
                raise serializers.ValidationError({"delivery_address_id": "Address not found on your account."})
        return attrs


class CancelOrderSerializer(serializers.Serializer):
    reason = serializers.CharField(max_length=255)


class OrderStatusUpdateSerializer(serializers.Serializer):
    status = serializers.ChoiceField(choices=Order.ORDER_STATUS_CHOICES)
    note = serializers.CharField(max_length=255, required=False, allow_blank=True)
