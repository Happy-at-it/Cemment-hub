# CEM Marketplace — Backend (through Phase: Orders)

## Progress so far
- **Database**, **Authentication**, **Retailers**, **Products & Catalog**, **Cart** — see prior phase notes.
- **Orders** (this drop):
  - `POST /api/v1/orders/checkout/` — creates an `Order` from the customer's cart via
    `apps/orders/services.py:checkout()` (written in the Database phase); reserves stock
    transactionally, empties the cart on success, rolls back everything on any failure
    (out of stock, empty cart, retailer not sellable). **Payment is a separate step** —
    checkout does not charge anything; that's `POST /payments/{order_id}/initiate/` in the next phase.
  - `GET /api/v1/orders/` — role-scoped: customers see their own, retailers see orders placed
    with them, admins see all. Scoping comes from `request.user.role`, never a client filter.
  - `GET /api/v1/orders/{id}/` — full detail with items **and** the complete status timeline
  - `POST /api/v1/orders/{id}/confirm/` — retailer confirms their own order
  - `POST /api/v1/orders/{id}/cancel/` — customer or retailer, gated entirely by
    `apps/orders/services.py:can_cancel()` (status + config-driven cancellation window)
  - `PATCH /api/v1/orders/{id}/status/` — retailer/admin only in this phase; every transition
    goes through `apps/orders/state_machine.py:transition()`, so illegal jumps (e.g.
    `OrderPlaced` → `Delivered`) are rejected with a 400, not silently accepted. Driver-driven
    status changes (`PickedUp`, `OutForDelivery`, `Delivered`) come via the Delivery app's own
    endpoints in the next-but-one phase, calling the same `transition()` underneath.
  - `tests/test_orders.py` — checkout success + stock reservation, cart clearing, delivery
    address requirement, empty-cart rejection, **real** insufficient-stock rejection (stock
    reduced between add-to-cart and checkout, whole order rolls back), confirm (own order only,
    404 for other retailers), cancel + stock release, cancellation blocked on completed orders,
    illegal status transitions rejected, role-based order visibility

## Run it
```bash
python -m venv venv && source venv/bin/activate
pip install -r requirements/dev.txt
cp .env.example .env
python manage.py makemigrations && python manage.py migrate
python manage.py createsuperuser
python manage.py runserver
```
```bash
pytest   # auth, retailer lifecycle, products/inventory, cart, orders
```

## Still not run against a live interpreter
Same caveat as every phase — syntax-checked, not execution-tested. Please
run `pytest` in Claude Code before the next phase builds further on top
of this one.

## What's next
**Payments**: wiring `apps/payments/services.py:initiate_payment()` (sandbox
gateway already implemented) to `POST /payments/{order_id}/initiate/`, plus
the webhook endpoint and refund flow.
