# CEM Marketplace — Backend (through Phase: Retailers)

## Progress so far
- **Database**: all 15 domain apps' models, service-layer business logic, admin wiring.
- **Authentication**: register/login/refresh/logout, password reset, profile + addresses, rate limiting.
- **Retailers** (this drop):
  - `POST /api/v1/retailers/register/` — business info + address; creates the profile in `Pending` status (requires a User already registered with `role=Retailer`)
  - `POST /api/v1/retailers/me/documents/` — multipart document upload (registration cert, owner ID, etc.), one call per file
  - `GET /api/v1/retailers/` — public directory, **Approved-only** (Pending/Rejected/Suspended never appear), filterable by `?city=` and `?delivery=true`
  - `GET /api/v1/retailers/{id}/` — public storefront detail, 404s (not 403s) for non-Approved retailers so their existence isn't confirmed
  - `GET/PATCH /api/v1/retailers/me/` — own profile; `status`/`rating_average`/`completed_orders_count` are read-only, silently ignored on PATCH (not an error — matches how most real APIs treat read-only fields)
  - `GET /api/v1/retailers/me/dashboard/` — sales (total/today), pending/completed/cancelled order counts, low-stock list, pending settlement total, recent customers, 7-day sales trend
  - `GET /api/v1/retailers/me/performance/` — fulfillment rate, average rating, repeat-customer count
  - `GET /api/v1/admin/retailers/?status=Pending` — admin verification queue (defaults to Pending)
  - `PATCH /api/v1/admin/retailers/{id}/verify/` — `{"action": "approve"|"reject"|"suspend", "reason": "..."}` — reject/suspend require a reason; delegates to the same service functions the Django admin's bulk actions use, so behavior (notifications, audit log) is identical either way
  - `tests/test_retailer_lifecycle.py` — registration, role gating, directory visibility before/after approval, reject-requires-reason, non-admin blocked from verifying, own-profile update, read-only status field

## Run it
```bash
python -m venv venv && source venv/bin/activate
pip install -r requirements/dev.txt
cp .env.example .env
python manage.py makemigrations && python manage.py migrate
python manage.py createsuperuser
python manage.py runserver
```
```bash
pytest   # runs test_auth.py + test_retailer_lifecycle.py
```

## Still not run against a live interpreter
Syntax-checked (`py_compile` + `ast.parse` on every file, including this
phase's additions) but not yet executed against real Django/DRF — same
sandbox limitation as before. Running `pytest` in Claude Code is the real
verification step.

## What's next
Products & Catalog phase: retailer-facing product CRUD (`/retailers/me/products/`),
category/brand admin endpoints, and inventory adjustment endpoints — building on
`apps/catalog/models.py` and `apps/inventory/services.py` already written.
